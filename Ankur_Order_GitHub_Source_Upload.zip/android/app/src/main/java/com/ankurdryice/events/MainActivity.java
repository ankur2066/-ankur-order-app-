package com.ankurdryice.events;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
