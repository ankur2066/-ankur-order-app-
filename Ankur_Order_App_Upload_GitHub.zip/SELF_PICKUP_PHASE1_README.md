# Self Pickup Phase 1 (business rules only)

Added `src/utils/selfPickup.ts`: pickup confirmation, 5-minute same-staff undo, owner override, receipt cancellation status, and immutable audit-event payloads.

**Not integrated yet:** UI, Firestore transaction/rules, PDF receipt, push, WhatsApp queue, dashboard alerts, and end-to-end tests. This archive must not be deployed as a completed Self Pickup feature.

Use the latest verified project source and merge this module only after reconciling with subsequent source revisions. Existing Firebase and signing configuration were not changed.
