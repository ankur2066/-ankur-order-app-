# Phase 8 — Staff controls UI scaffold and rule checks

Staff Dashboard now visibly displays **Confirm Pickup** and **Undo Pickup** for self-pickup orders. Both buttons are intentionally disabled (`disabled`, `aria-disabled`) and do not call Firebase, because a secure backend/validated Firestore rules are not yet available.

Security check: `pickup_audit` client writes are denied; existing staff order update rules allow only `status` and `updatedAt`, not `selfPickup`. This prevents insecure confirmation and falsified audits.

No live database modifications, deployment, GitHub push, notifications or APK build. Next implementation must add server-authoritative 5-minute undo checks, owner/staff role permissions, atomic audit and customer/owner notifications, then emulator and build tests.
