# Phase 12 — Testable server-side pickup policy

Added `firebase-functions/pickupPolicy.js` with pure server-side validation and five-minute undo authorization, and `firebase-functions/pickupPolicy.test.js` with 11 Node.js tests. The callable backend now uses these helpers.

Verified in this environment:
- `node --test firebase-functions/pickupPolicy.test.js`: 11 PASS / 0 FAIL.
- `node --check firebase-functions/index.js`: PASS.
- `npm run lint`: BLOCKED, no installed dependencies (`vite/client` type definitions missing). This is not a successful TypeScript build.

No Firebase Emulator run, live deploy, GitHub push, App Check configuration or signed APK. Real security and end-to-end testing still required before production.
