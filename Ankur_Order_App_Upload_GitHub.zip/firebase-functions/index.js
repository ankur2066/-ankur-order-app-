/**
 * Server-authoritative Self Pickup operations. Not deployed automatically.
 * Requires Firebase Functions configured and authorized staff identity.
 */
import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { canUndoPickup, validatePickupAction } from './pickupPolicy.js';

initializeApp();
const db = getFirestore();
const OWNER_EMAIL = 'ankurdryicewholesalers@gmail.com';

export const changeSelfPickup = onCall({ region: 'asia-south1', enforceAppCheck: true }, async (request) => {
  const auth = request.auth;
  if (!auth?.uid) throw new HttpsError('unauthenticated', 'Sign in required');
  const { orderId, action, reason } = request.data ?? {};
  const invalid = validatePickupAction({ orderId, action, reason });
  if (invalid) throw new HttpsError('invalid-argument', invalid);
  const isOwner = auth.token.email === OWNER_EMAIL && auth.token.email_verified === true;
  if (!isOwner) {
    const userSnap = await db.doc(`users/${auth.uid}`).get();
    const staff = userSnap.data();
    if (!staff || staff.role !== 'staff' || staff.permissions?.updateStatus !== true || staff.permissions?.viewOrders !== true) {
      throw new HttpsError('permission-denied', 'Pickup permission required');
    }
  }
  const orderRef = db.doc(`orders/${orderId}`);
  return db.runTransaction(async (tx) => {
    const snap = await tx.get(orderRef);
    if (!snap.exists) throw new HttpsError('not-found', 'Order not found');
    const order = snap.data();
    if (order.orderId !== orderId || order.isTrash === true || !order.selfPickup) {
      throw new HttpsError('failed-precondition', 'Not an active Self Pickup order');
    }
    const current = order.selfPickup;
    const now = Timestamp.now();
    let next;
    if (action === 'confirm') {
      if (current.status !== 'pickup_pending') throw new HttpsError('failed-precondition', 'Pickup is not pending');
      next = { ...current, status: 'pickup_completed', completedAt: now.toDate().toISOString(), completedBy: auth.uid, receiptStatus: 'valid' };
    } else {
      if (current.status !== 'pickup_completed') throw new HttpsError('failed-precondition', 'Pickup not completed');
      if (!isOwner) {
        if (!canUndoPickup({
          isOwner, actorUid: auth.uid, completedBy: current.completedBy,
          completedAt: current.completedAt, nowMs: now.toMillis()
        })) throw new HttpsError('permission-denied', 'Undo window expired or different staff member');
      }
      next = { ...current, status: 'pickup_pending', receiptStatus: 'cancelled' };
    }
    const eventRef = db.collection('pickup_audit').doc();
    const noticeRef = db.collection('pickup_notification_outbox').doc(eventRef.id);
    tx.update(orderRef, { selfPickup: next, updatedAt: now });
    tx.create(eventRef, { orderId, actorUid: auth.uid, action: action === 'confirm' ? 'pickup_confirmed' : 'pickup_undone', at: now, ...(action === 'undo' ? { reason: reason.trim() } : {}) });
    tx.create(noticeRef, { orderId, eventId: eventRef.id, event: action, customerUid: order.userId ?? null, status: 'pending', createdAt: now, whatsappMode: 'manual_only' });
    return { status: next.status, receiptStatus: next.receiptStatus, eventId: eventRef.id };
  });
});
