# Self Pickup Phase 2: receipt generator

Added `src/utils/selfPickupReceipt.ts` with guarded PDF download for confirmed, valid handovers only.

IMPORTANT: This is a source-level utility, not a complete feature. No customer UI is wired yet. The caller must verify customer authorization and provide actual verified received amount and box count; never use an assumed amount. No push notifications, WhatsApp queue, Firestore rules, or owner alerts have been implemented in this phase. Firestore security rules and transaction-safe confirmation/undo are required before production release. No Firebase writes were made.
