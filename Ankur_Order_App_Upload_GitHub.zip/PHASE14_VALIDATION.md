# Phase 14 — reproducible CI validation

Added `.github/workflows/self-pickup-validation.yml` for GitHub Actions on pull requests or manual dispatch. It installs exact locked frontend dependencies, runs TypeScript, Vite build, backend policy tests, and backend syntax checks. This workflow does not deploy Firebase, access secrets, or produce a signed APK.

Local test results (2026-10-30): `node --test firebase-functions/pickupPolicy.test.js` passed 11/11. `npm run lint` failed because `vite/client` types are absent; `npm run build` failed because Vite is not installed. Existing `node_modules` directory is incomplete (2.7 MB). These are NOT passing build results.

**GitHub limitation:** The connected repo currently builds from `Ankur_Order_GitHub_Source_Upload.zip` stored in the repository. Phase 14 changes in this archive have not been pushed to the repository, so GitHub Actions will not test them until the source archive is updated there. Do not dispatch the signed release workflow yet.

**Production blockers:** Firebase App Check, deploy, Firestore emulator authorization tests, client integration tests, and signed APK build remain outstanding.
