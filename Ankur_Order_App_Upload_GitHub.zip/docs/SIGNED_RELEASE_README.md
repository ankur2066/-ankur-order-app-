# Signed release build (not debug)

This workflow builds `assembleRelease`, verifies APK signing and uploads only the signed release artifact. It does not deploy or alter Firebase.

Required GitHub Actions **secrets** (never commit them):
- `ANKUR_RELEASE_KEYSTORE_BASE64`: base64 encoding of the ORIGINAL keystore used to sign the installed app
- `ANKUR_RELEASE_STORE_PASSWORD`
- `ANKUR_RELEASE_KEY_ALIAS`
- `ANKUR_RELEASE_KEY_PASSWORD`

Use the same original keystore and alias to update existing installs. Do not upload the keystore into repository files or chat. If the original keystore is unavailable, STOP: a new signing key cannot normally update the installed app.

Go to Actions > Ankur Order - Signed Release APK > Run workflow. Supply `version_code` (greater than installed APK) and `version_name`. These are not known from the source; the original Gradle file had versionCode=1 and versionName=1.0, which may not match distributed APKs. Confirm actual installed versionCode before running.

Build is untested until GitHub Actions runs. Firebase settings/Google services configuration must be reviewed before distribution. The signing secrets are passed to Gradle at build time, not committed. Do not publish the artifact publicly.
