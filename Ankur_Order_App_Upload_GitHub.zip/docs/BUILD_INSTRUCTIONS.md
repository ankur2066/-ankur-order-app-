# Build and deploy

1. `npm install`
2. `npm run lint` (type-check, this was NOT run by the author, see TEST_REPORT.md)
3. `npm run dev` (web test) and test the checklist in TEST_REPORT.md.

## Firebase (do before shipping the APK)
- Console > Firestore > Rules: paste `firestore.rules`, Publish. **Check first what is currently deployed**; keep a copy.
- Console > Storage: enable it, paste `storage.rules`, Publish (needed for product photo upload; the paid plan may be required for new buckets).
- Sign in once with the owner Google account, then Owner Dashboard > स्टोर / थीम > प्रोडक्ट > "मौजूदा 3 प्रोडक्ट कैटलॉग में सेव करें".
- Existing staff documents keep working (no `permissions` map = old behaviour). Review them in Owner Dashboard > Users.

## AI video / owner AI chat (optional backend)
- Host `server.ts` anywhere with Node 20+ (`NODE_ENV=production npm run build && NODE_ENV=production npx tsx server.ts`).
- Set env: `GEMINI_API_KEY`, `VEO_MODEL`, `ALLOWED_ORIGINS` (see `.env.example`).
- Build the app with `VITE_API_BASE_URL=https://your-server` (in `.env`), otherwise the APK shows "AI video unavailable".
- Veo may be paid/limited on your key; the server enforces `VIDEO_DAILY_LIMIT` per user.

## Android (existing script, unchanged)
`npm run android:sync` then `cd android && gradlew.bat assembleDebug` (or `BUILD_NEW_APK.cmd`). Release signing: use your own existing keystore; none is included or created.
Note: `android/app/src/main/assets/public` contains the OLD built web files until you run the sync.
