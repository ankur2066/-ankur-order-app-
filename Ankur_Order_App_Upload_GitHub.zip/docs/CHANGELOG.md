# Change log (storefront redesign + security hardening)

## 1. Security (done first)
- **Fixed privilege escalation in `firestore.rules`.** Previously any signed-in user could write their own `users/{uid}` document including `role`, which made them staff/admin. Now:
  - Owner = only the verified Google account `ankurdryicewholesalers@gmail.com`. A `role: "admin"` field in a user document grants nothing.
  - A user can write only `customerName, customerPhone, city, updatedAt` on their own document. Role, permissions and everything else are owner-only.
  - New `staffRequests/{uid}` collection: a person can file one pending request about themselves; only the owner can list, approve or delete.
  - Staff/delivery access to orders/tracking is now permission based (`viewOrders`, `updateStatus`). Staff created before this change (no `permissions` map) keep working as before.
  - Products: public can read only `active == true`; owner full write; staff with `toggleProducts` can change only `active`.
- Server (`server.ts`): `/api/gemini/chat` now requires the verified owner; unauthenticated, key-burning `/api/generate-image` and the fake `/api/generate-video` were removed; added CORS allow-list.
- New `storage.rules`: product photos readable by all, writable only by the verified owner (images < 2 MB).
- Security rules viewer inside the app now shows the real `firestore.rules` file (it previously showed a stale, different copy) and is owner-only.

## 2. Login
- One shared Google Sign-In screen (`SignInScreen`). Role comes from Firestore, never from which button was pressed.
- Removed `StaffLogin.tsx` and `LoginPortal.tsx` and the "staff portal" footer link.
- Owner approves staff in Owner Dashboard > Users (pending requests, role, permissions, revoke).
- Role is watched live (`useAccess`), so approval/revocation takes effect without restart.

## 3. Customer app
- New Blinkit-style home (original Ankur branding, icons and ice-crystal mark): hero header, search, category strip, quick tiles, snap promo carousel, Lucky Winner, one-tap "reorder last order", product grid.
- Fixed bottom tabs: Home, Categories, My Orders, AI Video, Profile.
- Only **active** products are shown. Until the owner presses "save catalog" once, the 3 built-in products are shown so nothing disappears. The repository contains no other dummy products.
- Booking: tapping a product opens the existing booking form with that product; legacy products keep following global rates in `settings/rates`.
- In-app order notifications (bell + toast) while the app is open. Not background push.

## 4. Owner
- New "स्टोर / थीम" section: add/edit/disable products with image upload (or https link), 5 themes, home banners, Lucky Winner (name + city, gift shown only as generic "खास गिफ्ट").
- Themes (Bhagwa Saffron #FF7A00, Emerald, Royal Blue, Purple, Dark) are saved in `settings/theme` and applied to customer, staff and owner screens.

## 5. AI Video
- New customer tab with: (a) server-based AI video (generate, poll, preview, download, share) with honest unavailable/error states, (b) the existing Creative Studio video export, kept.
- Creative Studio: standalone photo generation, HD PNG download and its `/api/generate-image` call removed. Photo upload removed from it (video upload kept). A reference photo can be attached only in the AI video form.
- No API key in client code; backend needs `GEMINI_API_KEY` and `VEO_MODEL`.

## Untouched
Order data, payments, tracking logic, collection names, Firebase IDs, `applicationId` (`com.ankurdryice.events`), `android/` native project and signing config, Ankur Smart CRM. No keystore was created.
