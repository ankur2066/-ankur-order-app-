# Ankur Dryice Security Specification (ABAC & Zero-Trust)

## 1. Data Invariants & Access Control Policy

1. **Catch-All Default Deny**: Every document and path in Firestore is denied access by default (`match /{document=**} { allow read, write: if false; }`).
2. **PII Isolation & Order Privacy**: 
   - Sensitive personal information (`customerName`, `customerPhone`, `customerEmail`, `deliveryAddress`, `pincode`, `specialInstructions`, `subtotal`, `totalAmount`) is isolated in `/orders/{orderId}`.
   - Public users CANNOT read `/orders/{orderId}`. Only the order owner (`resource.data.userId == request.auth.uid` if signed in) or an authorized Admin (`isAdmin()`) can read or list `/orders/{orderId}`.
3. **Public Order Tracking Sanitization**:
   - Tracking is handled via the split collection `/order_tracking/{orderId}`.
   - This collection contains ZERO PII (no customer name, no phone, no email, no street address, no commercial financial data). Only `orderId`, `status`, `productType`, `quantityKg`, `city`, `deliveryDate`, `urgency`, `lastStatusUpdate`, and timestamps are exposed.
   - Attackers CANNOT list or scrape `/order_tracking` (`allow list: if false;` or admin-only). Only direct point lookups by exact, valid ID (`allow get: if isValidId(orderId)`) are permitted.
4. **Order Creation Validation**:
   - Customers can create a new order in `/orders/{orderId}` only if `isValidOrder(incoming())` passes with all required keys, valid types, bounded lengths, status initialized strictly to `'pending'`, and `createdAt` & `updatedAt` matching `request.time`.
   - Creation requires atomic pairing: creating `/orders/{orderId}` requires `existsAfter(/databases/$(database)/documents/order_tracking/$(orderId))`, guaranteeing no orphaned private orders without public tracking projections.
5. **Administrative Privilege & Anti-Escalation**:
   - Administrative roles are anchored to verified email (`ankurdryicewholesalers@gmail.com` with `email_verified == true`) and/or presence in the `/admins/{userId}` collection.
   - Customers and unauthenticated users CANNOT update or delete orders, change order statuses, alter order amounts, or tamper with tracking.
   - Status transitions (e.g. to `'delivered'` or `'cancelled'`) are terminal unless updated by an admin.

---

## 2. The "Dirty Dozen" Malicious Payloads

The following 12 attack payloads attempt to exploit common Firestore vulnerabilities:

### Payload 1: Shadow Field Injection (Denial of Schema)
- **Target**: `orders/ADI-20261017-X892`
- **Vector**: Attacker adds `discountCode: "FREE_100"` or `isVipApproved: true` to the order payload.
- **Expected Outcome**: `PERMISSION_DENIED` via `data.keys().hasOnly([...])` strict allowlist.

### Payload 2: Status Tampering on Creation (State Shortcutting)
- **Target**: `orders/ADI-20261017-X892`
- **Vector**: Attacker submits an order with `"status": "delivered"` and `"paymentStatus": "paid_online"`.
- **Expected Outcome**: `PERMISSION_DENIED` because creation requires `incoming().status == 'pending'` and `incoming().paymentStatus in ['pending', 'paid_on_delivery', 'prepaid_online']`.

### Payload 3: Public PII Snooping via Collection Listing
- **Target**: `orders` collection query without user filter
- **Vector**: Unauthenticated or unauthorized user performs `getDocs(collection(db, "orders"))`.
- **Expected Outcome**: `PERMISSION_DENIED` because `allow list: if (isSignedIn() && resource.data.userId == request.auth.uid) || isAdmin()`.

### Payload 4: Directory Harvest Attack on Tracking (Mass Scraping)
- **Target**: `order_tracking` collection query
- **Vector**: Scraper attempts `getDocs(collection(db, "order_tracking"))` to extract all customer orders across cities.
- **Expected Outcome**: `PERMISSION_DENIED` because `allow list: if isAdmin()`. Only single-document `get` is permitted with a valid ID.

### Payload 5: ID Poisoning / Buffer Overflow Attack
- **Target**: `orders/ADI-MALICIOUS-%00-OVERFLOW-A...[10KB]`
- **Vector**: Malicious actor supplies a 10KB string with special characters as document ID.
- **Expected Outcome**: `PERMISSION_DENIED` via `isValidId(orderId)` regex `^[a-zA-Z0-9_\\-]+$` and `.size() <= 64`.

### Payload 6: Client Timestamp Manipulation
- **Target**: `orders/ADI-20261017-X892`
- **Vector**: Submitting client-generated timestamp in the past or future (`"createdAt": "2020-01-01T00:00:00Z"`).
- **Expected Outcome**: `PERMISSION_DENIED` via strict `incoming().createdAt == request.time`.

### Payload 7: Negative / Out-of-Bounds Quantity Exploit
- **Target**: `orders/ADI-20261017-X892`
- **Vector**: Customer orders `-500` kg or `99999999` kg of dry ice to corrupt billing.
- **Expected Outcome**: `PERMISSION_DENIED` because `data.quantityKg is number && data.quantityKg >= 5 && data.quantityKg <= 5000`.

### Payload 8: Customer Post-Creation Price Alteration (Update Gap)
- **Target**: `orders/ADI-20261017-X892`
- **Vector**: Customer updates their placed order to change `totalAmount: 1` or `status: "delivered"`.
- **Expected Outcome**: `PERMISSION_DENIED` because customer cannot update `/orders/{orderId}`; only `isAdmin()` has update privileges.

### Payload 9: Spoofed Identity on Signed-In Order
- **Target**: `orders/ADI-20261017-X892`
- **Vector**: User logged in with UID `attacker_uid` submits order with `"userId": "victim_uid"`.
- **Expected Outcome**: `PERMISSION_DENIED` because `incoming().userId == request.auth.uid`.

### Payload 10: Email Spoofing Admin Escalation
- **Target**: `admins/attacker_uid` or administrative order status updates
- **Vector**: Attacker signs up with `ankurdryicewholesalers@gmail.com` on an unverified email provider or without `email_verified == true`.
- **Expected Outcome**: `PERMISSION_DENIED` because `isAdmin()` strictly mandates `request.auth.token.email_verified == true`.

### Payload 11: Self-Assigned Admin Record Creation
- **Target**: `admins/attacker_uid`
- **Vector**: Authenticated non-admin attempts `setDoc(doc(db, "admins", uid), { role: "super_admin" })`.
- **Expected Outcome**: `PERMISSION_DENIED` because write to `/admins/{adminId}` requires existing `isAdmin()`.

### Payload 12: Orphaned Tracking Projection Exploit (Desync Attack)
- **Target**: Creating `/orders/{orderId}` without creating matching `/order_tracking/{orderId}` in the atomic batch.
- **Vector**: Malicious client attempts to create order document while omitting the public tracking projection.
- **Expected Outcome**: `PERMISSION_DENIED` via `existsAfter(/databases/$(database)/documents/order_tracking/$(orderId))`.
