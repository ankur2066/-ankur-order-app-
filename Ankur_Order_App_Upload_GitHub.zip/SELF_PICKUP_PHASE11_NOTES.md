# Phase 11 — Backend-only pickup state and UI safety

- Firestore owner update rule now requires `selfPickup` to remain unchanged. Only the Admin SDK backend can change pickup state, ensuring normal owner client edits cannot bypass audit.
- Staff buttons now disable during any pending pickup action, reducing duplicate requests.
- Backend uses Firebase callable `changeSelfPickup` in `asia-south1`, with App Check enforcement.
- The existing audit and outbox collections remain client-write-denied.

## NOT DONE
- No deployment, emulator rules tests, npm build, end-to-end test, GitHub push or signed APK.
- Must verify Firebase App Check initialization, deploy backend and rules, and test with Firebase Emulator before release.
- Confirm whether this repository has Firebase deployment configuration and whether callable functions are deployed in the intended project.
