import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';

dotenv.config();

const OWNER_EMAIL = 'ankurdryicewholesalers@gmail.com';

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT || 3000);

  // The Gemini key lives ONLY here on the server (environment variable). It is never sent to the app.
  const GEMINI_KEY = process.env.GEMINI_API_KEY || '';
  const ai: GoogleGenAI | null = GEMINI_KEY
    ? new GoogleGenAI({
        apiKey: GEMINI_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      })
    : null;

  app.use(express.json({ limit: '8mb' }));

  // ---------------------------------------------------------------------
  // CORS for the installed Android app (WebView origin) and local dev.
  // Override with ALLOWED_ORIGINS="https://a.com,https://b.com"
  // ---------------------------------------------------------------------
  const allowedOrigins = (process.env.ALLOWED_ORIGINS ||
    'https://localhost,capacitor://localhost,http://localhost,http://localhost:3000,http://localhost:5173')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean);

  app.use('/api', (req, res, next) => {
    const origin = req.headers.origin;
    if (origin && allowedOrigins.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    }
    if (req.method === 'OPTIONS') {
      res.sendStatus(204);
      return;
    }
    next();
  });

  // ---------------------------------------------------------------------
  // Firebase ID-token verification (no extra dependency): Google's Identity
  // Toolkit "accounts:lookup" validates the token and returns the user.
  // ---------------------------------------------------------------------
  let firebaseWebApiKey = process.env.FIREBASE_WEB_API_KEY || '';
  if (!firebaseWebApiKey) {
    try {
      firebaseWebApiKey = JSON.parse(fs.readFileSync(path.resolve('firebase-applet-config.json'), 'utf8')).apiKey || '';
    } catch {
      firebaseWebApiKey = '';
    }
  }

  interface VerifiedUser { uid: string; email?: string; emailVerified: boolean }
  const tokenCache = new Map<string, { user: VerifiedUser; expires: number }>();

  async function verifyFirebaseUser(req: express.Request): Promise<VerifiedUser | null> {
    const match = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    if (!match || !firebaseWebApiKey) return null;
    const token = match[1];
    const cached = tokenCache.get(token);
    if (cached && cached.expires > Date.now()) return cached.user;
    try {
      const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${firebaseWebApiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken: token }),
      });
      if (!resp.ok) return null;
      const data: any = await resp.json();
      const u = data?.users?.[0];
      if (!u?.localId) return null;
      const user: VerifiedUser = { uid: u.localId, email: u.email, emailVerified: !!u.emailVerified };
      tokenCache.set(token, { user, expires: Date.now() + 60_000 });
      if (tokenCache.size > 500) tokenCache.clear();
      return user;
    } catch {
      return null;
    }
  }

  const requireUser: express.RequestHandler = async (req, res, next) => {
    const user = await verifyFirebaseUser(req);
    if (!user) {
      res.status(401).json({ error: 'लॉगिन ज़रूरी है।' });
      return;
    }
    (req as any).authUser = user;
    next();
  };

  const requireOwner: express.RequestHandler = async (req, res, next) => {
    const user = await verifyFirebaseUser(req);
    if (!user) {
      res.status(401).json({ error: 'लॉगिन ज़रूरी है।' });
      return;
    }
    if (user.email !== OWNER_EMAIL || !user.emailVerified) {
      res.status(403).json({ error: 'यह सुविधा सिर्फ़ मालिक के लिए है।' });
      return;
    }
    (req as any).authUser = user;
    next();
  };

  function generateFallbackOrderResponse(userQuery: string, contextRaw: any): string {
    let ctx: any = null;
    try {
      ctx = typeof contextRaw === 'string' ? JSON.parse(contextRaw) : contextRaw;
    } catch {
      ctx = null;
    }

    const q = (userQuery || '').toLowerCase().trim();
    const todayOrders: any[] = ctx?.todayOrders || (Array.isArray(ctx) ? ctx : []);
    const recentOrders: any[] = ctx?.recentOrders || (Array.isArray(ctx) ? ctx : []);
    const allOrders: any[] = todayOrders.length > 0 ? todayOrders : recentOrders;
    const totalActive = ctx?.totalActiveOrders ?? (allOrders.length || 0);
    const todayCount = ctx?.todayOrdersCount ?? todayOrders.length;
    const todayKg = ctx?.todayTotalKg ?? todayOrders.reduce((sum: number, o: any) => sum + (Number(o.quantityKg) || 0), 0);
    const todayVal = ctx?.todayTotalValue ?? todayOrders.reduce((sum: number, o: any) => sum + (Number(o.totalAmount) || 0), 0);

    const getStatusText = (st: string) => {
      switch (st) {
        case 'pending': return '⏳ पेंडिंग';
        case 'confirmed': return '✅ कन्फर्म';
        case 'in_packing': return '📦 पैकिंग जारी';
        case 'dispatched': return '🚚 डिस्पैच / रास्ते में';
        case 'delivered': return '🎉 डिलीवर हो गया';
        default: return st || 'पेंडिंग';
      }
    };

    // 1. "aaj ke order" / "today"
    if (q.includes('aaj') || q.includes('today') || q.includes('आज')) {
      if (todayCount === 0 && todayOrders.length === 0) {
        return `नमस्ते अंकुर जी! आज (${ctx?.todayDate || 'Today'}) का अभी तक कोई नया ऑर्डर नहीं आया है।\nकुल सक्रिय ऑर्डर्स: ${totalActive} हैं।`;
      }
      let msg = `📋 नमस्ते अंकुर जी! आज के ऑर्डर्स का विवरण:\n\n`;
      msg += `• कुल आज के ऑर्डर्स: ${todayCount}\n`;
      msg += `• कुल ड्राई आइस मात्रा: ${todayKg} KG\n`;
      if (todayVal > 0) msg += `• कुल अनुमानित राशि: ₹${todayVal}\n\n`;
      msg += `ऑर्डर सूची:\n`;
      const displayList = todayOrders.length > 0 ? todayOrders : allOrders.slice(0, 10);
      displayList.forEach((ord: any, idx: number) => {
        const id = ord.orderId ? ord.orderId.split('-').pop() : `#${idx + 1}`;
        const name = ord.customerName || 'ग्राहक';
        const city = ord.district || ord.city ? ` (${ord.district || ord.city})` : '';
        const qty = ord.quantityKg ? `${ord.quantityKg} KG` : '';
        const timing = ord.dispatchTiming ? ` • ${ord.dispatchTiming}` : '';
        msg += `${idx + 1}. #${id} - ${name}${city}: ${qty} [${getStatusText(ord.status)}]${timing}\n`;
      });
      return msg;
    }

    // 2. "pending" / "packing"
    if (q.includes('pending') || q.includes('पेंडिंग') || q.includes('packing') || q.includes('पैकिंग') || q.includes('बाकी')) {
      const pendings = allOrders.filter((o: any) => o.status === 'pending' || o.status === 'in_packing');
      if (pendings.length === 0) {
        return `✅ बहुत बढ़िया! वर्तमान में कोई भी पेंडिंग या पैकिंग हेतु बाकी ऑर्डर नहीं है। सभी ऑर्डर्स डिस्पैच या डिलीवर हो चुके हैं।`;
      }
      let msg = `⏳ वर्तमान में ${pendings.length} ऑर्डर्स पैकिंग/पेंडिंग में हैं:\n`;
      pendings.slice(0, 8).forEach((o: any, i: number) => {
        const id = o.orderId ? o.orderId.split('-').pop() : `#${i + 1}`;
        msg += `${i + 1}. #${id}: ${o.customerName || 'ग्राहक'} (${o.quantityKg || 0} KG) - ${getStatusText(o.status)}\n`;
      });
      return msg;
    }

    // 3. "dispatched" / "delivered"
    if (q.includes('dispatch') || q.includes('डिस्पैच') || q.includes('deliver') || q.includes('डिलीवर') || q.includes('रास्ते')) {
      const list = allOrders.filter((o: any) => o.status === 'dispatched' || o.status === 'delivered');
      let msg = `🚚 डिस्पैच व डिलीवरी स्थिति:\n`;
      list.slice(0, 8).forEach((o: any, i: number) => {
        const id = o.orderId ? o.orderId.split('-').pop() : `#${i + 1}`;
        msg += `${i + 1}. #${id}: ${o.customerName || 'ग्राहक'} (${o.quantityKg || 0} KG) - ${getStatusText(o.status)}\n`;
      });
      if (list.length === 0) msg += `वर्तमान में कोई डिस्पैच/डिलीवर ऑर्डर नहीं मिला।`;
      return msg;
    }

    // 4. "total" / "kul" / "summary"
    if (q.includes('total') || q.includes('कुल') || q.includes('kitne') || q.includes('कितने') || q.includes('summary') || q.includes('हाल')) {
      return `📊 Ankur Dry Ice - ऑर्डर स्थिति सारांश:\n` +
        `• कुल सक्रिय ऑर्डर्स: ${totalActive}\n` +
        `• आज के ऑर्डर्स: ${todayCount} (${todayKg} KG)\n` +
        `• पेंडिंग ऑर्डर्स: ${ctx?.statusCounts?.pending ?? 'उपलब्ध'}\n` +
        `• पैकिंग जारी: ${ctx?.statusCounts?.packing ?? 'उपलब्ध'}\n` +
        `• रास्ते में (Dispatched): ${ctx?.statusCounts?.dispatched ?? 'उपलब्ध'}\n` +
        `• डिलीवर हो चुके: ${ctx?.statusCounts?.delivered ?? 'उपलब्ध'}`;
    }

    // 5. Customer search
    const matched = allOrders.find((o: any) => 
      (o.customerName && o.customerName.toLowerCase().includes(q)) ||
      (o.orderId && o.orderId.toLowerCase().includes(q)) ||
      (o.district && o.district.toLowerCase().includes(q))
    );
    if (matched) {
      return `🔍 ग्राहक ऑर्डर विवरण:\n` +
        `• ऑर्डर ID: #${matched.orderId}\n` +
        `• ग्राहक: ${matched.customerName}\n` +
        `• ज़िला/शहर: ${matched.district || matched.city || 'दर्ज नहीं'}\n` +
        `• मात्रा: ${matched.quantityKg} KG ड्राई आइस\n` +
        `• स्लॉट: ${matched.dispatchTiming || 'सामान्य'}\n` +
        `• स्टेटस: ${getStatusText(matched.status)}`;
    }

    // Default polite answer
    return `नमस्ते अंकुर जी! मैं आपके ऑर्डर्स का विश्लेषण कर सकता हूँ।\n` +
      `• आज के ऑर्डर्स के लिए 'aaj ke order' लिखें।\n` +
      `• पेंडिंग के लिए 'pending' लिखें।\n` +
      `• कुल स्थिति के लिए 'total orders' लिखें।`;
  }

  const withTimeout = <T>(promise: Promise<T>, ms: number): Promise<T> => {
    return Promise.race([
      promise,
      new Promise<T>((_, reject) => setTimeout(() => reject(new Error('Timeout')), ms)),
    ]);
  };

  app.post('/api/gemini/chat', requireOwner, async (req, res) => {
    const { message, context } = req.body;
    let aiResponse = '';

    // 1. Try Gemini model with quick 2.5s timeout
    try {
      const response = await withTimeout(
        (ai as GoogleGenAI).models.generateContent({
          model: "gemini-3.8-flash",
          contents: `Context Data:\n${typeof context === 'object' ? JSON.stringify(context) : context}\n\nUser Question:\n${message}`,
          config: {
            systemInstruction: "You are an intelligent, polite business assistant for Ankur Dry Ice & Events (Owner: Ankur Singh, Gorakhpur). Answer user queries about orders, daily status, quantities (KG), packing, and dispatch strictly using the provided context in clear Hindi.",
          },
        }),
        2500
      );
      if (response && response.text) {
        aiResponse = response.text;
      }
    } catch {
      // Graceful fallback to built-in intelligent engine
    }

    // 2. Fallback to built-in smart analytics engine
    if (!aiResponse) {
      aiResponse = generateFallbackOrderResponse(message, context);
    }

    res.json({ response: aiResponse });
  });

  // =====================================================================
  // AI VIDEO (Gemini / Veo) - server side only.
  //
  // STATUS: written against the documented @google/genai video flow but NOT
  // run against the live API in this project. Test it with your own key.
  //
  // Required environment variables (never put these in the app):
  //   GEMINI_API_KEY   key from Google AI Studio
  //   VEO_MODEL        the Veo model name your key can use (see AI Studio docs)
  // Optional: VIDEO_DAILY_LIMIT (default 3 per user/day), VIDEO_MAX_CONCURRENT (default 2)
  // Veo video generation can be paid / restricted on a free key. Check your quota.
  // =====================================================================
  const VEO_MODEL = process.env.VEO_MODEL || '';
  const VIDEO_DAILY_LIMIT = Number(process.env.VIDEO_DAILY_LIMIT || 3);
  const VIDEO_MAX_CONCURRENT = Number(process.env.VIDEO_MAX_CONCURRENT || 2);

  interface VideoJob {
    id: string;
    uid: string;
    status: 'queued' | 'processing' | 'done' | 'failed';
    error?: string;
    filePath?: string;
    createdAt: number;
  }
  const videoJobs = new Map<string, VideoJob>();
  const videoUsage = new Map<string, { day: string; count: number }>();

  const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
  const todayKey = () => new Date().toISOString().slice(0, 10);

  function videoConfigStatus(): { configured: boolean; reason?: string } {
    if (!GEMINI_KEY) return { configured: false, reason: 'सर्वर पर GEMINI_API_KEY सेट नहीं है।' };
    if (!VEO_MODEL) return { configured: false, reason: 'सर्वर पर VEO_MODEL सेट नहीं है (AI Studio में अपनी की के लिए उपलब्ध Veo मॉडल का नाम डालें)।' };
    return { configured: true };
  }

  app.get('/api/video/health', (_req, res) => {
    res.json(videoConfigStatus());
  });

  async function runVideoJob(job: VideoJob, prompt: string, aspectRatio: string, image?: { mimeType: string; dataBase64: string }) {
    const genai: any = ai;
    try {
      job.status = 'processing';
      let operation: any = await genai.models.generateVideos({
        model: VEO_MODEL,
        prompt,
        ...(image ? { image: { imageBytes: image.dataBase64, mimeType: image.mimeType } } : {}),
        config: { numberOfVideos: 1, aspectRatio },
      });

      const deadline = Date.now() + 10 * 60 * 1000;
      while (!operation.done) {
        if (Date.now() > deadline) throw new Error('वीडियो बनने की समय सीमा पूरी हो गई।');
        await sleep(10_000);
        operation = await genai.operations.getVideosOperation({ operation });
      }

      const video = operation.response?.generatedVideos?.[0]?.video;
      if (!video) throw new Error('मॉडल ने वीडियो नहीं लौटाया (सुरक्षा फ़िल्टर या कोटा हो सकता है)।');

      const filePath = path.join(os.tmpdir(), `ankur-video-${job.id}.mp4`);
      await genai.files.download({ file: video, downloadPath: filePath });
      job.filePath = filePath;
      job.status = 'done';
    } catch (err: any) {
      console.error('Video job failed:', err?.message || err);
      job.status = 'failed';
      job.error = 'वीडियो नहीं बन सका: ' + (err?.message || 'अज्ञात त्रुटि');
    }
  }

  app.post('/api/video/generate', requireUser, async (req, res) => {
    const status = videoConfigStatus();
    if (!status.configured) {
      res.status(503).json({ error: status.reason });
      return;
    }
    const user: VerifiedUser = (req as any).authUser;
    if (!user.emailVerified) {
      res.status(403).json({ error: 'वीडियो के लिए verified Google अकाउंट चाहिए।' });
      return;
    }

    const { prompt, aspectRatio, referenceImage } = req.body || {};
    if (typeof prompt !== 'string' || prompt.trim().length < 10 || prompt.length > 600) {
      res.status(400).json({ error: 'विवरण 10 से 600 अक्षरों के बीच होना चाहिए।' });
      return;
    }
    if (aspectRatio !== '16:9' && aspectRatio !== '9:16') {
      res.status(400).json({ error: 'आकार 16:9 या 9:16 होना चाहिए।' });
      return;
    }
    let image: { mimeType: string; dataBase64: string } | undefined;
    if (referenceImage) {
      const okType = referenceImage.mimeType === 'image/jpeg' || referenceImage.mimeType === 'image/png';
      if (!okType || typeof referenceImage.dataBase64 !== 'string' || referenceImage.dataBase64.length > 6_000_000) {
        res.status(400).json({ error: 'रेफ़रेंस फोटो JPEG/PNG और छोटी होनी चाहिए।' });
        return;
      }
      image = { mimeType: referenceImage.mimeType, dataBase64: referenceImage.dataBase64 };
    }

    const active = [...videoJobs.values()].filter((j) => j.status === 'queued' || j.status === 'processing').length;
    if (active >= VIDEO_MAX_CONCURRENT) {
      res.status(429).json({ error: 'अभी बहुत वीडियो बन रहे हैं। कुछ मिनट बाद कोशिश करें।' });
      return;
    }

    const usage = videoUsage.get(user.uid);
    const day = todayKey();
    const used = usage && usage.day === day ? usage.count : 0;
    if (used >= VIDEO_DAILY_LIMIT) {
      res.status(429).json({ error: `आज की सीमा (${VIDEO_DAILY_LIMIT} वीडियो) पूरी हो गई। कल फिर कोशिश करें।` });
      return;
    }
    videoUsage.set(user.uid, { day, count: used + 1 });

    const job: VideoJob = { id: crypto.randomUUID(), uid: user.uid, status: 'queued', createdAt: Date.now() };
    videoJobs.set(job.id, job);
    void runVideoJob(job, prompt.trim(), aspectRatio, image);
    res.status(202).json({ jobId: job.id });
  });

  function ownJob(req: express.Request, res: express.Response): VideoJob | null {
    const user: VerifiedUser = (req as any).authUser;
    const job = videoJobs.get(req.params.id);
    if (!job || job.uid !== user.uid) {
      res.status(404).json({ error: 'वीडियो जॉब नहीं मिला।' });
      return null;
    }
    return job;
  }

  app.get('/api/video/jobs/:id', requireUser, (req, res) => {
    const job = ownJob(req, res);
    if (!job) return;
    res.json({ id: job.id, status: job.status, error: job.error });
  });

  app.get('/api/video/jobs/:id/file', requireUser, (req, res) => {
    const job = ownJob(req, res);
    if (!job) return;
    if (job.status !== 'done' || !job.filePath || !fs.existsSync(job.filePath)) {
      res.status(404).json({ error: 'वीडियो अभी तैयार नहीं है।' });
      return;
    }
    res.setHeader('Content-Type', 'video/mp4');
    fs.createReadStream(job.filePath).pipe(res);
  });

  // Delete finished videos after an hour.
  setInterval(() => {
    const cutoff = Date.now() - 60 * 60 * 1000;
    for (const [id, job] of videoJobs) {
      if (job.createdAt < cutoff) {
        if (job.filePath) fs.rm(job.filePath, () => {});
        videoJobs.delete(id);
      }
    }
  }, 10 * 60 * 1000).unref();

  if (process.env.NODE_ENV === 'production') {
    // Production: API only + built web app (run `npm run build` first)
    app.use(express.static(path.resolve('dist')));
    app.get('*', (_req, res) => res.sendFile(path.resolve('dist', 'index.html')));
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => console.log(`Server listening on port ${port}`));
}

startServer();
