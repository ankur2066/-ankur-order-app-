# Ankur Order APK - SIGNED RELEASE ONLY

This repository includes a GitHub Actions workflow at `.github/workflows/android-signed-release.yml`. It builds ONLY `assembleRelease`, not a debug APK.

## Run requirements
1. Upload this source tree to a PRIVATE GitHub repository, without keystores, credentials, or customer data.
2. Configure the four GitHub Actions repository secrets listed in `docs/SIGNED_RELEASE_README.md`. Never paste passwords into chat or commit them.
3. Determine the installed APK's versionCode, and choose a larger integer for the new release.
4. GitHub Actions > `Ankur Order - Signed Release APK` > Run workflow.
5. Download the signed release APK artifact only after all steps pass.

No APK has been built or tested in this environment. Do not deploy Firebase rules before separate emulator validation.
