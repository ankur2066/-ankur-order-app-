import React, { createContext, useContext, useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { applyTheme, DEFAULT_THEME_ID } from '../theme/themes';
import type { ThemeId } from '../types';

interface ThemeContextValue {
  themeId: ThemeId;
  /** Local-only preview (not saved). Saving is done by the owner screen through Firestore. */
  previewTheme: (id: ThemeId) => void;
}

const ThemeContext = createContext<ThemeContextValue>({
  themeId: DEFAULT_THEME_ID,
  previewTheme: () => {},
});

/**
 * Listens to settings/theme in Firestore and applies it for EVERY role
 * (customer, staff, owner). Settings are publicly readable by design.
 */
export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [themeId, setThemeId] = useState<ThemeId>(DEFAULT_THEME_ID);

  useEffect(() => {
    const unsub = onSnapshot(
      doc(db, 'settings', 'theme'),
      (snap) => {
        const id = (snap.exists() ? (snap.data().themeId as ThemeId) : DEFAULT_THEME_ID) || DEFAULT_THEME_ID;
        setThemeId(id);
        applyTheme(id);
      },
      (err) => {
        // Keep the cached/default theme if Firestore is unreachable.
        console.warn('Theme listener error:', err?.message || err);
      }
    );
    return () => unsub();
  }, []);

  const previewTheme = (id: ThemeId) => {
    applyTheme(id);
  };

  return <ThemeContext.Provider value={{ themeId, previewTheme }}>{children}</ThemeContext.Provider>;
};

export function useTheme(): ThemeContextValue {
  return useContext(ThemeContext);
}
