import React from 'react';
import { Phone, MessageCircle } from 'lucide-react';

export const FloatingContactButtons: React.FC = () => {
  return (
    <div 
      className="fixed right-3 sm:right-5 z-30 app-safe-floating flex flex-col gap-2 items-end pointer-events-none select-none"
      aria-label="त्वरित संपर्क"
    >
      {/* WhatsApp Floating Action Button */}
      <a
        href="https://wa.me/918896332066?text=%E0%A4%A8%E0%A4%AE%E0%A4%B8%E0%A5%8D%E0%A4%A4%E0%A5%87%20%E0%A4%85%E0%A4%82%E0%A4%95%E0%A5%81%E0%A4%B0%20%E0%A4%A1%E0%A5%8D%E0%A4%B0%E0%A4%BE%E0%A4%88%20%E0%A4%86%E0%A4%87%E0%A4%B8%2C%20%E0%A4%AE%E0%A5%81%E0%A4%98%E0%A5%87%20%E0%A4%A1%E0%A5%8D%E0%A4%B0%E0%A4%BE%E0%A4%88%20%E0%A4%86%E0%A4%87%E0%A4%B8%20%E0%A4%AC%E0%A5%81%E0%A4%95%20%E0%A4%95%E0%A4%B0%E0%A4%A8%E0%A4%BE%20%E0%A4%B9%E0%A5%88%E0%A5%A4"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="WhatsApp पर संपर्क करें"
        title="WhatsApp पर चैट करें (+91 8896332066)"
        className="pointer-events-auto flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-full shadow-md hover:shadow-lg transition-all active:scale-95 text-xs font-bold border border-emerald-500/30"
      >
        <MessageCircle className="w-3.5 h-3.5 fill-current" />
        <span className="leading-none">WhatsApp</span>
      </a>

      {/* Call Floating Action Button */}
      <a
        href="tel:+918896332066"
        aria-label="कॉल करें"
        title="कॉल करें (+91 8896332066)"
        className="pointer-events-auto flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white rounded-full shadow-md hover:shadow-lg transition-all active:scale-95 text-xs font-bold border border-sky-500/30"
      >
        <Phone className="w-3.5 h-3.5 fill-current" />
        <span className="leading-none">कॉल करें</span>
      </a>
    </div>
  );
};
