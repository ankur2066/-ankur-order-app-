import React from 'react';
import { Gift, MapPin } from 'lucide-react';
import type { LuckyWinner } from '../../types';

/**
 * Shows only the winner's name and city plus the generic wording "खास गिफ्ट".
 * What the gift actually is stays a private decision of the owner.
 */
export const LuckyWinnerCard: React.FC<{ winner: LuckyWinner }> = ({ winner }) => (
  <section
    className="mx-4 c-card border b-line rounded-2xl p-3.5 flex items-center gap-3"
    aria-label="लकी विनर"
  >
    <div className="w-12 h-12 shrink-0 rounded-xl c-soft t-brand flex items-center justify-center">
      <Gift className="w-6 h-6" />
    </div>
    <div className="min-w-0 flex-1">
      <div className="text-[11px] font-bold t-sub">{winner.dateLabel ? `${winner.dateLabel} का लकी विनर` : 'लकी विनर'}</div>
      <div className="text-[16px] font-black t-main truncate">{winner.name}</div>
      <div className="text-[12px] t-sub flex items-center gap-1 truncate">
        <MapPin className="w-3.5 h-3.5 shrink-0" />
        <span className="truncate">{winner.city}</span>
      </div>
    </div>
    <div className="shrink-0 text-right">
      <div className="text-[11px] t-sub">इनाम</div>
      <div className="text-[13px] font-extrabold t-brand">खास गिफ्ट</div>
    </div>
  </section>
);

export default LuckyWinnerCard;
