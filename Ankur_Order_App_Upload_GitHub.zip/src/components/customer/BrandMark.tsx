import React from 'react';

/** Original Ankur ice-crystal mark (6-arm crystal). Colour follows the current text colour. */
export const BrandMark: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 48 48" className={className} fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" aria-hidden="true">
    <g>
      <path d="M24 5v38" />
      <path d="M7.5 14.5l33 19" />
      <path d="M40.5 14.5l-33 19" />
      <path d="M18.5 8.5L24 13l5.5-4.5" />
      <path d="M18.5 39.5L24 35l5.5 4.5" />
      <circle cx="24" cy="24" r="3" fill="currentColor" stroke="none" />
    </g>
  </svg>
);

export default BrandMark;
