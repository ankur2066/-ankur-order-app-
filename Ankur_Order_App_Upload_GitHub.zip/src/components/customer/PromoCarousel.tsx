import React from 'react';
import { ChevronRight } from 'lucide-react';
import type { PromoAction, PromoBanner } from '../../types';
import { BrandMark } from './BrandMark';

const BACKGROUNDS = [
  'linear-gradient(100deg, var(--brand-deep), var(--brand))',
  'linear-gradient(100deg, var(--hero-1), var(--hero-2))',
  'linear-gradient(100deg, var(--brand-ink), var(--brand-deep))',
];

interface PromoCarouselProps {
  banners: PromoBanner[];
  onAction: (action: PromoAction) => void;
}

/** Horizontal snap carousel with a visible peek of the next card, like the reference layout. */
export const PromoCarousel: React.FC<PromoCarouselProps> = ({ banners, onAction }) => (
  <div
    className="snap-rail no-scrollbar flex gap-3 overflow-x-auto px-4"
    role="region"
    aria-label="ऑफ़र और जानकारी"
  >
    {banners.map((b, i) => (
      <button
        key={b.id}
        type="button"
        onClick={() => onAction(b.action)}
        className="focus-ring relative shrink-0 w-[82%] max-w-[330px] min-h-[92px] rounded-2xl px-4 py-3 flex items-center gap-3 text-left text-white overflow-hidden cursor-pointer"
        style={{ background: BACKGROUNDS[i % BACKGROUNDS.length], boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.18)' }}
      >
        <BrandMark className="absolute -right-3 -bottom-4 w-24 h-24 opacity-15" />
        <div className="relative min-w-0 flex-1">
          <div className="text-[16px] font-black leading-snug">{b.title}</div>
          <div className="text-[12px] opacity-90 mt-0.5 leading-snug">{b.subtitle}</div>
        </div>
        {b.action !== 'none' && (
          <span className="relative shrink-0 w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
            <ChevronRight className="w-5 h-5" />
          </span>
        )}
      </button>
    ))}
  </div>
);

export default PromoCarousel;
