import React, { useEffect, useState } from 'react';
import { doc, onSnapshot, serverTimestamp, setDoc } from 'firebase/firestore';
import type { User } from 'firebase/auth';
import { ClipboardList, FileCode, Loader2, LogOut, MessageCircle, Phone, ShieldCheck, UserCheck } from 'lucide-react';
import { db, signOutUser } from '../../firebase';
import { BUSINESS_CALL_HREF, BUSINESS_PHONE_DISPLAY, BUSINESS_WHATSAPP_BASE } from '../../data/products';
import type { UserRole } from '../../types';
import { SignInScreen } from '../SignInScreen';

interface ProfileTabProps {
  currentUser: User | null;
  role: UserRole | null;
  onGoOrders: () => void;
  onOpenOwnerDashboard: () => void;
  onOpenRulesReview: () => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({ currentUser, role, onGoOrders, onOpenOwnerDashboard, onOpenRulesReview }) => {
  const [requestState, setRequestState] = useState<'unknown' | 'none' | 'pending'>('unknown');
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  // Watch my own staff-access request (rules allow reading only my own document).
  useEffect(() => {
    if (!currentUser || role) {
      setRequestState('unknown');
      return;
    }
    const unsub = onSnapshot(
      doc(db, 'staffRequests', currentUser.uid),
      (snap) => setRequestState(snap.exists() ? 'pending' : 'none'),
      () => setRequestState('none')
    );
    return () => unsub();
  }, [currentUser?.uid, role]);

  const sendRequest = async () => {
    if (!currentUser?.email) return;
    try {
      setSending(true);
      setMessage(null);
      await setDoc(doc(db, 'staffRequests', currentUser.uid), {
        uid: currentUser.uid,
        email: currentUser.email,
        name: (currentUser.displayName || '').slice(0, 100),
        status: 'pending',
        requestedAt: serverTimestamp(),
      });
      setMessage('अनुरोध मालिक को भेज दिया गया। मंज़ूरी मिलते ही स्टाफ पैनल खुल जाएगा।');
    } catch (err: any) {
      setMessage('अनुरोध नहीं भेजा जा सका: ' + (err?.message || 'अज्ञात त्रुटि'));
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="c-app min-h-screen page-with-bottom-nav">
      <header className="c-card border-b b-line px-4 pb-3" style={{ paddingTop: 'calc(env(safe-area-inset-top, 0px) + 14px)' }}>
        <h1 className="text-xl font-black t-main">प्रोफ़ाइल</h1>
      </header>

      <div className="p-4 space-y-4 max-w-lg mx-auto">
        {!currentUser ? (
          <SignInScreen />
        ) : (
          <>
            <section className="c-card border b-line rounded-2xl p-4 flex items-center gap-3">
              <div className="w-14 h-14 rounded-full c-soft t-brand flex items-center justify-center overflow-hidden shrink-0">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <UserCheck className="w-7 h-7" />
                )}
              </div>
              <div className="min-w-0">
                <div className="text-base font-black t-main truncate">{currentUser.displayName || 'ग्राहक'}</div>
                <div className="text-xs t-sub truncate">{currentUser.email}</div>
                {role && (
                  <span className="inline-block mt-1 text-[11px] font-extrabold px-2 py-0.5 rounded-full c-soft t-brand-ink">
                    {role === 'admin' ? 'मालिक' : role === 'staff' ? 'स्टाफ' : 'डिलीवरी'}
                  </span>
                )}
              </div>
            </section>

            <button
              type="button"
              onClick={onGoOrders}
              className="focus-ring w-full c-card border b-line rounded-2xl p-4 flex items-center gap-3 text-left cursor-pointer"
            >
              <ClipboardList className="w-5 h-5 t-brand" />
              <span className="text-sm font-extrabold t-main">मेरे ऑर्डर और ट्रैकिंग</span>
            </button>

            {role === 'admin' && (
              <>
                <button
                  type="button"
                  onClick={onOpenOwnerDashboard}
                  className="focus-ring w-full rounded-2xl p-4 flex items-center gap-3 text-left c-brand cursor-pointer"
                >
                  <ShieldCheck className="w-5 h-5" />
                  <span className="text-sm font-extrabold">ओनर डैशबोर्ड खोलें</span>
                </button>
                <button
                  type="button"
                  onClick={onOpenRulesReview}
                  className="focus-ring w-full c-card border b-line rounded-2xl p-4 flex items-center gap-3 text-left cursor-pointer"
                >
                  <FileCode className="w-5 h-5 t-brand" />
                  <span className="text-sm font-extrabold t-main">सिक्योरिटी रूल्स देखें</span>
                </button>
              </>
            )}

            {!role && (
              <section className="c-card border b-line rounded-2xl p-4">
                <h2 className="text-sm font-black t-main">क्या आप स्टाफ या डिलीवरी टीम में हैं?</h2>
                <p className="text-xs t-sub mt-1 leading-relaxed">
                  अपने इसी Google अकाउंट से एक्सेस माँगें। मालिक मंज़ूरी देंगे और बताएँगे कि आप क्या-क्या कर सकते हैं।
                </p>
                {requestState === 'pending' ? (
                  <div className="mt-3 p-3 rounded-xl c-soft text-xs font-bold t-brand-ink">
                    आपका अनुरोध मालिक की मंज़ूरी के इंतज़ार में है।
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={sendRequest}
                    disabled={sending || requestState === 'unknown'}
                    className="focus-ring mt-3 w-full min-h-11 rounded-xl border-2 b-brand t-brand text-sm font-extrabold flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
                  >
                    {sending && <Loader2 className="w-4 h-4 animate-spin" />}
                    स्टाफ एक्सेस माँगें
                  </button>
                )}
                {message && <p className="text-xs t-sub mt-2 leading-relaxed" role="status">{message}</p>}
              </section>
            )}
          </>
        )}

        <section className="c-card border b-line rounded-2xl p-4">
          <h2 className="text-sm font-black t-main">संपर्क करें</h2>
          <p className="text-xs t-sub mt-0.5">अंकुर ड्राई आइस एंड इवेंट्स, लखनऊ · {BUSINESS_PHONE_DISPLAY}</p>
          <div className="grid grid-cols-2 gap-2.5 mt-3">
            <a href={BUSINESS_CALL_HREF} className="focus-ring min-h-11 rounded-xl border-2 b-brand t-brand text-sm font-extrabold flex items-center justify-center gap-2">
              <Phone className="w-4 h-4" /> कॉल
            </a>
            <a
              href={BUSINESS_WHATSAPP_BASE}
              target="_blank"
              rel="noopener noreferrer"
              className="focus-ring min-h-11 rounded-xl c-brand text-sm font-extrabold flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" /> WhatsApp
            </a>
          </div>
        </section>

        {currentUser && (
          <button
            type="button"
            onClick={() => signOutUser()}
            className="focus-ring w-full min-h-11 rounded-xl border b-line c-card t-sub text-sm font-bold flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut className="w-4 h-4" /> लॉगआउट
          </button>
        )}
      </div>
    </div>
  );
};

export default ProfileTab;
