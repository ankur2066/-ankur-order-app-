import React from 'react';
import { Snowflake, CircleDot, Box, PartyPopper, Package, Tag, LayoutGrid } from 'lucide-react';

export const CATEGORY_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  all: LayoutGrid,
  dry_ice: Snowflake,
  pellets: CircleDot,
  blocks: Box,
  event_packs: PartyPopper,
  accessories: Package,
};

export function CategoryIcon({ id, className }: { id: string; className?: string }) {
  const Icon = CATEGORY_ICONS[id] || Tag;
  return <Icon className={className} />;
}
