import React, { useEffect } from 'react';
import { BellRing, X } from 'lucide-react';
import type { AppNotice } from '../../hooks/useOrderNotifications';

interface NotificationSheetProps {
  open: boolean;
  notices: AppNotice[];
  onClose: () => void;
  onMarkAllRead: () => void;
}

function timeLabel(ms: number): string {
  try {
    return new Date(ms).toLocaleString('hi-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

export const NotificationSheet: React.FC<NotificationSheetProps> = ({ open, notices, onClose, onMarkAllRead }) => {
  useEffect(() => {
    if (open) onMarkAllRead();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-end bg-black/45" onClick={onClose} role="presentation">
      <div
        role="dialog"
        aria-modal="true"
        aria-label="ऑर्डर अपडेट"
        className="w-full max-w-lg mx-auto c-card rounded-t-3xl p-4 max-h-[72vh] overflow-y-auto bottom-nav-safe"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-black t-main flex items-center gap-2">
            <BellRing className="w-5 h-5 t-brand" />
            ऑर्डर अपडेट
          </h2>
          <button type="button" onClick={onClose} className="focus-ring w-9 h-9 rounded-full c-soft t-brand flex items-center justify-center cursor-pointer" aria-label="बंद करें">
            <X className="w-5 h-5" />
          </button>
        </div>

        {notices.length === 0 ? (
          <p className="text-sm t-sub leading-relaxed py-6 text-center">
            अभी कोई अपडेट नहीं है। ऐप खुला रहने पर ऑर्डर की स्थिति बदलते ही यहाँ दिखेगी।
            ऐप बंद होने पर सूचना नहीं आती।
          </p>
        ) : (
          <ul className="space-y-2">
            {notices.map((n) => (
              <li key={n.id} className="rounded-xl border b-line p-3">
                <div className="text-sm font-extrabold t-main">{n.title}</div>
                <div className="text-xs t-sub mt-0.5 leading-relaxed">{n.body}</div>
                <div className="text-[11px] t-sub mt-1">
                  ऑर्डर {n.orderId} · {timeLabel(n.at)}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default NotificationSheet;
