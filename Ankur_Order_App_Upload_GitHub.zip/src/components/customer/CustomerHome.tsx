import React, { useMemo, useState } from 'react';
import { Bell, Clock, MapPin, PartyPopper, Phone, RotateCcw, Search, Truck, User as UserIcon, X } from 'lucide-react';
import type { User } from 'firebase/auth';
import type { LuckyWinner, Order, ProductItem, PromoAction, PromoBanner, RateSettings } from '../../types';
import { categoryLabel, displayPricePerKg } from '../../data/catalog';
import { getDispatchSlots } from '../../data/products';
import { readPlacedOrders } from '../../hooks/useOrderNotifications';
import { BrandMark } from './BrandMark';
import { CategoryIcon } from './categoryIcons';
import { LuckyWinnerCard } from './LuckyWinnerCard';
import { ProductCard } from './ProductCard';
import { PromoCarousel } from './PromoCarousel';

interface CustomerHomeProps {
  products: ProductItem[];
  productsLoading: boolean;
  productsError: string | null;
  rates: RateSettings;
  banners: PromoBanner[];
  winner: LuckyWinner | null;
  currentUser: User | null;
  unreadCount: number;
  onOpenNotifications: () => void;
  onOpenProfile: () => void;
  onBook: (product: ProductItem | null) => void;
  onReorder: (order: Order) => void;
  onPromoAction: (action: PromoAction) => void;
}

export const CustomerHome: React.FC<CustomerHomeProps> = ({
  products,
  productsLoading,
  productsError,
  rates,
  banners,
  winner,
  currentUser,
  unreadCount,
  onOpenNotifications,
  onOpenProfile,
  onBook,
  onReorder,
  onPromoAction,
}) => {
  const [query, setQuery] = useState('');
  const [activeCat, setActiveCat] = useState('all');

  const categories = useMemo(() => {
    const ids: string[] = [];
    products.forEach((p) => {
      if (p.category && !ids.includes(p.category)) ids.push(p.category);
    });
    return ids;
  }, [products]);

  // If the active category disappears (owner disabled its last product), fall back to "all".
  const effectiveCat = activeCat === 'all' || categories.includes(activeCat) ? activeCat : 'all';

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (effectiveCat !== 'all' && p.category !== effectiveCat) return false;
      if (!q) return true;
      return [p.name, p.hindiName, p.description || '', categoryLabel(p.category)].join(' ').toLowerCase().includes(q);
    });
  }, [products, effectiveCat, query]);

  const featured = useMemo(() => products.filter((p) => !!p.badge).slice(0, 8), [products]);

  const nextSlot = useMemo(() => getDispatchSlots().find((s) => !s.disabled), []);

  const lastOrder = useMemo(() => {
    const list = readPlacedOrders();
    return list.length > 0 ? (list[list.length - 1] as Order) : null;
  }, []);

  const tiles: { label: string; Icon: React.ComponentType<{ className?: string }>; action: () => void }[] = [
    { label: 'आज की बुकिंग', Icon: Clock, action: () => onBook(null) },
    { label: 'शादी / इवेंट', Icon: PartyPopper, action: () => onPromoAction('order') },
    { label: 'बस पार्सल', Icon: Truck, action: () => onPromoAction('whatsapp') },
    { label: 'थोक / कॉल', Icon: Phone, action: () => onPromoAction('call') },
  ];

  const searching = query.trim().length > 0;

  return (
    <div className="c-app min-h-screen page-with-bottom-nav">
      {/* ===== Hero header ===== */}
      <header className="frost-hero text-white rounded-b-[28px] pb-3" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
        <div className="px-4 pt-4 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-[12px] font-bold opacity-90">
              <BrandMark className="w-4 h-4" />
              <span>अंकुर ड्राई आइस एंड इवेंट्स</span>
            </div>
            <h1 className="text-[27px] leading-[1.15] font-black mt-1.5">
              ऑर्डर आज,
              <br />
              ठंडक समय पर
            </h1>
            <div className="mt-2 flex flex-wrap items-center gap-x-2.5 gap-y-1.5">
              <span className="inline-flex items-center gap-1 bg-white/15 rounded-full px-2.5 py-1 text-[11px] font-bold">
                <Clock className="w-3.5 h-3.5" />
                {nextSlot ? `अगला स्लॉट: ${nextSlot.label}` : 'कल के स्लॉट खुले हैं'}
              </span>
              <span className="inline-flex items-center gap-1 text-[12px] opacity-90">
                <MapPin className="w-3.5 h-3.5" />
                लखनऊ से पूरे उत्तर प्रदेश में
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenNotifications}
              className="focus-ring relative w-10 h-10 rounded-full bg-white/15 flex items-center justify-center cursor-pointer"
              aria-label={unreadCount > 0 ? `${unreadCount} नए अपडेट` : 'ऑर्डर अपडेट'}
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-[10px] font-black flex items-center justify-center">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={onOpenProfile}
              className="focus-ring w-10 h-10 rounded-full bg-white/15 flex items-center justify-center overflow-hidden cursor-pointer"
              aria-label="प्रोफ़ाइल"
            >
              {currentUser?.photoURL ? (
                <img src={currentUser.photoURL} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <UserIcon className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="px-4 mt-4">
          <label className="flex items-center gap-2.5 bg-white rounded-2xl h-12 px-3.5 text-slate-900 shadow-sm">
            <Search className="w-5 h-5 text-slate-500 shrink-0" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder='खोजें "ड्राई आइस पेलेट्स"'
              className="flex-1 min-w-0 bg-transparent outline-none text-[15px] placeholder:text-slate-500"
              style={{ backgroundColor: 'transparent', color: '#0F172A' }}
              aria-label="प्रोडक्ट खोजें"
            />
            {query && (
              <button type="button" onClick={() => setQuery('')} className="focus-ring w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center cursor-pointer" aria-label="खोज साफ़ करें">
                <X className="w-4 h-4 text-slate-600" />
              </button>
            )}
          </label>
        </div>

        {/* Category strip */}
        <div className="no-scrollbar mt-3.5 flex overflow-x-auto px-2" role="tablist" aria-label="कैटेगरी">
          {['all', ...categories].map((id) => {
            const selected = effectiveCat === id;
            return (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => setActiveCat(id)}
                className="focus-ring shrink-0 min-w-[74px] px-2 pt-1 pb-2 flex flex-col items-center gap-1 cursor-pointer"
              >
                <CategoryIcon id={id} className={`w-[26px] h-[26px] ${selected ? 'opacity-100' : 'opacity-75'}`} />
                <span className={`text-[12px] leading-none ${selected ? 'font-black' : 'font-semibold opacity-85'}`}>
                  {id === 'all' ? 'सभी' : categoryLabel(id)}
                </span>
                <span className={`h-[3px] w-8 rounded-full mt-0.5 ${selected ? 'bg-white' : 'bg-transparent'}`} />
              </button>
            );
          })}
        </div>
      </header>

      <main className="pt-4 space-y-5">
        {!searching && (
          <>
            {/* Quick actions */}
            <section className="px-4" aria-label="जल्दी शुरू करें">
              <ul className="grid grid-cols-4 gap-2.5">
                {tiles.map(({ label, Icon, action }) => (
                  <li key={label}>
                    <button
                      type="button"
                      onClick={action}
                      className="focus-ring w-full c-card border b-line rounded-2xl px-1.5 py-3 flex flex-col items-center gap-2 cursor-pointer"
                    >
                      <span className="w-11 h-11 rounded-xl c-soft t-brand flex items-center justify-center">
                        <Icon className="w-6 h-6" />
                      </span>
                      <span className="text-[12px] font-extrabold t-main leading-tight text-center">{label}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </section>

            <PromoCarousel banners={banners} onAction={onPromoAction} />

            {winner && <LuckyWinnerCard winner={winner} />}

            {lastOrder && lastOrder.orderId && (
              <section className="mx-4 c-card border b-line rounded-2xl p-3.5 flex items-center gap-3" aria-label="फिर से ऑर्डर करें">
                <div className="w-11 h-11 shrink-0 rounded-xl c-soft t-brand flex items-center justify-center">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[13px] font-extrabold t-main">पिछला ऑर्डर फिर से मँगाएँ</div>
                  <div className="text-[12px] t-sub truncate">
                    {lastOrder.quantityKg} kg{lastOrder.district ? ` · ${lastOrder.district}` : ''}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onReorder(lastOrder)}
                  className="focus-ring shrink-0 min-h-10 px-4 rounded-xl c-brand text-[13px] font-extrabold cursor-pointer"
                >
                  रीऑर्डर
                </button>
              </section>
            )}

            {featured.length > 0 && effectiveCat === 'all' && (
              <section aria-label="खास पसंद">
                <h2 className="px-4 text-[17px] font-black t-main mb-2.5">खास पसंद</h2>
                <div className="snap-rail no-scrollbar flex gap-3 overflow-x-auto px-4">
                  {featured.map((p) => (
                    <ProductCard key={p.id} product={p} pricePerKg={displayPricePerKg(p, rates)} onBook={onBook} compact />
                  ))}
                </div>
              </section>
            )}
          </>
        )}

        {/* ===== Product grid ===== */}
        <section className="px-4" aria-label="प्रोडक्ट">
          <h2 className="text-[17px] font-black t-main mb-2.5">
            {searching ? `“${query.trim()}” के नतीजे` : effectiveCat === 'all' ? 'सभी प्रोडक्ट' : categoryLabel(effectiveCat)}
          </h2>

          {productsLoading ? (
            <div className="grid grid-cols-2 gap-3" aria-busy="true">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="c-card border b-line rounded-2xl h-56 animate-pulse" />
              ))}
            </div>
          ) : visible.length > 0 ? (
            <div className="grid grid-cols-2 gap-3">
              {visible.map((p) => (
                <ProductCard key={p.id} product={p} pricePerKg={displayPricePerKg(p, rates)} onBook={onBook} />
              ))}
            </div>
          ) : (
            <div className="c-card border b-line rounded-2xl p-6 text-center">
              <p className="text-sm font-bold t-main">
                {searching ? 'इस नाम का कोई प्रोडक्ट नहीं मिला।' : 'अभी कोई प्रोडक्ट उपलब्ध नहीं है।'}
              </p>
              <p className="text-xs t-sub mt-1">
                {productsError || 'सीधे बुकिंग करें या कॉल करके अपनी ज़रूरत बताएँ।'}
              </p>
              <div className="mt-4 flex gap-2 justify-center">
                <button type="button" onClick={() => onBook(null)} className="focus-ring min-h-11 px-5 rounded-xl c-brand text-sm font-extrabold cursor-pointer">
                  ड्राई आइस बुक करें
                </button>
                <button type="button" onClick={() => onPromoAction('call')} className="focus-ring min-h-11 px-5 rounded-xl border-2 b-brand t-brand text-sm font-extrabold cursor-pointer">
                  कॉल करें
                </button>
              </div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
};

export default CustomerHome;
