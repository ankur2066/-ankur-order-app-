import React from 'react';
import { Snowflake } from 'lucide-react';
import type { ProductItem } from '../../types';

interface ProductCardProps {
  product: ProductItem;
  pricePerKg: number;
  onBook: (product: ProductItem) => void;
  compact?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, pricePerKg, onBook, compact }) => {
  const [imgFailed, setImgFailed] = React.useState(false);
  const showImage = !!product.imageUrl && !imgFailed;
  const mrp = product.mrpPerKg && product.mrpPerKg > pricePerKg ? product.mrpPerKg : null;

  return (
    <article className={`c-card border b-line rounded-2xl overflow-hidden flex flex-col ${compact ? 'w-[148px] shrink-0' : ''}`}>
      <div className="relative aspect-square c-soft flex items-center justify-center">
        {showImage ? (
          <img
            src={product.imageUrl}
            alt={product.hindiName}
            loading="lazy"
            onError={() => setImgFailed(true)}
            className="w-full h-full object-cover"
          />
        ) : (
          <Snowflake className="w-12 h-12 t-brand opacity-70" aria-hidden="true" />
        )}
        {product.badge && (
          <span className="absolute top-2 left-2 text-[10px] font-extrabold px-2 py-0.5 rounded-full c-brand">{product.badge}</span>
        )}
      </div>

      <div className="p-2.5 flex flex-col flex-1">
        <h3 className="text-[13px] font-extrabold t-main leading-snug line-clamp-2">{product.hindiName}</h3>
        <p className="text-[11px] t-sub mt-0.5 line-clamp-1">{product.description || product.name}</p>

        <div className="mt-auto pt-2.5 flex items-end justify-between gap-2">
          <div className="min-w-0">
            <div className="text-[15px] font-black t-main leading-none">
              ₹{pricePerKg}
              <span className="text-[11px] font-semibold t-sub">/{product.unit || 'kg'}</span>
            </div>
            {mrp && <div className="text-[11px] t-sub line-through mt-0.5">₹{mrp}</div>}
          </div>
          <button
            type="button"
            onClick={() => onBook(product)}
            className="focus-ring shrink-0 min-h-9 px-3.5 rounded-lg border-2 b-brand t-brand text-[12px] font-extrabold cursor-pointer"
            aria-label={`${product.hindiName} बुक करें`}
          >
            बुक करें
          </button>
        </div>
        <p className="text-[10px] t-sub mt-1.5">थर्मोकोल पैकिंग सहित</p>
      </div>
    </article>
  );
};

export default ProductCard;
