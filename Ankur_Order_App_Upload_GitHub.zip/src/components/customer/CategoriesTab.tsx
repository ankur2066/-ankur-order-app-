import React, { useMemo } from 'react';
import type { ProductItem, RateSettings } from '../../types';
import { categoryLabel, displayPricePerKg } from '../../data/catalog';
import { CategoryIcon } from './categoryIcons';
import { ProductCard } from './ProductCard';

interface CategoriesTabProps {
  products: ProductItem[];
  loading: boolean;
  rates: RateSettings;
  selected: string;
  onSelect: (id: string) => void;
  onBook: (product: ProductItem | null) => void;
}

export const CategoriesTab: React.FC<CategoriesTabProps> = ({ products, loading, rates, selected, onSelect, onBook }) => {
  const categories = useMemo(() => {
    const ids: string[] = [];
    products.forEach((p) => {
      if (p.category && !ids.includes(p.category)) ids.push(p.category);
    });
    return ids;
  }, [products]);

  const current = selected === 'all' || categories.includes(selected) ? selected : 'all';
  const list = current === 'all' ? products : products.filter((p) => p.category === current);
  const rail = ['all', ...categories];

  return (
    <div className="c-app min-h-screen page-with-bottom-nav">
      <header className="c-card border-b b-line px-4 pb-3 sticky top-0 z-30" style={{ paddingTop: 'calc(env(safe-area-inset-top, 0px) + 14px)' }}>
        <h1 className="text-xl font-black t-main">कैटेगरी</h1>
        <p className="text-xs t-sub mt-0.5">सिर्फ़ वही प्रोडक्ट दिखते हैं जो अभी उपलब्ध हैं।</p>
      </header>

      <div className="flex">
        <nav className="w-[92px] shrink-0 c-card border-r b-line min-h-[calc(100vh-120px)]" aria-label="कैटेगरी सूची">
          {rail.map((id) => {
            const isActive = current === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => onSelect(id)}
                aria-current={isActive ? 'true' : undefined}
                className={`focus-ring relative w-full px-1.5 py-3.5 flex flex-col items-center gap-1.5 cursor-pointer ${isActive ? 'c-soft' : ''}`}
              >
                {isActive && <span className="absolute left-0 top-2 bottom-2 w-[4px] rounded-r-full" style={{ background: 'var(--brand)' }} />}
                <CategoryIcon id={id} className={`w-6 h-6 ${isActive ? 't-brand' : 't-sub'}`} />
                <span className={`text-[12px] text-center leading-tight ${isActive ? 'font-extrabold t-main' : 'font-semibold t-sub'}`}>
                  {id === 'all' ? 'सभी' : categoryLabel(id)}
                </span>
              </button>
            );
          })}
        </nav>

        <section className="flex-1 min-w-0 p-3" aria-label="प्रोडक्ट">
          <h2 className="text-[15px] font-black t-main mb-2.5">{current === 'all' ? 'सभी प्रोडक्ट' : categoryLabel(current)}</h2>
          {loading ? (
            <div className="grid grid-cols-2 gap-2.5" aria-busy="true">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="c-card border b-line rounded-2xl h-52 animate-pulse" />
              ))}
            </div>
          ) : list.length === 0 ? (
            <div className="c-card border b-line rounded-2xl p-5 text-center">
              <p className="text-sm font-bold t-main">इस कैटेगरी में अभी कुछ उपलब्ध नहीं है।</p>
              <button type="button" onClick={() => onBook(null)} className="focus-ring mt-3 min-h-11 px-5 rounded-xl c-brand text-sm font-extrabold cursor-pointer">
                ड्राई आइस बुक करें
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5">
              {list.map((p) => (
                <ProductCard key={p.id} product={p} pricePerKg={displayPricePerKg(p, rates)} onBook={onBook} />
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default CategoriesTab;
