import React, { useState, useEffect } from 'react';
import { collection, addDoc, query, orderBy, onSnapshot, serverTimestamp, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { Plus, Trash2, Calendar } from 'lucide-react';

export interface Expense {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: any;
}

export const ExpensesView: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Transport');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'expenses'), orderBy('date', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setExpenses(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Expense)));
    });
    return () => unsubscribe();
  }, []);

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || isNaN(Number(amount))) return;
    try {
      setLoading(true);
      await addDoc(collection(db, 'expenses'), {
        amount: Number(amount),
        category,
        description,
        date: serverTimestamp(),
      });
      setAmount('');
      setDescription('');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteExpense = async (id: string) => {
    await deleteDoc(doc(db, 'expenses', id));
  };

  return (
    <div className="p-4 bg-white rounded-xl border border-slate-200">
      <h3 className="text-lg font-bold mb-4">खर्च ट्रैकिंग (Expense Tracking)</h3>
      <form onSubmit={handleAddExpense} className="flex flex-col gap-2 mb-4">
        <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="राशि (Amount)" className="p-2 border rounded" required />
        <select value={category} onChange={e => setCategory(e.target.value)} className="p-2 border rounded">
          <option>Transport</option>
          <option>Dry Ice Purchase</option>
          <option>Other</option>
        </select>
        <input type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder="विवरण (Description)" className="p-2 border rounded" />
        <button type="submit" className="bg-sky-600 text-white p-2 rounded" disabled={loading}>खर्च जोड़ें</button>
      </form>
      <div className="space-y-2">
        {expenses.map(exp => (
          <div key={exp.id} className="flex justify-between items-center p-2 border-b">
            <div>
              <p className="font-bold">₹{exp.amount} - {exp.category}</p>
              <p className="text-sm text-slate-500">{exp.description}</p>
            </div>
            <button onClick={() => handleDeleteExpense(exp.id)} className="text-rose-500"><Trash2 className="w-4 h-4" /></button>
          </div>
        ))}
      </div>
    </div>
  );
};
