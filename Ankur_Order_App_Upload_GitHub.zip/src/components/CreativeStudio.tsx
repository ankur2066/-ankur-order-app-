import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Sparkles, 
  Wand2, 
  Download, 
  Share2, 
  Loader2, 
  Flame, 
  Heart,
  Crown,
  Play, 
  Pause, 
  Video,
  Layers,
  Music,
  Sliders,
  Calendar,
  MapPin,
  Building,
  RefreshCw,
  PartyPopper,
  Zap,
  Copy,
  Check,
  Upload,
  Image as ImageIcon,
  UserCheck,
  X
} from 'lucide-react';
import type { User } from 'firebase/auth';
import { generateWeddingStageSvg, generateWeddingStageDataUrl } from '../utils/weddingStageGenerator';

interface WeddingTheme {
  id: 'varmala' | 'cloud-dance' | 'pyro-blast' | 'sangeet' | 'baraat' | 'doli';
  title: string;
  badge: string;
  badgeColor: string;
  icon: any;
  accentGradient: string;
  description: string;
  defaultPrompt: string;
}

const WEDDING_THEMES: WeddingTheme[] = [
  {
    id: 'varmala',
    title: 'शाही वरमाला स्टेज एंट्री',
    badge: '★ सुपर हिट',
    badgeColor: 'bg-amber-400 text-rose-950',
    icon: Crown,
    accentGradient: 'from-amber-500 via-rose-600 to-amber-600',
    description: 'रॉयल पैलेस मंडप, सुनहरी मेहराब, वरमाला और भारी घना सफेद क्लाउड फॉग',
    defaultPrompt: 'Royal Indian wedding stage with grand floral mandap arch, bride and groom varmala ceremony surrounded by rolling low-lying stage cloud fog and golden spotlights'
  },
  {
    id: 'cloud-dance',
    title: 'जयमाला क्लाउड डांस',
    badge: '♥ रोमांटिक एंट्री',
    badgeColor: 'bg-rose-500 text-white',
    icon: Heart,
    accentGradient: 'from-purple-600 via-pink-600 to-rose-600',
    description: 'बादलों पर चलने जैसा दिव्य एहसास (Walking on Clouds) और तारों भरी लाइटिंग',
    defaultPrompt: 'Romantic Indian couple first dance on stage covered in thick sea of white clouds low-fog with starry golden chandeliers and soft violet ambient glow'
  },
  {
    id: 'pyro-blast',
    title: 'कोल्ड पायरो आतिशबाजी',
    badge: '⚡ फुल धमाका',
    badgeColor: 'bg-amber-500 text-black',
    icon: Flame,
    accentGradient: 'from-orange-500 via-amber-500 to-red-600',
    description: 'स्टेज के दोनों पंखों से आसमान छूती सुरक्षित इनडोर गोल्डन स्पार्कलर आतिशबाजी',
    defaultPrompt: 'High energy wedding stage with indoor cold pyro sparkler fountains shooting high into the air with dense stage cloud fog billowing across stage floor'
  },
  {
    id: 'sangeet',
    title: 'संगीत & डीजे लेज़र शो',
    badge: '♫ पार्टी स्पेशल',
    badgeColor: 'bg-cyan-400 text-slate-950',
    icon: Music,
    accentGradient: 'from-cyan-500 via-indigo-600 to-purple-600',
    description: 'इलेक्ट्रिक नियॉन लेज़र बीम्स, पार्टी लाइट्स और स्विरलिंग स्मोक इफेक्ट्स',
    defaultPrompt: 'Vibrant wedding sangeet party stage with colorful neon laser beams, DJ setup, and rolling fog clouds for high energy dance performances'
  },
  {
    id: 'baraat',
    title: 'रॉयल बारात & दूल्हा एंट्री',
    badge: '👑 शाही ठाठ',
    badgeColor: 'bg-amber-300 text-amber-950',
    icon: PartyPopper,
    accentGradient: 'from-red-600 via-amber-600 to-red-700',
    description: 'विंटेज बग्गी / रॉयल कार के साथ दूल्हे की बादलों के बीच रोबदार ग्रैंड एंट्री',
    defaultPrompt: 'Majestic Indian groom royal baraat grand entry enveloped in thick dense white stage cloud fog with cold fireworks lighting up the night'
  },
  {
    id: 'doli',
    title: 'दुल्हन डोली स्मोक वॉक',
    badge: '✨ परीकथा एंट्री',
    badgeColor: 'bg-pink-400 text-pink-950',
    icon: Sparkles,
    accentGradient: 'from-pink-500 via-rose-500 to-purple-600',
    description: 'फूलों की चादर और डोली के नीचे तैरता हुआ प्योर वाइट ड्रीम क्लाउड वॉक',
    defaultPrompt: 'Fairytale bride entry under floral chadar and doli walking on pure white dense low-fog clouds with warm golden lighting'
  }
];

interface CreativeStudioProps {
  currentUser?: User | null;
}

export const CreativeStudio: React.FC<CreativeStudioProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'video-sim' | 'upload-media'>('video-sim');
  const [selectedTheme, setSelectedTheme] = useState<'varmala' | 'cloud-dance' | 'pyro-blast' | 'sangeet' | 'baraat' | 'doli'>('varmala');
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '9:16' | '16:9'>('1:1');

  // Dynamic user branding defaults
  const isOwnerAnkur = currentUser?.email === 'ankurdryicewholesalers@gmail.com';
  const defaultFirmName = isOwnerAnkur 
    ? 'अंकुर ड्राई आइस & स्पेशल इवेंट्स' 
    : (currentUser?.displayName || (currentUser?.email ? currentUser.email.split('@')[0].toUpperCase() + ' EVENTS' : 'SHARMA EVENTS & WEDDINGS'));

  // Customer Personalization State
  const [groomBrideName, setGroomBrideName] = useState('रोहन 💖 अंजलि');
  const [backdropBanner, setBackdropBanner] = useState('THE GRAND ROYAL WEDDING');
  const [firmOrFamilyName, setFirmOrFamilyName] = useState(defaultFirmName);
  const [eventDate, setEventDate] = useState('28 नवम्बर 2026');
  const [venue, setVenue] = useState('गोरखपुर पैलेस');
  const [namePosition, setNamePosition] = useState<'backdrop' | 'arch' | 'golden-board'>('backdrop');
  const [prompt, setPrompt] = useState(WEDDING_THEMES[0].defaultPrompt);

  // User Upload State (Customer can upload their own wedding stage photo or video)
  const [userUploadedPhoto, setUserUploadedPhoto] = useState<string | null>(null);
  const [userUploadedVideo, setUserUploadedVideo] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Output State
  const [resultSvg, setResultSvg] = useState<string | null>(null);
  const [resultImg, setResultImg] = useState<string | null>(null);
  const [isAiGenerated, setIsAiGenerated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [recordingVideo, setRecordingVideo] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState(false);

  // Video Simulator Canvas State
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoPlayerRef = useRef<HTMLVideoElement | null>(null);
  const [simPlaying, setSimPlaying] = useState(true);
  const [simFogLevel, setSimFogLevel] = useState<'medium' | 'dense' | 'ultra-cloud'>('dense');
  const [simLighting, setSimLighting] = useState<'royal-gold' | 'romantic-violet' | 'crimson-fire' | 'sapphire-blue'>('royal-gold');
  const [simShowPyros, setSimShowPyros] = useState(true);

  // Sync default firm name if user changes
  useEffect(() => {
    if (currentUser) {
      if (currentUser.email === 'ankurdryicewholesalers@gmail.com') {
        setFirmOrFamilyName('अंकुर ड्राई आइस & स्पेशल इवेंट्स');
      } else if (currentUser.displayName) {
        setFirmOrFamilyName(currentUser.displayName + ' EVENTS');
      }
    }
  }, [currentUser]);

  // Generate / Update current wedding stage visual (instant client-side)
  const refreshStageGraphic = useCallback((themeOverride?: 'varmala' | 'cloud-dance' | 'pyro-blast' | 'sangeet' | 'baraat' | 'doli') => {
    try {
      const theme = themeOverride || selectedTheme;
      const svg = generateWeddingStageSvg({
        prompt,
        theme,
        aspectRatio,
        groomBrideName: groomBrideName.trim() || 'रोहन 💖 अंजलि',
        backdropBanner: backdropBanner.trim() || 'शुभ विवाह',
        firmOrFamilyName: firmOrFamilyName.trim() || defaultFirmName,
        eventDate: eventDate.trim() || undefined,
        venue: venue.trim() || undefined,
        userPhotoUrl: userUploadedPhoto,
        namePosition
      });
      setResultSvg(svg);
      setResultImg(null);
      setIsAiGenerated(false);
    } catch (err) {
      console.error('Failed to generate wedding graphic:', err);
    }
  }, [selectedTheme, prompt, aspectRatio, groomBrideName, backdropBanner, firmOrFamilyName, eventDate, venue, userUploadedPhoto, namePosition, defaultFirmName]);

  // Initial load
  useEffect(() => {
    refreshStageGraphic('varmala');
  }, []);

  // When theme changes
  const handleThemeChange = (theme: WeddingTheme) => {
    setSelectedTheme(theme.id);
    setPrompt(theme.defaultPrompt);
    refreshStageGraphic(theme.id);
    setStatusMessage(`👑 ${theme.title} थीम लागू हो गई!`);
    setTimeout(() => setStatusMessage(null), 2500);
  };

  // Handle Photo/Video Upload from Device
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type.startsWith('video/')) {
      const videoUrl = URL.createObjectURL(file);
      setUserUploadedVideo(videoUrl);
      setUserUploadedPhoto(null);
      setActiveTab('video-sim');
      setStatusMessage('🎬 आपका वीडियो सफलतापूर्वक लोड हो गया!');
      setTimeout(() => setStatusMessage(null), 3000);
    } else {
      // Standalone photo output was removed: this studio is video-only.
      // (A reference photo can be attached in the "AI वीडियो (सर्वर)" tab instead.)
      setStatusMessage('यहाँ सिर्फ़ वीडियो अपलोड होता है। फोटो को रेफ़रेंस के रूप में AI वीडियो टैब में जोड़ें।');
      setTimeout(() => setStatusMessage(null), 3500);
    }
  };
  // Export a short recording of the existing canvas animation (not Gemini video generation).
  const handleDownloadVideo = async () => {
    const canvas = canvasRef.current;
    if (!canvas || userUploadedVideo || recordingVideo) return;
    if (typeof MediaRecorder === 'undefined' || typeof canvas.captureStream !== 'function') {
      setStatusMessage('इस डिवाइस में वीडियो रिकॉर्डिंग उपलब्ध नहीं है। Chrome में कोशिश करें।');
      return;
    }
    const mimeType = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm']
      .find(type => MediaRecorder.isTypeSupported(type));
    if (!mimeType) {
      setStatusMessage('इस ब्राउज़र में WebM वीडियो डाउनलोड समर्थित नहीं है।');
      return;
    }
    const stream = canvas.captureStream(30);
    const chunks: BlobPart[] = [];
    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 2500000 });
      recorder.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
      recorder.onerror = () => {
        setStatusMessage('वीडियो रिकॉर्डिंग में त्रुटि आई।');
        setRecordingVideo(false);
        stream.getTracks().forEach(t => t.stop());
      };
      recorder.onstop = () => {
        stream.getTracks().forEach(t => t.stop());
        setRecordingVideo(false);
        if (!chunks.length) { setStatusMessage('वीडियो रिकॉर्ड नहीं हो सका।'); return; }
        const url = URL.createObjectURL(new Blob(chunks, { type: mimeType }));
        const link = document.createElement('a');
        link.href = url;
        link.download = `ankur-event-preview-${Date.now()}.webm`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 60000);
        setStatusMessage('वीडियो डाउनलोड शुरू हो गया है (WebM)।');
      };
      setSimPlaying(true);
      setRecordingVideo(true);
      recorder.start(1000);
      setStatusMessage('15 सेकंड का वीडियो रिकॉर्ड हो रहा है…');
      setTimeout(() => { if (recorder.state === 'recording') recorder.stop(); }, 15000);
    } catch {
      stream.getTracks().forEach(t => t.stop());
      setRecordingVideo(false);
      setStatusMessage('वीडियो रिकॉर्डिंग शुरू नहीं हो सकी।');
    }
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(
      `👑 *${groomBrideName} - शाही वेडिंग स्टेज स्पेशल*\n` +
      `✨ *${backdropBanner}*\n` +
      `📅 तारीख: ${eventDate}\n` +
      `📍 वेन्यू: ${venue}\n` +
      `🎉 ${firmOrFamilyName}\n\n` +
      `🌟 भव्य लो-फॉग एंट्री, जयमाला क्लाउड डांस और कोल्ड पायरो स्पेशल इफेक्ट्स!`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  // Copy Wedding Details
  const handleCopyDetails = () => {
    const text = `${groomBrideName} • ${backdropBanner} • ${eventDate} • ${venue} • ${firmOrFamilyName}`;
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // 60 FPS Wedding Stage Simulator Canvas Animation Loop (with detailed couple, guests, falling petals, and smoke)
  useEffect(() => {
    if (userUploadedVideo) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const width = (canvas.width = 800);
    const height = (canvas.height = 450);

    let sweepAngle = 0;
    let petalStep = 0;

    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      alpha: number;
      maxAlpha: number;
    }

    interface PyroSpark {
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
      maxLife: number;
      color: string;
    }

    interface Petal {
      x: number;
      y: number;
      vx: number;
      vy: number;
      rot: number;
      vrot: number;
      color: string;
    }

    const smokeParticles: Particle[] = [];
    const sparkParticles: PyroSpark[] = [];
    const fallingPetals: Petal[] = [];

    const densityMap = {
      'medium': 14,
      'dense': 26,
      'ultra-cloud': 42
    };
    const density = densityMap[simFogLevel];

    const lightingMap = {
      'royal-gold': { bg1: '#260408', bg2: '#4a0815', beam1: '#fbbf24', beam2: '#f59e0b', glow: '#fef08a' },
      'romantic-violet': { bg1: '#140321', bg2: '#380954', beam1: '#c084fc', beam2: '#e879f9', glow: '#f5d0fe' },
      'crimson-fire': { bg1: '#240602', bg2: '#541207', beam1: '#f97316', beam2: '#ef4444', glow: '#fed7aa' },
      'sapphire-blue': { bg1: '#020e26', bg2: '#0b2352', beam1: '#38bdf8', beam2: '#818cf8', glow: '#bae6fd' },
    };

    const render = () => {
      const lights = lightingMap[simLighting];
      sweepAngle += 0.02;
      petalStep++;

      // 1. Velvet royal wedding stage backdrop
      const bg = ctx.createLinearGradient(0, 0, 0, height);
      bg.addColorStop(0, lights.bg1);
      bg.addColorStop(0.5, lights.bg2);
      bg.addColorStop(1, '#050109');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      // 2. Sweeping luxury stage lights
      ctx.save();
      const beamLX = width * 0.35 + Math.sin(sweepAngle) * 90;
      const beamL = ctx.createLinearGradient(100, 0, beamLX, height);
      beamL.addColorStop(0, lights.beam1 + '77');
      beamL.addColorStop(1, lights.beam1 + '00');
      ctx.fillStyle = beamL;
      ctx.beginPath();
      ctx.moveTo(60, 0);
      ctx.lineTo(140, 0);
      ctx.lineTo(beamLX + 60, height);
      ctx.lineTo(beamLX - 60, height);
      ctx.closePath();
      ctx.fill();

      const beamRX = width * 0.65 - Math.sin(sweepAngle) * 90;
      const beamR = ctx.createLinearGradient(width - 100, 0, beamRX, height);
      beamR.addColorStop(0, lights.beam2 + '77');
      beamR.addColorStop(1, lights.beam2 + '00');
      ctx.fillStyle = beamR;
      ctx.beginPath();
      ctx.moveTo(width - 140, 0);
      ctx.lineTo(width - 60, 0);
      ctx.lineTo(beamRX + 60, height);
      ctx.lineTo(beamRX - 60, height);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      // 3. MANDAP & STAGE BACKDROP WITH CUSTOMER'S NAME DISPLAY
      ctx.save();
      ctx.fillStyle = '#0f0518';
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(width / 2 - 230, 42, 460, 115, 14);
      ctx.fill();
      ctx.stroke();

      // Customer's Backdrop Banner
      ctx.fillStyle = '#fbcfe8';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(backdropBanner || 'शुभ विवाह', width / 2, 66);

      // Bride & Groom Names (Glowing Neon on stage LED)
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 14;
      ctx.font = 'bold 26px "Playfair Display", Georgia, sans-serif';
      ctx.fillText(groomBrideName || 'रोहन 💖 अंजलि', width / 2, 108);
      ctx.shadowBlur = 0;

      // Date on board
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(`📅 ${eventDate} • 📍 ${venue}`, width / 2, 138);
      ctx.restore();

      // Mandap Arch Outline
      ctx.strokeStyle = '#fbbf2499';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(width / 2, height - 70, 140, Math.PI, 0, false);
      ctx.stroke();

      // Mandap Pillars
      ctx.fillStyle = '#d97706';
      ctx.fillRect(width / 2 - 145, height - 180, 16, 120);
      ctx.fillRect(width / 2 + 129, height - 180, 16, 120);

      // 4. GUESTS & RELATIVES IN BACKGROUND (पीछे लोग व बाराती)
      ctx.save();
      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      // Left side guests
      ctx.beginPath();
      ctx.arc(width / 2 - 95, height - 150, 9, 0, Math.PI * 2);
      ctx.arc(width / 2 - 120, height - 146, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(236, 72, 153, 0.7)';
      ctx.fillRect(width / 2 - 102, height - 140, 14, 30);
      ctx.fillStyle = 'rgba(59, 130, 246, 0.7)';
      ctx.fillRect(width / 2 - 126, height - 137, 12, 28);

      // Right side guests
      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      ctx.beginPath();
      ctx.arc(width / 2 + 95, height - 150, 9, 0, Math.PI * 2);
      ctx.arc(width / 2 + 120, height - 146, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(16, 185, 129, 0.7)';
      ctx.fillRect(width / 2 + 88, height - 140, 14, 30);
      ctx.fillStyle = 'rgba(245, 158, 11, 0.7)';
      ctx.fillRect(width / 2 + 114, height - 137, 12, 28);
      ctx.restore();

      // 5. DETAILED WEDDING COUPLE ON STAGE (दूल्हा और दुल्हन)
      ctx.save();
      const coupleX = width / 2;
      const coupleY = height - 135;

      // Groom (Ivory Sherwani, Red Turban with Golden Kalgi)
      ctx.fillStyle = '#fed7aa';
      ctx.beginPath();
      ctx.arc(coupleX - 22, coupleY - 26, 13, 0, Math.PI * 2); // Face
      ctx.fill();
      // Red Turban / Safa
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.ellipse(coupleX - 22, coupleY - 37, 16, 9, 0, 0, Math.PI * 2);
      ctx.fill();
      // Kalgi brooch
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(coupleX - 23, coupleY - 48, 3, 10);
      // Sherwani body
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(coupleX - 32, coupleY - 13, 20, 48);
      ctx.fillStyle = '#b45309';
      ctx.fillRect(coupleX - 23, coupleY - 13, 2, 48);

      // Bride (Bridal Red Lehenga & Gold Jewelry)
      ctx.fillStyle = '#fed7aa';
      ctx.beginPath();
      ctx.arc(coupleX + 22, coupleY - 22, 12, 0, Math.PI * 2); // Face
      ctx.fill();
      // Hair Bun & Gajra
      ctx.fillStyle = '#1c1917';
      ctx.beginPath();
      ctx.arc(coupleX + 22, coupleY - 25, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(coupleX + 22, coupleY - 25, 15, 0, Math.PI * 2);
      ctx.stroke();
      // Maang Tikka
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(coupleX + 22, coupleY - 32, 2.5, 0, Math.PI * 2);
      ctx.fill();
      // Bridal Lehenga
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.moveTo(coupleX + 10, coupleY - 10);
      ctx.lineTo(coupleX + 34, coupleY - 10);
      ctx.lineTo(coupleX + 44, coupleY + 38);
      ctx.lineTo(coupleX + 0, coupleY + 38);
      ctx.closePath();
      ctx.fill();
      // Lehenga Gold Border
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(coupleX + 0, coupleY + 33, 44, 5);

      // Varmala Garland connecting them
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(coupleX, coupleY - 6, 18, 0, Math.PI, false);
      ctx.stroke();
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();

      // 6. FALLING FLOWER PETALS (पुष्प वर्षा)
      if (simPlaying) {
        if (petalStep % 6 === 0) {
          fallingPetals.push({
            x: Math.random() * width,
            y: 0,
            vx: (Math.random() - 0.5) * 1.5,
            vy: 1.5 + Math.random() * 2,
            rot: Math.random() * Math.PI,
            vrot: (Math.random() - 0.5) * 0.1,
            color: Math.random() > 0.4 ? '#f43f5e' : '#fbbf24',
          });
        }

        // Emit Dense Smoke Particles
        for (let i = 0; i < density / 4; i++) {
          smokeParticles.push({
            x: Math.random() * width,
            y: height - 10 - Math.random() * 25,
            vx: (Math.random() - 0.5) * 1.4,
            vy: -0.15 - Math.random() * 0.7,
            size: 40 + Math.random() * 65,
            alpha: 0.05,
            maxAlpha: 0.3 + Math.random() * 0.45,
          });
        }

        // Emit Active Cold Pyro Sparklers
        if (simShowPyros) {
          for (let s = 0; s < 6; s++) {
            sparkParticles.push({
              x: width * 0.18 + (Math.random() - 0.5) * 16,
              y: height - 60,
              vx: (Math.random() - 0.5) * 2.2,
              vy: -7 - Math.random() * 8,
              life: 0,
              maxLife: 22 + Math.random() * 26,
              color: Math.random() > 0.3 ? '#fef08a' : '#ffffff',
            });
            sparkParticles.push({
              x: width * 0.82 + (Math.random() - 0.5) * 16,
              y: height - 60,
              vx: (Math.random() - 0.5) * 2.2,
              vy: -7 - Math.random() * 8,
              life: 0,
              maxLife: 22 + Math.random() * 26,
              color: Math.random() > 0.3 ? '#fef08a' : '#ffffff',
            });
          }
        }
      }

      // Draw & Update Falling Flower Petals
      for (let k = fallingPetals.length - 1; k >= 0; k--) {
        const pt = fallingPetals[k];
        pt.x += pt.vx;
        pt.y += pt.vy;
        pt.rot += pt.vrot;

        ctx.save();
        ctx.translate(pt.x, pt.y);
        ctx.rotate(pt.rot);
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.ellipse(0, 0, 4.5, 2.5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        if (pt.y > height - 60) {
          fallingPetals.splice(k, 1);
        }
      }

      // Draw & Update Dense Low-Fog Smoke Clouds
      for (let i = smokeParticles.length - 1; i >= 0; i--) {
        const p = smokeParticles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.size += 0.45;
        p.alpha += 0.01;
        if (p.alpha > p.maxAlpha) p.alpha = p.maxAlpha;

        const pGrad = ctx.createRadialGradient(p.x, p.y, p.size * 0.05, p.x, p.y, p.size);
        pGrad.addColorStop(0, `rgba(255, 255, 255, ${p.alpha})`);
        pGrad.addColorStop(0.4, `rgba(240, 249, 255, ${p.alpha * 0.8})`);
        pGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');

        ctx.fillStyle = pGrad;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        if (p.y < height - 170 || p.size > 150) {
          smokeParticles.splice(i, 1);
        }
      }

      // Draw Cold Pyro Sparks
      for (let j = sparkParticles.length - 1; j >= 0; j--) {
        const sp = sparkParticles[j];
        sp.x += sp.vx;
        sp.y += sp.vy;
        sp.vy += 0.18;
        sp.life++;

        ctx.fillStyle = sp.color;
        ctx.fillRect(sp.x, sp.y, 2.5, 4.5);

        if (sp.life >= sp.maxLife) {
          sparkParticles.splice(j, 1);
        }
      }

      // Ground Dense Fog Base
      const baseFog = ctx.createLinearGradient(0, height - 75, 0, height);
      baseFog.addColorStop(0, 'rgba(255, 255, 255, 0)');
      baseFog.addColorStop(0.35, 'rgba(255, 255, 255, 0.6)');
      baseFog.addColorStop(1, 'rgba(255, 255, 255, 0.96)');
      ctx.fillStyle = baseFog;
      ctx.fillRect(0, height - 75, width, 75);

      // Bottom Custom Presenter Credit Bar
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(width / 2 - 190, height - 28, 380, 24);
      ctx.fillStyle = '#fbbf24';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`👑 ${firmOrFamilyName || defaultFirmName} 👑`, width / 2, height - 12);

      if (simPlaying) {
        animId = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [activeTab, simPlaying, simFogLevel, simLighting, simShowPyros, groomBrideName, backdropBanner, firmOrFamilyName, eventDate, venue, userUploadedVideo, defaultFirmName]);

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-4 py-4 space-y-5">
      {/* High-Contrast Luxury Header with Dynamic User Profile Badge */}
      <div className="relative overflow-hidden rounded-3xl p-5 sm:p-7 bg-gradient-to-r from-red-950 via-purple-950 to-amber-950 border-2 border-amber-400 shadow-2xl shadow-amber-900/30">
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-amber-400/40">
                <Crown className="w-4 h-4 fill-current" />
                <span>ड्राई आइस स्मोक &amp; फॉग एंट्री विज़ुअलाइज़र</span>
              </span>

              {/* Dynamic User Branding Badge */}
              <span className="px-3 py-1 rounded-full bg-slate-900/80 border border-amber-400/50 text-amber-200 text-xs font-bold flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>इवेंट प्लानर/फर्म: {isOwnerAnkur ? 'अंकुर ड्राई आइस & इवेंट्स' : (currentUser ? currentUser.displayName || 'डेकोरेटर पोर्टल' : 'डेकोरेटर पोर्टल')}</span>
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-400 tracking-tight flex items-center gap-2">
              <span>व्हाट्सएप स्टेटस के लिए स्मोक &amp; फॉग एंट्री वीडियो मेकर</span>
            </h1>

            <p className="text-xs sm:text-sm text-amber-100/90 max-w-2xl font-medium leading-relaxed">
              आप अपने क्लाइंट्स (दूल्हा-दुल्हन) के लिए <strong>ड्राई आइस फॉग, वरमाला एंट्री और कोल्ड पायरो</strong> की शानदार फोटो और वीडियो यहाँ बनाएं, जिसपर आपकी डेकोरेशन फर्म का नाम चमकता रहे ताकि क्लाइंट WhatsApp स्टेटस पर लगाकर आपका काम प्रमोट कर सकें!
            </p>
          </div>

        </div>

        {/* Ambient Glow Orbs */}
        <div className="absolute -top-12 -right-12 w-80 h-80 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-80 h-80 bg-rose-600/20 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* High-Contrast Mode Navigation */}
      <div className="grid grid-cols-2 gap-2 p-1.5 bg-slate-900/90 border-2 border-amber-500/50 rounded-2xl shadow-xl backdrop-blur-md">
        <button
          type="button"
          onClick={() => setActiveTab('video-sim')}
          className={`py-3 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all duration-300 cursor-pointer ${
            activeTab === 'video-sim'
              ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-lg shadow-amber-500/30 scale-[1.02]'
              : 'text-amber-200 hover:text-white hover:bg-white/10'
          }`}
        >
          <Video className="w-4 h-4 shrink-0" />
          <span>लाइव स्टेज वीडियो सिमुलेटर</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('upload-media')}
          className={`py-3 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all duration-300 cursor-pointer ${
            activeTab === 'upload-media'
              ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-lg shadow-amber-500/30 scale-[1.02]'
              : 'text-amber-200 hover:text-white hover:bg-white/10'
          }`}
        >
          <Upload className="w-4 h-4 shrink-0" />
          <span>अपना वीडियो अपलोड</span>
        </button>
      </div>

      {/* Status Notification Toast */}
      {statusMessage && (
        <div className="p-3.5 bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 text-xs sm:text-sm rounded-2xl flex items-center gap-2.5 animate-bounce shadow-xl font-black border-2 border-amber-200">
          <Sparkles className="w-4 h-4 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column: Personalization & Uploads */}
        <div className="lg:col-span-5 space-y-4">
          {/* UPLOAD PANEL if in upload mode */}
          {activeTab === 'upload-media' && (
            <div className="bg-slate-900/90 p-5 rounded-3xl border-2 border-amber-400 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-amber-400" />
                  <span>अपना स्टेज वीडियो अपलोड करें</span>
                </label>
              </div>

              <p className="text-xs text-amber-200/80 leading-relaxed">
                अपने मोबाइल या कंप्यूटर से अपनी स्टेज का वीडियो चुनें। उस पर आपके नाम का जगमगाता बैनर, वर-वधू का नाम और फॉग/पायरो इफेक्ट्स अपने आप फिट हो जाएंगे!
              </p>

              <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept="video/*"
                className="hidden" 
              />

              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-amber-400/60 rounded-2xl p-6 text-center hover:border-amber-400 hover:bg-amber-400/5 transition-all cursor-pointer space-y-3"
              >
                <div className="w-12 h-12 rounded-2xl bg-amber-400/10 border border-amber-400/40 text-amber-400 flex items-center justify-center mx-auto shadow-inner">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-sm font-black text-amber-300 block">वीडियो चुनने के लिए यहाँ क्लिक करें</span>
                  <span className="text-[11px] text-amber-200/60 block mt-1">MP4, MOV सपोर्टेड</span>
                </div>
              </div>

              {(userUploadedPhoto || userUploadedVideo) && (
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-amber-400/40">
                  <span className="text-xs font-bold text-amber-200 flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>{userUploadedVideo ? 'वीडियो लोड है' : 'फोटो लोड है'}</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setUserUploadedPhoto(null);
                      setUserUploadedVideo(null);
                      refreshStageGraphic();
                    }}
                    className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>हटाएं</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Wedding Themes Palette */}
          <div className="bg-slate-900/90 p-4 sm:p-5 rounded-3xl border-2 border-amber-400/40 shadow-xl space-y-3.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>1. शादी का अवसर / ग्रैंड थीम चुनें</span>
              </label>
              <span className="text-[10px] text-amber-300/80 font-bold bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/30">
                6 शाही विकल्प
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {WEDDING_THEMES.map((theme) => {
                const Icon = theme.icon;
                const isSelected = selectedTheme === theme.id;
                return (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => handleThemeChange(theme)}
                    className={`p-3 rounded-2xl border-2 text-left transition-all duration-300 cursor-pointer relative overflow-hidden group ${
                      isSelected
                        ? 'border-amber-400 bg-gradient-to-br from-amber-950/80 via-purple-950/80 to-slate-950 shadow-lg shadow-amber-500/25 scale-[1.02] ring-2 ring-amber-400/50'
                        : 'border-slate-800 bg-slate-950/60 hover:border-amber-400/60 hover:bg-slate-800/80'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                        isSelected 
                          ? 'bg-amber-400 text-slate-950 shadow-md' 
                          : 'bg-slate-800 text-amber-300 group-hover:bg-amber-400 group-hover:text-slate-950'
                      }`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full shadow-xs ${theme.badgeColor}`}>
                        {theme.badge}
                      </span>
                    </div>
                    <div className="font-black text-xs text-white leading-tight">
                      {theme.title}
                    </div>
                    <div className="text-[10px] text-amber-200/70 line-clamp-1 mt-0.5">
                      {theme.description}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Customer Personalization Panel */}
          <div className="bg-slate-900/90 p-4 sm:p-5 rounded-3xl border-2 border-amber-400/40 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-amber-400" />
                <span>2. अपना नाम व बैकड्रॉप कस्टमाइज़ करें</span>
              </label>
              <button
                type="button"
                onClick={handleCopyDetails}
                className="text-[11px] text-amber-300 hover:text-white flex items-center gap-1 cursor-pointer"
              >
                {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedText ? 'कॉपी हो गया' : 'कॉपी'}</span>
              </button>
            </div>

            {/* Couple Names */}
            <div>
              <label className="text-xs text-amber-200 font-black block mb-1.5 flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5 text-rose-400 fill-current" />
                <span>वर व वधू का नाम (Bride &amp; Groom Names):</span>
              </label>
              <input
                type="text"
                value={groomBrideName}
                onChange={(e) => {
                  setGroomBrideName(e.target.value);
                  setTimeout(refreshStageGraphic, 40);
                }}
                className="w-full p-3 text-xs sm:text-sm font-black bg-slate-950 text-amber-200 border-2 border-amber-400/50 rounded-xl focus:border-amber-400 focus:ring-2 focus:ring-amber-400 outline-none transition-all shadow-inner"
                placeholder="उदा: रोहन 💖 अंजलि / Rahul weds Simran"
              />
            </div>

            {/* Backdrop Banner Text */}
            <div>
              <label className="text-xs text-amber-200 font-black block mb-1.5 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                <span>स्टेज के पीछे LED बैकड्रॉप बैनर पर क्या लिखें?</span>
              </label>
              <input
                type="text"
                value={backdropBanner}
                onChange={(e) => {
                  setBackdropBanner(e.target.value);
                  setTimeout(refreshStageGraphic, 40);
                }}
                className="w-full p-3 text-xs sm:text-sm font-black bg-slate-950 text-amber-200 border-2 border-amber-400/50 rounded-xl focus:border-amber-400 focus:ring-2 focus:ring-amber-400 outline-none transition-all shadow-inner"
                placeholder="उदा: शुभ विवाह • THE ROYAL WEDDING"
              />
            </div>

            {/* Firm or Family Name */}
            <div>
              <label className="text-xs text-amber-200 font-black block mb-1.5 flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5 text-cyan-400" />
                <span>इवेंट प्लानर / डेकोरेटर फर्म का नाम (जो WhatsApp स्टेटस पर दिखेगा):</span>
              </label>
              <input
                type="text"
                value={firmOrFamilyName}
                onChange={(e) => {
                  setFirmOrFamilyName(e.target.value);
                  setTimeout(refreshStageGraphic, 40);
                }}
                className="w-full p-3 text-xs sm:text-sm font-black bg-slate-950 text-amber-200 border-2 border-amber-400/50 rounded-xl focus:border-amber-400 focus:ring-2 focus:ring-amber-400 outline-none transition-all shadow-inner"
                placeholder={defaultFirmName}
              />
            </div>

            {/* Date & Venue */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="text-xs text-amber-200 font-black block mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                  <span>तारीख:</span>
                </label>
                <input
                  type="text"
                  value={eventDate}
                  onChange={(e) => {
                    setEventDate(e.target.value);
                    setTimeout(refreshStageGraphic, 40);
                  }}
                  className="w-full p-2.5 text-xs sm:text-sm font-bold bg-slate-950 text-amber-100 border border-slate-700 rounded-xl focus:border-amber-400 outline-none"
                  placeholder="28 नवम्बर 2026"
                />
              </div>
              <div>
                <label className="text-xs text-amber-200 font-black block mb-1 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-400" />
                  <span>स्थान / वेन्यू:</span>
                </label>
                <input
                  type="text"
                  value={venue}
                  onChange={(e) => {
                    setVenue(e.target.value);
                    setTimeout(refreshStageGraphic, 40);
                  }}
                  className="w-full p-2.5 text-xs sm:text-sm font-bold bg-slate-950 text-amber-100 border border-slate-700 rounded-xl focus:border-amber-400 outline-none"
                  placeholder="गोरखपुर पैलेस"
                />
              </div>
            </div>

            {/* Aspect Ratio */}
            <div>
              <label className="text-xs text-amber-200 font-black block mb-1.5">
                साइज / रेश्यो (Aspect Ratio):
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setAspectRatio('1:1');
                    setTimeout(refreshStageGraphic, 40);
                  }}
                  className={`py-2 px-2 rounded-xl text-xs font-black border-2 transition-all cursor-pointer ${
                    aspectRatio === '1:1'
                      ? 'border-amber-400 bg-amber-400 text-slate-950 shadow-md scale-[1.02]'
                      : 'border-slate-800 bg-slate-950 text-amber-200 hover:border-amber-400/50'
                  }`}
                >
                  1:1 चौकोर
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAspectRatio('9:16');
                    setTimeout(refreshStageGraphic, 40);
                  }}
                  className={`py-2 px-2 rounded-xl text-xs font-black border-2 transition-all cursor-pointer ${
                    aspectRatio === '9:16'
                      ? 'border-amber-400 bg-amber-400 text-slate-950 shadow-md scale-[1.02]'
                      : 'border-slate-800 bg-slate-950 text-amber-200 hover:border-amber-400/50'
                  }`}
                >
                  9:16 स्टेटस/रील्स
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAspectRatio('16:9');
                    setTimeout(refreshStageGraphic, 40);
                  }}
                  className={`py-2 px-2 rounded-xl text-xs font-black border-2 transition-all cursor-pointer ${
                    aspectRatio === '16:9'
                      ? 'border-amber-400 bg-amber-400 text-slate-950 shadow-md scale-[1.02]'
                      : 'border-slate-800 bg-slate-950 text-amber-200 hover:border-amber-400/50'
                  }`}
                >
                  16:9 स्टेज LED
                </button>
              </div>
            </div>

          </div>

          {/* Simulator Settings (when in Video Sim Mode) */}
          {activeTab === 'video-sim' && (
            <div className="bg-slate-900/90 p-4 sm:p-5 rounded-3xl border-2 border-amber-400/40 shadow-xl space-y-3.5">
              <label className="text-xs font-black text-amber-300 uppercase tracking-wider block">
                लाइव स्टेज वीडियो व इफेक्ट्स सेटिंग्स
              </label>

              {/* Fog Level */}
              <div>
                <label className="text-xs text-amber-200 font-bold block mb-1">
                  लो-लाइंग स्टेज फॉग स्तर:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['medium', 'dense', 'ultra-cloud'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setSimFogLevel(lvl)}
                      className={`py-1.5 px-2 rounded-xl text-xs font-black border transition-all cursor-pointer ${
                        simFogLevel === lvl
                          ? 'border-amber-400 bg-amber-400 text-slate-950'
                          : 'border-slate-800 bg-slate-950 text-amber-200'
                      }`}
                    >
                      {lvl === 'medium' ? 'मीडियम फॉग' : lvl === 'dense' ? 'डेंस फॉग' : 'अल्ट्रा क्लाउड'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Light Theme */}
              <div>
                <label className="text-xs text-amber-200 font-bold block mb-1">
                  स्टेज लाइट कलर:
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {(['royal-gold', 'romantic-violet', 'crimson-fire', 'sapphire-blue'] as const).map((l) => (
                    <button
                      key={l}
                      type="button"
                      onClick={() => setSimLighting(l)}
                      className={`py-1.5 px-2 rounded-xl text-[11px] font-black border transition-all cursor-pointer ${
                        simLighting === l
                          ? 'border-amber-400 bg-amber-400 text-slate-950'
                          : 'border-slate-800 bg-slate-950 text-amber-200'
                      }`}
                    >
                      {l === 'royal-gold' ? 'रॉयल गोल्ड' : l === 'romantic-violet' ? 'वायलेट' : l === 'crimson-fire' ? 'रेड' : 'ब्लू'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Pyro Toggle & Play/Pause */}
              <div className="flex items-center justify-between pt-1">
                <button
                  type="button"
                  onClick={() => setSimShowPyros(!simShowPyros)}
                  className={`py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    simShowPyros 
                      ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/30' 
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {simShowPyros ? '✨ कोल्ड पायरो: चालू' : 'कोल्ड पायरो: बंद'}
                </button>

                <button
                  type="button"
                  onClick={() => setSimPlaying(!simPlaying)}
                  className="py-2 px-4 bg-gradient-to-r from-rose-600 to-amber-600 hover:opacity-90 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  {simPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{simPlaying ? 'पॉज़' : 'प्ले'}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Visual Stage Output Preview */}
        <div className="lg:col-span-7 space-y-3.5">
          <div className="bg-slate-950 p-4 sm:p-5 rounded-3xl border-2 border-amber-400 shadow-2xl shadow-amber-900/40">
            {/* Preview Header with Custom Branding */}
            <div className="flex items-center justify-between mb-3 px-1">
              <span className="text-xs font-black text-amber-300 flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-400 fill-current" />
                <span>
                  {userUploadedVideo 
                    ? 'कस्टमर वीडियो प्लेयर (ब्रांडेड ओवरले)' 
                    : 'लाइव 60 FPS स्टेज वीडियो सिमुलेटर'}
                </span>
              </span>

              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black px-3 py-1 rounded-full bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 shadow-md">
                  {groomBrideName}
                </span>
              </div>
            </div>

            {/* Display Canvas, Video Player, or Vector Wedding Stage */}
            <div className="relative rounded-2xl overflow-hidden bg-black flex items-center justify-center min-h-[400px] border-2 border-amber-500/40 shadow-inner">
              {userUploadedVideo ? (
                /* Customer's Uploaded Video with Brand Overlay */
                <div className="relative w-full h-full flex items-center justify-center">
                  <video
                    ref={videoPlayerRef}
                    src={userUploadedVideo}
                    controls
                    autoPlay
                    loop
                    className="w-full h-auto object-contain max-h-[540px] rounded-xl"
                  />
                  {/* Floating Custom Branded Overlay on top of customer's video */}
                  <div className="absolute top-4 left-4 right-4 bg-slate-950/80 backdrop-blur-md p-2.5 rounded-xl border border-amber-400 flex items-center justify-between pointer-events-none">
                    <div>
                      <div className="text-[11px] font-bold text-amber-400">{backdropBanner}</div>
                      <div className="text-sm font-black text-white">{groomBrideName}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] font-black text-amber-300">👑 {firmOrFamilyName}</div>
                      <div className="text-[9px] text-slate-300">{eventDate} • {venue}</div>
                    </div>
                  </div>
                </div>
              ) : (
                /* Real-time 60 FPS Wedding Stage Simulator Canvas */
                <canvas
                  ref={canvasRef}
                  className="w-full h-auto object-contain max-h-[540px] rounded-xl"
                />
              )}
            </div>

            {!userUploadedVideo && (
              <button
                type="button"
                onClick={handleDownloadVideo}
                disabled={recordingVideo || loading}
                className="w-full mt-4 py-3.5 rounded-2xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-sm flex justify-center items-center gap-2 disabled:opacity-60"
              >
                {recordingVideo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Video className="w-4 h-4" />}
                {recordingVideo ? '15 सेकंड का वीडियो बन रहा है…' : '15 सेकंड का वीडियो डाउनलोड करें (WebM)'}
              </button>
            )}
            {/* Download & Share Actions */}
            <div className="grid grid-cols-2 gap-2.5 mt-4 pt-1">
              <button
                type="button"
                onClick={handleShareWhatsApp}
                className="py-3.5 px-3 bg-gradient-to-r from-emerald-500 via-emerald-600 to-emerald-700 hover:from-emerald-400 hover:to-emerald-600 text-white font-black text-xs sm:text-sm rounded-2xl flex items-center justify-center gap-2 shadow-xl shadow-emerald-700/30 active:scale-95 transition-all duration-200 cursor-pointer border border-emerald-300/40"
              >
                <Share2 className="w-4 h-4" />
                <span>WhatsApp शेयर</span>
              </button>

              <button
                type="button"
                onClick={() => refreshStageGraphic()}
                disabled={loading}
                className="py-3.5 px-3 bg-slate-900 hover:bg-slate-800 border-2 border-amber-500/50 text-amber-200 hover:text-white text-xs sm:text-sm font-black rounded-2xl flex items-center justify-center gap-2 transition-all duration-200 cursor-pointer shadow-md"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                <span>रीफ्रेश स्टेज</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreativeStudio;
