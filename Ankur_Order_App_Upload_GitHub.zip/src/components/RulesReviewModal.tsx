import React, { useState } from 'react';
import { 
  FileCode, 
  Check, 
  Copy, 
  X, 
  ShieldCheck, 
  Lock, 
  EyeOff, 
  Database
} from 'lucide-react';

import rulesText from '../../firestore.rules?raw';

interface RulesReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Always shows the real firestore.rules file shipped with the project (no stale copy).
export const FIRESTORE_RULES_CONTENT: string = rulesText;

export const RulesReviewModal: React.FC<RulesReviewModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(FIRESTORE_RULES_CONTENT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-sky-50 border border-sky-200 text-sky-700">
              <FileCode className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                Firestore Security Rules Code
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-300 font-semibold">
                  Verified Clean
                </span>
              </h2>
              <p className="text-[11px] text-slate-500">
                Project: <strong className="text-slate-800 font-mono">ankur-dryice-app</strong> &bull; Database: <strong className="text-slate-800 font-mono">(default)</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-sky-500 hover:bg-sky-600 text-white flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Rules</span>
                </>
              )}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Security Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 p-3.5 bg-slate-50 border-b border-slate-200 text-xs">
          <div className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-slate-200">
            <Lock className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-900 block font-semibold text-[11px]">Customer PII Strictly Isolated</strong>
              <p className="text-[10px] text-slate-500">
                Customer name, phone, and address in <code className="text-sky-700 font-mono">/orders</code> are accessible only by the buyer and verified owner.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-slate-200">
            <EyeOff className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-900 block font-semibold text-[11px]">Compound Token Tracking</strong>
              <p className="text-[10px] text-slate-500">
                <code className="text-sky-700 font-mono">/order_tracking</code> is keyed by <code className="text-slate-700 font-mono">\${'{orderId}'}_\${'{PIN}'}</code>. Queries without both are denied.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-slate-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-900 block font-semibold text-[11px]">Owner Authorization</strong>
              <p className="text-[10px] text-slate-500">
                Admin updates are restricted to <code className="text-emerald-700 font-mono">ankurdryicewholesalers@gmail.com</code>.
              </p>
            </div>
          </div>
        </div>

        {/* Code Content */}
        <div className="flex-1 overflow-auto p-3.5 bg-slate-900 font-mono text-[11px] text-slate-200 selection:bg-sky-600">
          <pre className="whitespace-pre overflow-x-auto leading-relaxed">
            {FIRESTORE_RULES_CONTENT}
          </pre>
        </div>

        {/* Footer */}
        <div className="px-5 py-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <Database className="w-3.5 h-3.5 text-sky-600" />
            <span>Target: <code className="text-slate-800 font-mono">firestore.rules</code></span>
          </div>

          <button
            onClick={onClose}
            className="px-3 py-1 rounded-lg bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
