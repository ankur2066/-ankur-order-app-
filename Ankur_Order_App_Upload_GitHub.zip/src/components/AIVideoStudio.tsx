import React, { useCallback, useEffect, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import { AlertTriangle, Clapperboard, Download, ImagePlus, Loader2, Share2, Sparkles, Video, X } from 'lucide-react';
import { CreativeStudio } from './CreativeStudio';
import { SignInScreen } from './SignInScreen';
import { resizeImageToJpeg } from '../utils/imageResize';
import {
  checkVideoService,
  fetchVideoBlob,
  getVideoJob,
  startVideoJob,
  VideoApiError,
  type VideoAspect,
  type ServiceStatus,
} from '../services/videoApi';

type Mode = 'ai' | 'stage';
type Phase = 'idle' | 'submitting' | 'processing' | 'done' | 'error';

const POLL_MS = 8000;
const MAX_WAIT_MS = 12 * 60 * 1000;

const IDEAS = [
  'दूल्हा-दुल्हन की वरमाला एंट्री, ज़मीन पर घना ड्राई आइस फॉग, सुनहरी रोशनी, सिनेमैटिक',
  'संगीत नाइट का डांस फ्लोर, ठंडा सफ़ेद धुआँ, रंगीन लेज़र लाइट्स',
  'ड्राई आइस पेलेट्स पर पानी डालते ही उठता धुआँ, क्लोज़-अप, स्लो मोशन',
];

function readFileAsBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(new Error('फ़ाइल पढ़ी नहीं जा सकी'));
    reader.readAsDataURL(blob);
  });
}

export const AIVideoStudio: React.FC<{ currentUser: User | null }> = ({ currentUser }) => {
  const [mode, setMode] = useState<Mode>('ai');
  const [service, setService] = useState<ServiceStatus | null>(null);

  const [prompt, setPrompt] = useState('');
  const [aspect, setAspect] = useState<VideoAspect>('9:16');
  const [refImage, setRefImage] = useState<{ previewUrl: string; mimeType: string; dataBase64: string } | null>(null);

  const [phase, setPhase] = useState<Phase>('idle');
  const [errorText, setErrorText] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const videoBlobRef = useRef<Blob | null>(null);
  const pollRef = useRef<number | undefined>(undefined);
  const startedAtRef = useRef(0);

  useEffect(() => {
    let alive = true;
    checkVideoService().then((s) => alive && setService(s));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(
    () => () => {
      window.clearInterval(pollRef.current);
    },
    []
  );

  useEffect(
    () => () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    },
    [videoUrl]
  );

  const fail = useCallback((message: string) => {
    window.clearInterval(pollRef.current);
    setErrorText(message);
    setPhase('error');
  }, []);

  const handlePickImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setErrorText('सिर्फ़ फोटो चुनें (रेफ़रेंस के रूप में)।');
      return;
    }
    try {
      const blob = await resizeImageToJpeg(file, 1024, 0.85);
      const dataBase64 = await readFileAsBase64(blob);
      setRefImage({ previewUrl: URL.createObjectURL(blob), mimeType: 'image/jpeg', dataBase64 });
      setErrorText(null);
    } catch (err: any) {
      setErrorText(err?.message || 'फोटो जोड़ी नहीं जा सकी');
    }
  };

  const handleGenerate = async () => {
    const text = prompt.trim();
    if (text.length < 10) {
      setErrorText('कृपया वीडियो का थोड़ा विस्तार से विवरण लिखें (कम से कम 10 अक्षर)।');
      return;
    }
    setErrorText(null);
    setVideoUrl(null);
    videoBlobRef.current = null;
    setPhase('submitting');

    try {
      const jobId = await startVideoJob({
        prompt: text,
        aspectRatio: aspect,
        referenceImage: refImage ? { mimeType: refImage.mimeType, dataBase64: refImage.dataBase64 } : undefined,
      });
      setPhase('processing');
      startedAtRef.current = Date.now();

      window.clearInterval(pollRef.current);
      pollRef.current = window.setInterval(async () => {
        if (Date.now() - startedAtRef.current > MAX_WAIT_MS) {
          fail('वीडियो बनने में बहुत समय लग रहा है। कुछ देर बाद दोबारा कोशिश करें।');
          return;
        }
        try {
          const job = await getVideoJob(jobId);
          if (job.status === 'failed') {
            fail(job.error || 'वीडियो नहीं बन सका।');
          } else if (job.status === 'done') {
            window.clearInterval(pollRef.current);
            const blob = await fetchVideoBlob(jobId);
            videoBlobRef.current = blob;
            setVideoUrl(URL.createObjectURL(blob));
            setPhase('done');
          }
        } catch (err) {
          fail(err instanceof VideoApiError ? err.message : 'वीडियो की स्थिति नहीं मिल सकी।');
        }
      }, POLL_MS);
    } catch (err) {
      fail(err instanceof VideoApiError ? err.message : 'वीडियो शुरू नहीं हो सका।');
    }
  };

  const handleDownload = () => {
    if (!videoUrl) return;
    const a = document.createElement('a');
    a.href = videoUrl;
    a.download = `ankur-ai-video-${Date.now()}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleShare = async () => {
    const blob = videoBlobRef.current;
    if (!blob) return;
    try {
      const file = new File([blob], 'ankur-ai-video.mp4', { type: blob.type || 'video/mp4' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], text: 'अंकुर ड्राई आइस एंड इवेंट्स' });
        return;
      }
      setErrorText('इस डिवाइस पर सीधे शेयर उपलब्ध नहीं है। पहले “डाउनलोड” करें, फिर गैलरी से WhatsApp पर भेजें।');
    } catch (err: any) {
      if (err?.name !== 'AbortError') setErrorText('शेयर नहीं हो सका। डाउनलोड करके गैलरी से भेजें।');
    }
  };

  const busy = phase === 'submitting' || phase === 'processing';

  return (
    <div className="c-app min-h-screen page-with-bottom-nav">
      <header className="c-card border-b b-line px-4 pb-3 sticky top-0 z-30" style={{ paddingTop: 'calc(env(safe-area-inset-top, 0px) + 14px)' }}>
        <h1 className="text-xl font-black t-main flex items-center gap-2">
          <Clapperboard className="w-6 h-6 t-brand" />
          AI वीडियो
        </h1>
        <div className="mt-3 grid grid-cols-2 gap-1.5 p-1 rounded-2xl c-soft" role="tablist" aria-label="वीडियो का तरीका">
          {([
            ['ai', 'AI वीडियो (सर्वर)'],
            ['stage', 'स्टेज वीडियो मेकर'],
          ] as [Mode, string][]).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={mode === id}
              onClick={() => setMode(id)}
              className={`focus-ring min-h-10 rounded-xl text-[13px] font-extrabold cursor-pointer ${mode === id ? 'c-brand' : 't-brand-ink'}`}
            >
              {label}
            </button>
          ))}
        </div>
      </header>

      {mode === 'stage' ? (
        <CreativeStudio currentUser={currentUser} />
      ) : (
        <div className="p-4 space-y-4 max-w-lg mx-auto">
          {service === null && (
            <div className="c-card border b-line rounded-2xl p-5 flex items-center gap-3 t-sub text-sm" aria-busy="true">
              <Loader2 className="w-5 h-5 animate-spin" /> वीडियो सर्वर जाँचा जा रहा है…
            </div>
          )}

          {service && !service.available && (
            <section className="c-card border b-line rounded-2xl p-5" role="status">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-6 h-6 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h2 className="text-base font-black t-main">AI वीडियो अभी उपलब्ध नहीं है</h2>
                  <p className="text-xs t-sub mt-1 leading-relaxed">{service.reason}</p>
                  <p className="text-xs t-sub mt-2 leading-relaxed">
                    तब तक “स्टेज वीडियो मेकर” से अपने डिवाइस पर ही धुएँ वाली एंट्री का वीडियो बनाकर डाउनलोड कर सकते हैं।
                  </p>
                  <button type="button" onClick={() => setMode('stage')} className="focus-ring mt-3 min-h-10 px-4 rounded-xl c-brand text-sm font-extrabold cursor-pointer">
                    स्टेज वीडियो मेकर खोलें
                  </button>
                </div>
              </div>
            </section>
          )}

          {service?.available && !currentUser && (
            <SignInScreen
              title="वीडियो बनाने के लिए लॉगिन करें"
              subtitle="AI वीडियो पर रोज़ की सीमा लगती है, इसलिए Google लॉगिन ज़रूरी है।"
            />
          )}

          {service?.available && currentUser && (
            <>
              <section className="c-card border b-line rounded-2xl p-4 space-y-3">
                <label className="block">
                  <span className="text-sm font-extrabold t-main">आप कैसा वीडियो चाहते हैं?</span>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value.slice(0, 600))}
                    rows={4}
                    disabled={busy}
                    placeholder="जैसे: वरमाला के समय स्टेज पर ड्राई आइस फॉग, सुनहरी रोशनी…"
                    className="focus-ring mt-1.5 w-full rounded-xl border b-line p-3 text-sm t-main c-card"
                  />
                </label>

                <div className="flex flex-wrap gap-1.5">
                  {IDEAS.map((idea) => (
                    <button
                      key={idea}
                      type="button"
                      disabled={busy}
                      onClick={() => setPrompt(idea)}
                      className="focus-ring text-[11px] font-bold px-2.5 py-1.5 rounded-full c-soft t-brand-ink cursor-pointer text-left"
                    >
                      {idea.slice(0, 28)}…
                    </button>
                  ))}
                </div>

                <div>
                  <span className="text-sm font-extrabold t-main">वीडियो का आकार</span>
                  <div className="grid grid-cols-2 gap-2 mt-1.5">
                    {([
                      ['9:16', 'WhatsApp स्टेटस (खड़ा)'],
                      ['16:9', 'चौड़ा (TV / LED)'],
                    ] as [VideoAspect, string][]).map(([id, label]) => (
                      <button
                        key={id}
                        type="button"
                        disabled={busy}
                        onClick={() => setAspect(id)}
                        aria-pressed={aspect === id}
                        className={`focus-ring min-h-11 rounded-xl border-2 text-[12px] font-extrabold cursor-pointer ${aspect === id ? 'b-brand t-brand c-soft' : 'b-line t-sub'}`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-sm font-extrabold t-main">रेफ़रेंस फोटो (वैकल्पिक)</span>
                  <p className="text-[11px] t-sub mt-0.5">फोटो सिर्फ़ वीडियो के लिए रेफ़रेंस की तरह इस्तेमाल होती है।</p>
                  {refImage ? (
                    <div className="mt-2 flex items-center gap-3">
                      <img src={refImage.previewUrl} alt="रेफ़रेंस" className="w-16 h-16 rounded-xl object-cover" />
                      <button type="button" onClick={() => setRefImage(null)} disabled={busy} className="focus-ring min-h-10 px-3 rounded-xl border b-line t-sub text-xs font-bold flex items-center gap-1 cursor-pointer">
                        <X className="w-4 h-4" /> हटाएँ
                      </button>
                    </div>
                  ) : (
                    <label className="focus-ring mt-2 min-h-11 px-4 rounded-xl border-2 border-dashed b-line t-sub text-sm font-bold flex items-center justify-center gap-2 cursor-pointer">
                      <ImagePlus className="w-5 h-5" /> फोटो चुनें
                      <input type="file" accept="image/*" onChange={handlePickImage} disabled={busy} className="sr-only" />
                    </label>
                  )}
                </div>

                <button
                  type="button"
                  onClick={handleGenerate}
                  disabled={busy}
                  className="focus-ring w-full min-h-12 rounded-2xl c-brand text-sm font-extrabold flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
                >
                  {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
                  {phase === 'submitting' ? 'भेजा जा रहा है…' : phase === 'processing' ? 'वीडियो बन रहा है…' : 'वीडियो बनाएँ'}
                </button>
                {phase === 'processing' && (
                  <p className="text-xs t-sub text-center" role="status">
                    इसमें कुछ मिनट लग सकते हैं। इस स्क्रीन को खुला रखें।
                  </p>
                )}
              </section>

              {errorText && (
                <div role="alert" className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs leading-relaxed">
                  {errorText}
                </div>
              )}

              {phase === 'done' && videoUrl && (
                <section className="c-card border b-line rounded-2xl p-3 space-y-3">
                  <h2 className="text-sm font-black t-main flex items-center gap-2">
                    <Video className="w-4 h-4 t-brand" /> आपका वीडियो
                  </h2>
                  <video src={videoUrl} controls playsInline className="w-full rounded-xl bg-black max-h-[60vh]" />
                  <div className="grid grid-cols-2 gap-2.5">
                    <button type="button" onClick={handleDownload} className="focus-ring min-h-11 rounded-xl c-brand text-sm font-extrabold flex items-center justify-center gap-2 cursor-pointer">
                      <Download className="w-4 h-4" /> डाउनलोड
                    </button>
                    <button type="button" onClick={handleShare} className="focus-ring min-h-11 rounded-xl border-2 b-brand t-brand text-sm font-extrabold flex items-center justify-center gap-2 cursor-pointer">
                      <Share2 className="w-4 h-4" /> शेयर
                    </button>
                  </div>
                  <p className="text-[11px] t-sub leading-relaxed">
                    डाउनलोड/शेयर आपके फोन और Android सेटिंग पर निर्भर करता है। न चले तो इसी वीडियो को ब्राउज़र वर्ज़न में खोलकर सेव करें।
                  </p>
                </section>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default AIVideoStudio;
