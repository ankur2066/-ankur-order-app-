import React from 'react';
import { 
  Package, 
  Truck,
  Boxes,
  LogOut
} from 'lucide-react';
import type { User } from 'firebase/auth';
import type { UserRole } from '../types';
import { signOutUser } from '../firebase';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentUser?: User | null;
  userRole?: UserRole | null;
  onOpenRulesReview?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  currentUser,
  userRole,
}) => {
  const isStaffOrDelivery = userRole === 'staff' || userRole === 'delivery';

  // -------------------------------------------------------------
  // RESTRICTED HEADER FOR STAFF & DELIVERY BOYS
  // Hide booking, customer orders, studio, and settings completely!
  // -------------------------------------------------------------
  if (isStaffOrDelivery) {
    return (
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs app-safe-header">
        <div className="max-w-4xl mx-auto px-3 sm:px-4 py-2.5 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-white font-bold shrink-0 ${
              userRole === 'delivery' ? 'bg-indigo-600' : 'bg-emerald-600'
            }`}>
              {userRole === 'delivery' ? <Truck className="w-4 h-4" /> : <Boxes className="w-4 h-4" />}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-sm text-slate-900 leading-none">अंकुर ड्राई आइस</span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                  userRole === 'delivery' 
                    ? 'bg-indigo-100 text-indigo-800' 
                    : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {userRole === 'delivery' ? 'डिलीवरी' : 'स्टाफ'}
                </span>
              </div>
              <span className="text-[11px] text-slate-400 block mt-0.5">
                सीमित स्टेटस अपडेट पोर्टल
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setCurrentTab('staff-dashboard')}
              className="py-1 px-3 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs"
            >
              <Package className="w-3.5 h-3.5" />
              <span>ऑर्डर्स सूची</span>
            </button>

            <button
              type="button"
              onClick={() => signOutUser()}
              className="p-1.5 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-bold transition-colors cursor-pointer"
              title="लॉगआउट करें"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>
    );
  }

  // Customers and the owner use the storefront bottom navigation / owner dashboard
  // (see App.tsx); this header is only for staff and delivery accounts.
  return null;
};

export default Header;
