import React, { useState } from 'react';
import { Loader2, LogIn, ShieldCheck } from 'lucide-react';
import { signInWithGoogle } from '../firebase';

interface SignInScreenProps {
  title?: string;
  subtitle?: string;
  onSignedIn?: () => void;
}

/**
 * The ONE Google Sign-In screen for everybody (customer, staff, owner).
 * What the person can do afterwards is decided by their role in Firestore
 * (users/{uid}.role, written only by the owner) and enforced by firestore.rules,
 * never by which button they pressed here.
 */
export const SignInScreen: React.FC<SignInScreenProps> = ({
  title = 'Google से लॉगिन करें',
  subtitle = 'ऑर्डर हिस्ट्री, रीऑर्डर और प्रोफ़ाइल के लिए लॉगिन करें। बुकिंग और ट्रैकिंग बिना लॉगिन भी हो सकती है।',
  onSignedIn,
}) => {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    try {
      setBusy(true);
      setError(null);
      await signInWithGoogle();
      onSignedIn?.();
    } catch (err: any) {
      setError('लॉगिन नहीं हो सका: ' + (err?.message || 'अज्ञात त्रुटि'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="c-card border b-line rounded-3xl p-6 text-center">
      <div className="w-14 h-14 rounded-2xl c-soft t-brand flex items-center justify-center mx-auto mb-3">
        <ShieldCheck className="w-7 h-7" />
      </div>
      <h2 className="text-lg font-black t-main">{title}</h2>
      <p className="text-xs t-sub mt-1.5 leading-relaxed">{subtitle}</p>

      {error && (
        <div role="alert" className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs text-left">
          {error}
        </div>
      )}

      <button
        type="button"
        onClick={handleLogin}
        disabled={busy}
        className="focus-ring mt-5 w-full min-h-12 rounded-2xl c-brand font-extrabold text-sm flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
      >
        {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : <LogIn className="w-5 h-5" />}
        <span>Google से साइन इन करें</span>
      </button>
      <p className="text-[11px] t-sub mt-3">
        मालिक और स्टाफ भी यहीं से लॉगिन करते हैं। स्टाफ एक्सेस मालिक की मंज़ूरी के बाद मिलता है।
      </p>
    </div>
  );
};

export default SignInScreen;
