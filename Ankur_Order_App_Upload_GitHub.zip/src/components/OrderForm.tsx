import React, { useState, useEffect, useMemo } from 'react';
import { 
  Snowflake, 
  MapPin, 
  Phone, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Copy, 
  Check, 
  ArrowRight,
  User,
  RotateCcw,
  X,
  CreditCard,
  MessageCircle,
  Upload,
  Image as ImageIcon,
  Share2,
  Loader2,
  QrCode,
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';
import { 
  writeBatch, 
  doc, 
  getDoc,
  setDoc,
  collection,
  query,
  where,
  getDocs,
  serverTimestamp 
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, signInWithGoogle, signOutUser } from '../firebase';
import { 
  getDispatchSlots, 
  BUSINESS_PHONE_DISPLAY,
  BUSINESS_CALL_HREF,
  BUSINESS_WHATSAPP_BASE
} from '../data/products';
import { subscribeToRates, getLocalRates } from '../data/rates';
import type { Order, OrderTracking, ProductItem, RateSettings } from '../types';
import { applyProductRates, orderProductName } from '../data/catalog';
import type { User as FirebaseUser } from 'firebase/auth';

interface OrderFormProps {
  currentUser: FirebaseUser | null;
  onOrderSuccess: (orderId: string, trackingPin: string) => void;
  onGoToTrack?: (orderId: string, pin: string) => void;
  onGoToMyOrders?: () => void;
  reorderData?: Order | null;
  onClearReorder?: () => void;
  /** Product picked on the storefront (optional). Without it the form behaves exactly as before. */
  selectedProduct?: ProductItem | null;
  onClearProduct?: () => void;
}

export const OrderForm: React.FC<OrderFormProps> = ({
  currentUser,
  onOrderSuccess,
  onGoToTrack,
  onGoToMyOrders,
  reorderData,
  onClearReorder,
  selectedProduct,
  onClearProduct
}) => {
  // Owner-controlled pricing rates
  const [baseRates, setRates] = useState<RateSettings>(getLocalRates());
  // Rates actually used for this booking: global rates, or the picked product's own rates.
  const rates: RateSettings = useMemo(
    () => (selectedProduct ? applyProductRates(baseRates, selectedProduct) : baseRates),
    [baseRates, selectedProduct]
  );
  const bookedProductName = orderProductName(selectedProduct);

  useEffect(() => {
    const unsub = subscribeToRates((loaded) => setRates(loaded));
    return () => unsub();
  }, []);

  // Form fields
  const [customerName, setCustomerName] = useState(currentUser?.displayName || '');
  const [customerPhone, setCustomerPhone] = useState('');
  // Single city / place field: "शहर"
  const [address, setAddress] = useState('');
  
  // Custom-only quantity input allowing positive decimals (e.g. 2, 7, 10, 27.5); default 10
  const [quantityInput, setQuantityInput] = useState<string>('10');
  
  // Dispatch Slots (IST)
  const dispatchSlots = getDispatchSlots();
  // Select first non-disabled slot by default
  const defaultSlot = dispatchSlots.find(s => !s.disabled)?.label || dispatchSlots[0].label;
  const [dispatchTiming, setDispatchTiming] = useState<string>(defaultSlot);

  interface OrderSuccessDetails {
    orderId: string;
    trackingPin: string;
    customerName: string;
    customerPhone: string;
    address: string;
    quantityKg: number;
    totalAmount: number;
    dispatchTiming: string;
  }

  // Submission & UI States
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successData, setSuccessData] = useState<OrderSuccessDetails | null>(null);
  const [copiedId, setCopiedId] = useState(false);
  const [copiedPin, setCopiedPin] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [reorderNotice, setReorderNotice] = useState<string | null>(null);

  // Optional Payment Screenshot selection
  const [paymentScreenshot, setPaymentScreenshot] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  // Duplicate Order Protection State
  const [showDuplicateModal, setShowDuplicateModal] = useState(false);
  const [duplicatePreviousOrder, setDuplicatePreviousOrder] = useState<Order | null>(null);

  // Helper for human-readable order status in Hindi & English
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending': return 'प्रतीक्षित (Pending)';
      case 'confirmed': return 'कन्फर्म (Confirmed)';
      case 'in_packing': return 'पैकिंग जारी (In Packing)';
      case 'dispatched': return 'डिस्पैच हो गया (Dispatched)';
      case 'delivered': return 'डिलीवर हो गया (Delivered)';
      case 'cancelled': return 'रद्द (Cancelled)';
      default: return status;
    }
  };

  // Find matching order placed within the last 3 hours with same product, same quantity (KG), same location, and same dispatch timing
  const findRecentMatchingOrder = async (phone: string): Promise<Order | null> => {
    const cleanPhone = getClean10DigitPhone(phone);
    const THREE_HOURS_MS = 3 * 60 * 60 * 1000;
    const now = Date.now();

    const currentQty = currentQuantityKg;
    const currentLoc = address.trim().toLowerCase();
    const currentTiming = dispatchTiming.trim();
    const currentProduct = 'ड्राई आइस (Dry Ice)';

    // 1. Check local saved orders
    try {
      const stored = localStorage.getItem('ankur_dryice_placed_orders_v1');
      if (stored) {
        const list = JSON.parse(stored);
        if (Array.isArray(list)) {
          const match = list.find((ord: any) => {
            const ordPhone = getClean10DigitPhone(ord.customerPhone || '');
            const ordTime = ord.createdAtMs || (ord.createdAt ? new Date(ord.createdAt).getTime() : 0);
            const isMatch = (cleanPhone && ordPhone === cleanPhone) || 
                            (currentUser && ord.userId && ord.userId === currentUser.uid);
            const isRecent = (now - ordTime) <= THREE_HOURS_MS && (now - ordTime) >= 0;
            const notCancelled = ord.status !== 'cancelled';

            const ordQty = Number(ord.quantityKg || 0);
            const ordLoc = (ord.address || ord.city || ord.district || '').trim().toLowerCase();
            const ordTiming = (ord.dispatchTiming || '').trim();
            const ordProduct = (ord.productName || 'ड्राई आइस (Dry Ice)').trim();

            const isSameProduct = ordProduct === currentProduct;
            const isSameQty = ordQty === currentQty;
            const isSameLoc = ordLoc === currentLoc;
            const isSameTiming = ordTiming === currentTiming;

            return isMatch && isRecent && notCancelled && isSameProduct && isSameQty && isSameLoc && isSameTiming;
          });
          if (match) return match as Order;
        }
      }
    } catch (e) {
      console.warn('Error reading local orders:', e);
    }

    // 2. If authenticated user, also check Firestore orders
    if (currentUser) {
      try {
        const ordersRef = collection(db, 'orders');
        const q = query(ordersRef, where('userId', '==', currentUser.uid));
        const snap = await getDocs(q);
        const matches: Order[] = [];
        snap.forEach((d) => {
          const ord = d.data() as Order;
          if (!ord.isTrash && ord.status !== 'cancelled') {
            const ordPhone = getClean10DigitPhone(ord.customerPhone || '');
            const ordTime = ord.createdAt?.toMillis 
              ? ord.createdAt.toMillis() 
              : (ord.createdAt?.seconds ? ord.createdAt.seconds * 1000 : 0);
            const isMatch = (cleanPhone && ordPhone === cleanPhone) || ord.userId === currentUser.uid;
            const isRecent = (now - ordTime) <= THREE_HOURS_MS && (now - ordTime) >= 0;

            const ordQty = Number(ord.quantityKg || 0);
            const ordLoc = (ord.address || ord.city || ord.district || '').trim().toLowerCase();
            const ordTiming = (ord.dispatchTiming || '').trim();
            const ordProduct = (ord.productName || 'ड्राई आइस (Dry Ice)').trim();

            const isSameProduct = ordProduct === currentProduct;
            const isSameQty = ordQty === currentQty;
            const isSameLoc = ordLoc === currentLoc;
            const isSameTiming = ordTiming === currentTiming;

            if (isMatch && isRecent && isSameProduct && isSameQty && isSameLoc && isSameTiming) {
              matches.push(ord);
            }
          }
        });
        if (matches.length > 0) {
          matches.sort((a, b) => b.orderId.localeCompare(a.orderId));
          return matches[0];
        }
      } catch (e) {
        console.warn('Error checking Firestore orders for duplicate:', e);
      }
    }

    return null;
  };

  // Customer Google Login State
  const [customerLoggingIn, setCustomerLoggingIn] = useState(false);

  // Sync customerName with currentUser if customerName is empty or not customized
  // Fetch saved profile from Firestore for authenticated user
  useEffect(() => {
    if (currentUser) {
      const fetchProfile = async () => {
        try {
          const userDocRef = doc(db, 'users', currentUser.uid);
          const snap = await getDoc(userDocRef);
          if (snap.exists()) {
            const data = snap.data();
            if (data.customerName) setCustomerName(data.customerName);
            if (data.customerPhone) setCustomerPhone(data.customerPhone);
            if (data.city) setAddress(data.city);
          } else if (currentUser.displayName && !customerName) {
            setCustomerName(currentUser.displayName);
          }
        } catch (err) {
          console.error('Error fetching profile:', err);
          if (currentUser.displayName && !customerName) {
            setCustomerName(currentUser.displayName);
          }
        }
      };
      fetchProfile();
    }
  }, [currentUser]);

  const handleCustomerGoogleSignIn = async () => {
    try {
      setCustomerLoggingIn(true);
      setErrorMsg(null);
      const cred = await signInWithGoogle();
      if (cred?.user?.displayName && !customerName) {
        setCustomerName(cred.user.displayName);
      }
    } catch (err: any) {
      console.error('Customer Google Login error:', err);
      if (err?.code !== 'auth/popup-closed-by-user') {
        setErrorMsg('Google से लॉगिन करने में त्रुटि आई। कृपया पुनः प्रयास करें।');
      }
    } finally {
      setCustomerLoggingIn(false);
    }
  };

  // Pre-fill if reorderData passed
  useEffect(() => {
    if (reorderData) {
      setCustomerName(reorderData.customerName || '');
      setCustomerPhone(reorderData.customerPhone || '');
      setAddress(reorderData.address || reorderData.district || '');
      setQuantityInput(String(reorderData.quantityKg || 10));
      setReorderNotice(`पिछले ऑर्डर ${reorderData.orderId} (${reorderData.quantityKg} kg) की जानकारी भरी गई है।`);
    }
  }, [reorderData]);

  // Live Pricing calculation based on user custom quantity input (supports decimals, 0 if empty/invalid)
  const parsedQuantity = parseFloat(quantityInput);
  const currentQuantityKg = (quantityInput.trim() === '' || isNaN(parsedQuantity) || parsedQuantity <= 0) ? 0 : parsedQuantity;
  const currentUnitRate = rates.dryIceRate + rates.thermocolRate + (rates.transportRate || 0);
  const dryIceSubtotal = Math.round(currentQuantityKg * rates.dryIceRate * 100) / 100;
  const thermocolSubtotal = Math.round(currentQuantityKg * rates.thermocolRate * 100) / 100;
  const totalAmount = Math.round(currentQuantityKg * currentUnitRate * 100) / 100;

  // Indian phone validator (10 digits starting with 6, 7, 8, or 9)
  const validatePhone = (phone: string): boolean => {
    const cleaned = phone.replace(/[^0-9]/g, '');
    const tenDigits = cleaned.length >= 10 ? cleaned.slice(-10) : cleaned;
    return /^[6-9]\d{9}$/.test(tenDigits);
  };

  const getClean10DigitPhone = (phone: string): string => {
    const cleaned = phone.replace(/[^0-9]/g, '');
    return cleaned.length >= 10 ? cleaned.slice(-10) : cleaned;
  };

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPaymentScreenshot(file);
      const previewUrl = URL.createObjectURL(file);
      setScreenshotPreview(previewUrl);
      setShareFeedback(null);
    }
  };

  const handleRemoveScreenshot = () => {
    setPaymentScreenshot(null);
    if (screenshotPreview) {
      URL.revokeObjectURL(screenshotPreview);
      setScreenshotPreview(null);
    }
    setShareFeedback(null);
  };

  // Helper to build WhatsApp message text with full customer order details & total amount
  const getWhatsAppMessageText = (orderId: string): string => {
    const name = (successData?.customerName || customerName).trim() || 'ग्राहक';
    const phone = successData?.customerPhone || getClean10DigitPhone(customerPhone) || customerPhone;
    const place = (successData?.address || address).trim() || 'उत्तर प्रदेश';
    const qty = successData?.quantityKg ?? (currentQuantityKg > 0 ? currentQuantityKg : (parseFloat(quantityInput) || 10));
    const amountVal = successData?.totalAmount ?? (totalAmount > 0 ? totalAmount : (Math.round(qty * currentUnitRate * 100) / 100));
    const timing = successData?.dispatchTiming || dispatchTiming;
    const pin = successData?.trackingPin;
    const paymentStatusText = paymentScreenshot 
      ? 'भुगतान संपन्न (स्क्रीनशॉट चैट में संलग्न)' 
      : 'भुगतान संपन्न (स्क्रीनशॉट चैट में भेज रहा हूँ)';

    const orderLines = [
      `*अंकुर ड्राई आइस (Ankur Dry Ice)*`,
      `*ऑर्डर एवं पेमेंट विवरण (Order & Payment Confirmation)*`,
      ``,
      `नमस्ते, मैंने ऑर्डर #${orderId} का भुगतान पूरा कर दिया है। कृपया ऑर्डर विवरण एवं भुगतान स्वीकार करें:`,
      ``,
      `📋 *ऑर्डर विवरण (Order Details):*`,
      `• ऑर्डर ID: #${orderId}`,
      pin ? `• गोपनीय ट्रैकिंग PIN: ${pin}` : null,
      `• ग्राहक का नाम: ${name}`,
      `• मोबाइल नंबर: ${phone}`,
      `• शहर / जगह: ${place} (पता/Address)`,
      `• उत्पाद: ड्राई आइस (Dry Ice)`,
      `• मात्रा: ${qty} KG`,
      `• डिस्पैच समय: ${timing}`,
      `• कुल राशि: ₹${amountVal}`,
      `• पेमेंट स्थिति: ${paymentStatusText}`,
      `• भुगतान माध्यम: Paytm UPI (8896332066@paytm)`,
      ``,
      paymentScreenshot 
        ? `📸 [नोट: पेमेंट स्क्रीनशॉट चैट में अटैच करके भेजा जा रहा है]` 
        : `📸 [नोट: कृपया इस चैट में पेमेंट का स्क्रीनशॉट अटैच करके भेजें]`
    ].filter(Boolean) as string[];

    return orderLines.join('\n');
  };

  // Helper to build WhatsApp deep link URL with +918896332066
  const getWhatsAppPaymentDeepLink = (orderId: string): string => {
    const message = getWhatsAppMessageText(orderId);
    return `https://wa.me/918896332066?text=${encodeURIComponent(message)}`;
  };

  // Desktop web WhatsApp fallback URL with +918896332066
  const getWhatsAppWebPaymentLink = (orderId: string): string => {
    const message = getWhatsAppMessageText(orderId);
    return `https://web.whatsapp.com/send?phone=918896332066&text=${encodeURIComponent(message)}`;
  };

  // Pre-filled WhatsApp inquiry link with entered order details & total amount
  const getFormWhatsAppInquiryLink = (): string => {
    const name = customerName.trim();
    const phone = getClean10DigitPhone(customerPhone) || customerPhone.trim();
    const place = address.trim();
    const qty = currentQuantityKg > 0 ? currentQuantityKg : (parseFloat(quantityInput) || 10);
    const amountVal = totalAmount > 0 ? totalAmount : (Math.round(qty * currentUnitRate * 100) / 100);

    const inquiryLines = [
      `नमस्ते अंकुर ड्राई आइस,`,
      `मुझे ड्राई आइस ऑर्डर के संबंध में पूछताछ / बुकिंग करनी है:`,
      ``,
      `📋 *ऑर्डर विवरण:*`,
      name ? `• ग्राहक का नाम: ${name}` : null,
      phone ? `• मोबाइल नंबर: ${phone}` : null,
      place ? `• शहर / पता: ${place}` : null,
      `• उत्पाद: ड्राई आइस (Dry Ice)`,
      `• मात्रा: ${qty} KG`,
      `• डिस्पैच समय: ${dispatchTiming}`,
      `• कुल राशि: ₹${amountVal}`,
    ].filter(Boolean) as string[];

    return `https://wa.me/918896332066?text=${encodeURIComponent(inquiryLines.join('\n'))}`;
  };

  // Direct WhatsApp payment message logic - opens WhatsApp chat directly with +918896332066
  const handleSharePaymentScreenshot = (orderId: string) => {
    const isMobile = typeof navigator !== 'undefined' && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

    const directChatUrl = isMobile
      ? getWhatsAppPaymentDeepLink(orderId)
      : getWhatsAppWebPaymentLink(orderId);

    window.open(directChatUrl, '_blank', 'noopener,noreferrer');

    setShareFeedback(
      paymentScreenshot
        ? 'WhatsApp चैट (+91 8896332066) खुल रही है। कृपया चैट में अटैचमेंट (+) आइकन से अपना चुना हुआ पेमेंट स्क्रीनशॉट भेजें।'
        : 'WhatsApp चैट (+91 8896332066) खुल रही है। कृपया चैट में अपने पेमेंट का स्क्रीनशॉट अटैच करके भेजें।'
    );
  };

  const executeOrderSubmission = async () => {
    if (submitting) return; // Prevent accidental double submission
    setErrorMsg(null);

    try {
      setSubmitting(true);

      const parsedQty = parseFloat(quantityInput);
      const cleanPhone = getClean10DigitPhone(customerPhone);
      const cleanAddress = address.trim();

      // Standardized Order ID: ADI-YYYYMMDD-XXXX
      const dateSegment = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const randomSuffix = Math.random().toString(36).substring(2, 6).toUpperCase();
      const generatedOrderId = `ADI-${dateSegment}-${randomSuffix}`;
      
      // 6-digit Secret Tracking PIN
      const generatedPin = Math.floor(100000 + Math.random() * 900000).toString();

      // Compound token for zero-trust tracking authorization
      const generatedTrackingToken = `${generatedOrderId}_${generatedPin}`;

      const finalQuantityKg = parsedQty;
      const unitRate = rates.dryIceRate + rates.thermocolRate + (rates.transportRate || 0);
      const finalDryIceSubtotal = Math.round(finalQuantityKg * rates.dryIceRate * 100) / 100;
      const finalThermocolSubtotal = Math.round(finalQuantityKg * rates.thermocolRate * 100) / 100;
      const finalTotalAmount = Math.round(finalQuantityKg * unitRate * 100) / 100;

      const batch = writeBatch(db);

      // 1. Private Order Document (/orders/{orderId})
      const privateOrderRef = doc(db, 'orders', generatedOrderId);
      const privateOrderPayload: Order = {
        orderId: generatedOrderId,
        trackingToken: generatedTrackingToken,
        trackingPin: generatedPin,
        customerName: customerName.trim(),
        customerPhone: cleanPhone,
        district: cleanAddress.slice(0, 100),
        address: cleanAddress,
        city: cleanAddress.slice(0, 100),
        quantityKg: finalQuantityKg,
        dispatchTiming,
        productName: bookedProductName,
        
        // Exact stored booked rates and totals
        dryIcePricePerKg: rates.dryIceRate,
        dryIceSubtotal: finalDryIceSubtotal,
        thermocolPricePerKg: rates.thermocolRate,
        thermocolSubtotal: finalThermocolSubtotal,
        transportPrice: rates.transportRate || 0,
        totalAmount: finalTotalAmount,

        status: 'pending',
        paymentStatus: 'pending_verification',
        paymentMethod: 'paytm_business_upi',
        paymentNotes: 'Paytm Business / UPI द्वारा ओनर वेरिफिकेशन प्रतीक्षित',
        userId: currentUser?.uid || 'guest',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      // 2. Protected Tracking Document (/order_tracking/{trackingToken}) - ZERO PII
      const publicTrackingRef = doc(db, 'order_tracking', generatedTrackingToken);
      const publicTrackingPayload: OrderTracking = {
        orderId: generatedOrderId,
        trackingToken: generatedTrackingToken,
        status: 'pending',
        productName: bookedProductName,
        quantityKg: finalQuantityKg,
        district: cleanAddress.slice(0, 100),
        dispatchTiming,
        paymentStatus: 'pending_verification',
        lastStatusUpdate: 'ऑर्डर प्राप्त हुआ। पैकिंग शेड्यूल्ड।',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      batch.set(privateOrderRef, privateOrderPayload);
      batch.set(publicTrackingRef, publicTrackingPayload);

      // Commit atomically
      await batch.commit();

      // Save customer profile securely
      if (currentUser && currentUser.uid) {
        const userProfileRef = doc(db, 'users', currentUser.uid);
        await setDoc(userProfileRef, {
          customerName: customerName.trim(),
          customerPhone: cleanPhone,
          city: cleanAddress.slice(0, 100),
          updatedAt: serverTimestamp()
        }, { merge: true });
      }

      // Save to localStorage for offline resilience & duplicate protection
      try {
        const existingStored = localStorage.getItem('ankur_dryice_placed_orders_v1');
        const list: any[] = existingStored ? JSON.parse(existingStored) : [];
        const recordToStore = {
          ...privateOrderPayload,
          createdAtMs: Date.now(),
        };
        const updatedList = [recordToStore, ...list.filter((o: any) => o.orderId !== generatedOrderId)].slice(0, 20);
        localStorage.setItem('ankur_dryice_placed_orders_v1', JSON.stringify(updatedList));
      } catch (e) {
        console.warn('Could not save order locally:', e);
      }

      setSuccessData({
        orderId: generatedOrderId,
        trackingPin: generatedPin,
        customerName: customerName.trim(),
        customerPhone: cleanPhone,
        address: cleanAddress,
        quantityKg: finalQuantityKg,
        totalAmount: finalTotalAmount,
        dispatchTiming: dispatchTiming,
      });

      onOrderSuccess(generatedOrderId, generatedPin);
      if (onClearReorder) onClearReorder();
    } catch (err: unknown) {
      console.error('Failed to submit order:', err);
      try {
        handleFirestoreError(err, OperationType.WRITE, 'orders');
      } catch (e: any) {
        setErrorMsg('डेटाबेस में ऑर्डर सेव करने में त्रुटि आई। कृपया दोबारा प्रयास करें या कॉल करें।');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setErrorMsg(null);

    // Validate Name
    if (!customerName.trim() || customerName.trim().length < 2) {
      setErrorMsg('कृपया अपना सही नाम दर्ज करें (कम से कम 2 अक्षर)।');
      return;
    }

    // Validate Indian Mobile Number
    if (!validatePhone(customerPhone)) {
      setErrorMsg('कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें (शुरुआत 6, 7, 8 या 9 से)।');
      return;
    }

    // Validate City: शहर
    if (!address.trim() || address.trim().length < 2) {
      setErrorMsg('कृपया अपना शहर दर्ज करें (कम से कम 2 अक्षर)।');
      return;
    }

    // Validate Quantity: minimum 10 KG
    const parsedQty = parseFloat(quantityInput);
    if (!quantityInput.trim() || isNaN(parsedQty) || parsedQty < 10) {
      setErrorMsg('न्यूनतम ऑर्डर 10 KG है। कृपया कम से कम 10 KG मात्रा दर्ज करें।');
      return;
    }
    if (parsedQty > 5000) {
      setErrorMsg('अधिकतम ऑर्डर मात्रा 5,000 kg तक है। बड़ी मात्रा के लिए कृपया सीधे कॉल करें।');
      return;
    }

    // Validate selected dispatch timing slot
    const selectedSlotObj = dispatchSlots.find(s => s.label === dispatchTiming);
    if (selectedSlotObj && selectedSlotObj.disabled) {
      setErrorMsg('यह डिस्पैच समय अब समाप्त हो चुका है। कृपया दूसरा उपलब्ध समय चुनें।');
      return;
    }

    // Duplicate Order Protection: Check for existing matching order within 24 hours
    try {
      const existingMatch = await findRecentMatchingOrder(customerPhone);
      if (existingMatch) {
        setDuplicatePreviousOrder(existingMatch);
        setShowDuplicateModal(true);
        return;
      }
    } catch (e) {
      console.warn('Error during duplicate check:', e);
    }

    // If no duplicate found, proceed to place order
    await executeOrderSubmission();
  };

  const copyText = (text: string, type: 'id' | 'pin') => {
    navigator.clipboard.writeText(text);
    if (type === 'id') {
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } else {
      setCopiedPin(true);
      setTimeout(() => setCopiedPin(false), 2000);
    }
  };

  return (
    <div className="max-w-xl mx-auto py-3 px-3 sm:px-4">
      {/* Duplicate Order Warning Popup Modal */}
      {showDuplicateModal && duplicatePreviousOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-amber-300 max-w-md w-full overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-amber-500 to-orange-500 p-3.5 sm:p-4 text-white flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-sm sm:text-base leading-tight">डुप्लीकेट ऑर्डर चेतावनी (Duplicate Order Warning)</h3>
                <p className="text-amber-100 text-xs mt-0.5">
                  पिछले 24 घंटों में आपका एक मिलता-जुलता ऑर्डर पहले से दर्ज है
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowDuplicateModal(false)}
                className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                title="बंद करें"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-4 sm:p-5 space-y-3.5 text-slate-800">
              <p className="text-xs text-slate-600 leading-relaxed">
                गलती से डबल बुकिंग होने से बचाने के लिए यह जांच की गई है। आपके मोबाइल नंबर (<strong className="text-slate-900 font-mono">{duplicatePreviousOrder.customerPhone}</strong>) पर दर्ज पिछले ऑर्डर का विवरण:
              </p>

              {/* Actual Previous Order Details Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 sm:p-3.5 space-y-2 text-xs">
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-200">
                  <span className="text-slate-500 font-medium">Previous Order ID:</span>
                  <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                    #{duplicatePreviousOrder.orderId}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Customer Name (ग्राहक का नाम):</span>
                  <span className="font-semibold text-slate-900">{duplicatePreviousOrder.customerName}</span>
                </div>

                <div className="flex items-start justify-between gap-2">
                  <span className="text-slate-500 font-medium shrink-0">Customer Place/City/Address (जगह):</span>
                  <span className="font-semibold text-slate-900 text-right">{duplicatePreviousOrder.address || duplicatePreviousOrder.city || duplicatePreviousOrder.district || 'उत्तर प्रदेश'}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Product & Quantity:</span>
                  <span className="font-semibold text-sky-800 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                    {duplicatePreviousOrder.productName || 'ड्राई आइस (Dry Ice)'} • {duplicatePreviousOrder.quantityKg} KG
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Total Amount:</span>
                  <span className="font-mono font-bold text-slate-900 text-sm">
                    ₹{duplicatePreviousOrder.totalAmount}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                  <span className="text-slate-500 font-medium">Order Status:</span>
                  <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                    duplicatePreviousOrder.status === 'confirmed' ? 'bg-emerald-100 text-emerald-800' :
                    duplicatePreviousOrder.status === 'dispatched' ? 'bg-blue-100 text-blue-800' :
                    duplicatePreviousOrder.status === 'delivered' ? 'bg-purple-100 text-purple-800' :
                    'bg-amber-100 text-amber-800'
                  }`}>
                    {getStatusLabel(duplicatePreviousOrder.status)}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-1">
                {/* 1. Continue previous order */}
                <button
                  type="button"
                  onClick={() => {
                    setShowDuplicateModal(false);
                    if (onGoToTrack) {
                      onGoToTrack(duplicatePreviousOrder.orderId, duplicatePreviousOrder.trackingPin || '');
                    }
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>पिछला ऑर्डर जारी रखें / ट्रैक करें (Continue Previous Order)</span>
                </button>

                {/* 2. Explicitly confirm genuine second order */}
                <button
                  type="button"
                  disabled={submitting}
                  onClick={async () => {
                    setShowDuplicateModal(false);
                    await executeOrderSubmission();
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-600" />
                      <span>ऑर्डर बुक हो रहा है...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>हाँ, नया (दूसरा) ऑर्डर बुक करें (Confirm Genuine Second Order)</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* 1. TODAY'S RATE PROMINENT COMPACT BANNER */}
      <div className="bg-gradient-to-r from-sky-50 via-white to-sky-50 border border-sky-200/90 rounded-2xl p-3 sm:p-3.5 mb-3 text-center shadow-2xs">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-sky-100/90 text-sky-800 text-[11px] font-bold mb-1.5 border border-sky-200">
          <Snowflake className="w-3.5 h-3.5 text-sky-600" />
          <span>आज का रेट</span>
        </div>
        <div className="text-xs sm:text-sm font-semibold text-slate-800 flex flex-wrap items-center justify-center gap-x-2 gap-y-1">
          <span>ड्राई आइस: <strong className="font-mono text-sky-700 font-bold">₹{rates.dryIceRate}/kg</strong></span>
          <span className="text-slate-300 hidden sm:inline">&bull;</span>
          <span>थर्माकोल फुल पैकिंग: <strong className="font-mono text-sky-700 font-bold">₹{rates.thermocolRate}/kg</strong></span>
          <span className="text-slate-300 hidden sm:inline">&bull;</span>
          <span className="bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-md border border-emerald-200 font-bold">
            कुल: ₹{rates.dryIceRate + rates.thermocolRate}/kg
          </span>
        </div>
        <p className="text-[10px] sm:text-[11px] text-slate-500 mt-1">
          कोई छुपा शुल्क नहीं (No hidden fees) &bull; किसी भी कस्टम मात्रा में उपलब्ध
        </p>
      </div>

      {/* Customer Google Login Gate / Authenticated Booking Flow */}
      {!currentUser ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 text-center space-y-4 shadow-sm my-6">
          <div className="w-16 h-16 bg-sky-100 text-sky-600 rounded-full flex items-center justify-center mx-auto mb-2">
            <User className="w-8 h-8" />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-950">
            ड्राई आइस बुकिंग के लिए लॉगिन करें
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 max-w-sm mx-auto">
            ऑर्डर बुक करने और ट्रैकिंग देखने के लिए कृपया अपने Google (Gmail) अकाउंट से सुरक्षित रूप से लॉगिन करें।
          </p>
          <div className="pt-2">
            <button
              type="button"
              onClick={handleCustomerGoogleSignIn}
              disabled={customerLoggingIn}
              className="w-full max-w-xs mx-auto py-3 px-4 bg-sky-500 hover:bg-sky-600 text-white rounded-xl font-bold text-sm shadow-md flex items-center justify-center gap-2.5 transition-colors cursor-pointer disabled:opacity-50"
            >
              {customerLoggingIn ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>लॉगिन हो रहा है...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 bg-white rounded-full p-0.5 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#4FB3F8" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#FBBC05" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                  <span>Google से लॉगिन करें</span>
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {/* Authenticated Customer Profile Greeting & Logout */}
          <div className="bg-sky-50/70 border border-sky-200/90 rounded-xl p-2.5 sm:p-3 flex items-center justify-between gap-2 shadow-2xs">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-sky-500 text-white font-bold text-xs flex items-center justify-center shrink-0 overflow-hidden ring-1 ring-sky-300">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL} alt={currentUser.displayName || 'Profile'} className="w-full h-full object-cover" />
                ) : (
                  (currentUser.displayName || currentUser.email || 'U').charAt(0).toUpperCase()
                )}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-slate-900 truncate flex items-center gap-1.5">
                  <span>नमस्ते, {currentUser.displayName || 'ग्राहक'}</span>
                  <span className="text-[10px] font-normal text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                    लॉगिन
                  </span>
                </div>
                <p className="text-[10px] text-slate-500 truncate">
                  {currentUser.email} &bull; आपका खाता सुरक्षित है
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => signOutUser()}
              className="text-[11px] text-slate-500 hover:text-rose-600 font-semibold px-2 py-1 rounded-lg border border-slate-200 hover:border-rose-200 hover:bg-white transition-colors shrink-0 cursor-pointer"
              title="लॉगआउट करें"
            >
              लॉगआउट
            </button>
          </div>

          {/* Product picked on the storefront */}
          {selectedProduct && (
            <div className="p-2.5 rounded-lg bg-sky-50 border border-sky-200 text-sky-900 text-xs flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="font-extrabold truncate">चुना गया प्रोडक्ट: {selectedProduct.hindiName}</div>
                <div className="text-[11px] text-sky-700">₹{rates.dryIceRate + rates.thermocolRate}/kg (थर्मोकोल पैकिंग सहित)</div>
              </div>
              {onClearProduct && (
                <button type="button" onClick={onClearProduct} className="text-sky-600 hover:text-sky-800 text-[11px] font-bold shrink-0 underline">
                  बदलें
                </button>
              )}
            </div>
          )}

          {/* Reorder notification banner if active */}
          {reorderNotice && (
            <div className="p-2 rounded-lg bg-sky-50 border border-sky-200 text-sky-800 text-xs flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 min-w-0">
                <RotateCcw className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                <span className="truncate">{reorderNotice}</span>
              </div>
              <button
                onClick={() => {
                  setReorderNotice(null);
                  if (onClearReorder) onClearReorder();
                }}
                className="text-sky-500 hover:text-sky-700 p-0.5 shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Success Modal / Screen with Optional Payment Screenshot */}
          {successData && (
            <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
              <div className="bg-white rounded-2xl max-w-md w-full p-4 sm:p-5 shadow-2xl border border-slate-100 my-auto animate-in fade-in zoom-in-95 duration-150">
                <div className="text-center mb-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <CheckCircle className="w-7 h-7" />
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900">
                    ऑर्डर सफलतापूर्वक बुक हुआ!
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    आपका ड्राई आइस ऑर्डर सुरक्षित रूप से दर्ज कर लिया गया है।
                  </p>
                </div>

                {/* Secret Credentials Card */}
                <div className="bg-sky-50/70 border border-sky-200 rounded-xl p-3 mb-3 space-y-2">
                  <div>
                    <div className="text-[10px] font-semibold text-sky-800 uppercase tracking-wider mb-0.5">
                      ऑर्डर नंबर (Order ID)
                    </div>
                    <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded-lg border border-sky-200 font-mono font-bold text-xs text-slate-900">
                      <span>{successData.orderId}</span>
                      <button
                        onClick={() => copyText(successData.orderId, 'id')}
                        className="text-sky-600 hover:text-sky-800 p-1"
                        title="कॉपी करें"
                      >
                        {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="text-[10px] font-semibold text-sky-800 uppercase tracking-wider mb-0.5 flex items-center justify-between">
                      <span>गोपनीय ट्रैकिंग पिन (Tracking PIN)</span>
                      <span className="text-[10px] font-normal text-rose-600">सुरक्षित रखें</span>
                    </div>
                    <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded-lg border border-sky-200 font-mono font-bold text-xs text-slate-900">
                      <span className="tracking-widest text-emerald-700">{successData.trackingPin}</span>
                      <button
                        onClick={() => copyText(successData.trackingPin, 'pin')}
                        className="text-sky-600 hover:text-sky-800 p-1"
                        title="कॉपी करें"
                      >
                        {copiedPin ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="pt-1 border-t border-sky-200 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>मात्रा:</span>
                      <span className="font-semibold text-slate-900">{successData.quantityKg} KG</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>कुल राशि:</span>
                      <span className="font-bold text-emerald-700 font-mono">₹{successData.totalAmount}</span>
                    </div>
                    <div className="text-[11px] text-amber-700 pt-1 font-semibold flex items-center gap-1">
                      <CreditCard className="w-3 h-3 text-amber-600 shrink-0" />
                      <span>पेमेंट स्थिति: वेरिफिकेशन प्रतीक्षित (ओनर द्वारा बैंक/UPI वेरीफाई होने पर अपडेट होगा)</span>
                    </div>
                  </div>
                </div>

                {/* 5. UPI / QR PAYMENT & SCREENSHOT SHARING SECTION */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 mb-0 text-xs space-y-2.5">
                  <div className="font-bold text-slate-900 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-sky-600" />
                      <span>UPI / QR से भुगतान करें</span>
                    </div>
                    <span className="text-[10px] bg-sky-100 text-sky-800 font-semibold px-2 py-0.5 rounded-full">
                      Paytm / PhonePe / GPay
                    </span>
                  </div>

                  {/* Payment Barcode / QR Code */}
                  <div className="bg-white border border-sky-100 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-2xs">
                    <div className="text-[11px] font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
                      <QrCode className="w-3.5 h-3.5 text-sky-600" />
                      <span>पेमेंट बारकोड / QR स्कैन करें (Google Pay / any UPI)</span>
                    </div>
                    <div className="p-1.5 bg-slate-50 border border-slate-200 rounded-lg shadow-2xs max-w-[210px] sm:max-w-[230px]">
                      <img
                        src="/assets/aistudio/google_pay_qr.png"
                        alt="पेमेंट बारकोड / QR कोड - Ankur Pratap Singh"
                        className="w-full h-auto rounded object-contain max-h-[260px]"
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 mt-1.5 font-medium">
                      GPay, PhonePe, Paytm या किसी भी UPI ऐप से स्कैन करके पेमेंट करें
                    </span>
                  </div>

                  <div className="bg-white border border-sky-200 rounded-lg p-2.5 flex items-center justify-between shadow-2xs">
                    <div>
                      <div className="text-[10px] text-slate-500 font-semibold">UPI ID / Paytm नंबर:</div>
                      <div className="font-mono font-bold text-slate-900 text-xs">8896332066@paytm</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText('8896332066@paytm');
                        setCopiedUpi(true);
                        setTimeout(() => setCopiedUpi(false), 2000);
                      }}
                      className="px-2 py-1 text-[11px] font-semibold text-sky-600 hover:text-sky-800 bg-sky-50 rounded-md border border-sky-200 flex items-center gap-1 cursor-pointer transition-colors"
                      title="UPI ID कॉपी करें"
                    >
                      {copiedUpi ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedUpi ? 'कॉपी हुआ' : 'कॉपी करें'}</span>
                    </button>
                  </div>
                  
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    Paytm Business या किसी भी UPI ऐप से राशि <strong className="text-slate-900 font-mono">₹{successData.totalAmount}</strong> का भुगतान करें। भुगतान के बाद नीचे से स्क्रीनशॉट चुनकर ओनर (+91 8896332066) को WhatsApp पर भेजें।
                  </p>

                  {/* Optional Screenshot Picker */}
                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                      पेमेंट का स्क्रीनशॉट चुनें (वैकल्पिक):
                    </label>
                    <div className="flex items-center gap-2">
                      <label className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 hover:border-sky-500 text-slate-700 text-xs font-semibold cursor-pointer flex items-center gap-1.5 transition-colors">
                        <Upload className="w-3.5 h-3.5 text-sky-600" />
                        <span>{paymentScreenshot ? 'दूसरा स्क्रीनशॉट चुनें' : 'पेमेंट का स्क्रीनशॉट चुनें'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleScreenshotChange}
                          className="hidden"
                        />
                      </label>
                      {paymentScreenshot && (
                        <button
                          type="button"
                          onClick={handleRemoveScreenshot}
                          className="text-rose-600 hover:text-rose-800 text-[11px] font-semibold p-1"
                        >
                          हटाएं
                        </button>
                      )}
                    </div>

                    {screenshotPreview && (
                      <div className="mt-2 p-2 bg-emerald-50 rounded-lg border border-emerald-200 space-y-1.5">
                        <div className="flex items-center gap-2">
                          <img 
                            src={screenshotPreview} 
                            alt="Payment Preview" 
                            className="w-11 h-11 object-cover rounded-md border border-emerald-300 shadow-xs" 
                          />
                          <div className="min-w-0 flex-1 text-[11px]">
                            <span className="text-slate-800 font-medium truncate block">{paymentScreenshot?.name}</span>
                            <span className="text-emerald-700 font-bold text-[10px] flex items-center gap-1">
                              <Check className="w-3 h-3 text-emerald-600" /> स्क्रीनशॉट चुना गया
                            </span>
                          </div>
                        </div>
                        <div className="text-[10px] text-emerald-900 bg-white/90 p-1.5 rounded border border-emerald-100 font-medium">
                          💡 <strong>निर्देश:</strong> नीचे &quot;WhatsApp पर पेमेंट फोटो भेजें&quot; दबाने पर <strong>+91 8896332066</strong> की चैट खुलेगी। वहां <strong>Attach (+) / गैलरी</strong> से यही स्क्रीनशॉट सेंड करें।
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Send Photo to WhatsApp Button */}
                  <a
                    href={getWhatsAppPaymentDeepLink(successData.orderId)}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => {
                      e.preventDefault();
                      handleSharePaymentScreenshot(successData.orderId);
                    }}
                    className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-sm text-center"
                  >
                    <MessageCircle className="w-4 h-4 fill-current" />
                    <span>WhatsApp पर पेमेंट फोटो भेजें</span>
                  </a>

                  {shareFeedback && (
                    <div className="text-[11px] text-emerald-950 bg-emerald-50 p-2 rounded-lg border border-emerald-200 space-y-0.5">
                      <div className="flex items-center gap-1 font-bold text-emerald-800">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>WhatsApp चैट लिंक (+91 8896332066)</span>
                      </div>
                      <p className="text-emerald-900 text-[10px] leading-relaxed">{shareFeedback}</p>
                    </div>
                  )}

                  <p className="text-[10px] text-slate-400">
                    नोट: स्क्रीनशॉट सर्वर पर स्टोर नहीं किया जाता — केवल ओनर को WhatsApp (+91 8896332066) सत्यापन हेतु भेजा जाता है।
                  </p>

                  {/* Notify Staff via WhatsApp */}
                  <a
                    href={getWhatsAppPaymentDeepLink(successData.orderId)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-[11px] flex items-center justify-center gap-1 transition-colors cursor-pointer shadow-sm text-center mb-2"
                  >
                    <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                    <span className="leading-tight">स्टाफ को WhatsApp भेजें</span>
                  </a>

                  {/* Navigation link to My Orders */}
                  <div className="pt-2 text-center border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => {
                        setSuccessData(null);
                        onGoToMyOrders?.();
                      }}
                      className="text-xs text-sky-600 hover:text-sky-800 font-semibold underline underline-offset-4 cursor-pointer inline-flex items-center gap-1 transition-colors"
                    >
                      <span>मेरे सभी ऑर्डर देखें</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Main Booking Form */}
          <div className="bg-white border border-slate-200 rounded-2xl p-3.5 sm:p-4 shadow-xs">
            <div className="border-b border-slate-100 pb-2.5 mb-3 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="p-1 rounded-md bg-sky-50 text-sky-600">
                  <Snowflake className="w-4 h-4" />
                </span>
                <h2 className="text-base font-bold text-slate-900">
                  ड्राई आइस बुकिंग फॉर्म
                </h2>
              </div>
              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                ₹60/kg ऑल-इन
              </span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                {/* 1. ग्राहक का नाम */}
                <div>
                  <label className="text-xs font-semibold text-slate-800 block mb-1 truncate">
                    ग्राहक का नाम <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="उदा. राहुल शर्मा"
                      className="w-full bg-white border border-slate-300 rounded-lg pl-8 pr-2 py-1.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                </div>

                {/* 2. मोबाइल नंबर */}
                <div>
                  <label className="text-xs font-semibold text-slate-800 block mb-1 truncate">
                    मोबाइल नंबर (10 अंक) <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="उदा. 9876543210"
                      className="w-full bg-white border border-slate-300 rounded-lg pl-8 pr-2 py-1.5 text-xs sm:text-sm font-mono text-slate-900 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                </div>
              </div>

              {/* ROW 2: [ शहर ] [ मात्रा (KG) ] */}
              <div className="grid grid-cols-2 gap-2">
                {/* 3. शहर */}
                <div>
                  <label className="text-xs font-semibold text-slate-800 block mb-1 truncate">
                    शहर <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      required
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="उदा. लखनऊ"
                      className="w-full bg-white border border-slate-300 rounded-lg pl-8 pr-2 py-1.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                </div>

                {/* 4. मात्रा (KG) */}
                <div>
                  <label className="text-xs font-semibold text-slate-800 block mb-1 truncate">
                    मात्रा (KG) <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      inputMode="decimal"
                      required
                      value={quantityInput}
                      onChange={(e) => {
                        const val = e.target.value.replace(/[^0-9.]/g, '');
                        const parts = val.split('.');
                        if (parts.length > 2) return;
                        setQuantityInput(val);
                      }}
                      placeholder="उदा. 10, 25"
                      className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs sm:text-sm font-mono font-bold text-slate-900 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                </div>
              </div>
              <div className="flex justify-between text-[10px] text-slate-500">
                <span className="text-amber-700 font-medium">न्यूनतम ऑर्डर 10 KG है।</span>
                <span className="font-mono font-bold text-sky-700">{currentQuantityKg > 0 ? `${currentQuantityKg} KG` : ''}</span>
              </div>

              {/* 5. डिस्पैच का समय (Exact IST Slots) */}
              <div className="pt-0.5">
                <label className="text-xs font-semibold text-slate-800 block mb-1">
                  डिस्पैच का समय (IST) <span className="text-rose-500">*</span>
                </label>

                <div className="grid grid-cols-2 gap-2.5">
                  {dispatchSlots.map((slot) => {
                    const titleText = 
                      slot.id === 'today_morning' ? 'आज सुबह' :
                      slot.id === 'today_evening' ? 'आज शाम' :
                      slot.id === 'tomorrow_morning' ? 'कल सुबह' : 'कल शाम';

                    return (
                      <label
                        key={slot.id}
                        className={`flex flex-col justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                          slot.disabled
                            ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed opacity-60'
                            : dispatchTiming === slot.label
                            ? 'bg-sky-50 border-sky-500 text-sky-950 ring-2 ring-sky-400 shadow-xs'
                            : 'bg-white border-slate-300 text-slate-700 hover:border-sky-300 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <input
                            type="radio"
                            name="dispatchTiming"
                            value={slot.label}
                            disabled={slot.disabled}
                            checked={dispatchTiming === slot.label}
                            onChange={() => setDispatchTiming(slot.label)}
                            className="accent-sky-600 w-4 h-4"
                          />
                          {slot.disabled && (
                            <span className="text-[10px] text-rose-600 font-bold bg-rose-50 px-1 py-0.5 rounded">
                              समय समाप्त
                            </span>
                          )}
                        </div>
                        <div className="font-bold text-xs sm:text-sm text-slate-900">
                          {titleText}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                          {slot.timeWindow}
                        </div>
                      </label>
                    );
                  })}
                </div>
                <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-sky-600 shrink-0" />
                  <span>विंडो समाप्त होने के बाद स्लॉट स्वतः बंद हो जाते हैं।</span>
                </p>
              </div>

              {/* 6. कुल कीमत (Price Breakup) */}
              <div className="bg-sky-50/70 rounded-xl p-2.5 sm:p-3 border border-sky-200 text-xs space-y-1">
                <div className="font-bold text-slate-800 text-xs mb-1">
                  कुल कीमत
                </div>

                <div className="flex justify-between text-slate-600 text-[11px] sm:text-xs">
                  <span>ड्राई आइस ({currentQuantityKg} kg × ₹{rates.dryIceRate}):</span>
                  <span className="font-mono font-semibold text-slate-900">₹{dryIceSubtotal}</span>
                </div>

                <div className="flex justify-between text-slate-600 text-[11px] sm:text-xs">
                  <span>थर्मोकोल फुल पैकिंग ({currentQuantityKg} kg × ₹{rates.thermocolRate}):</span>
                  <span className="font-mono font-semibold text-slate-900">₹{thermocolSubtotal}</span>
                </div>

                <div className="flex justify-between items-baseline pt-1 border-t border-sky-200">
                  <span className="font-bold text-slate-900">कुल देय राशि:</span>
                  <div className="text-right">
                    <span className="text-base sm:text-lg font-black font-mono text-emerald-700">
                      ₹{totalAmount}
                    </span>
                    <span className="text-[10px] text-slate-500 block">
                      (₹{rates.dryIceRate + rates.thermocolRate}/kg - कोई छुपा शुल्क नहीं)
                    </span>
                  </div>
                </div>
              </div>

              {/* 7. Payment Instructions */}
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600">
                <span className="font-bold text-slate-800 block mb-0.5 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-sky-600" />
                  पेमेंट निर्देश
                </span>
                <p className="leading-relaxed text-[11px]">
                  पेमेंट: Paytm Business / किसी भी UPI ऐप द्वारा भुगतान करें। ऑर्डर बुक होने के बाद आप पेमेंट का स्क्रीनशॉट WhatsApp पर ओनर को भेज सकते हैं। ओनर द्वारा मैन्युअल सत्यापन के बाद पेमेंट वेरीफाई होगा।
                </p>
              </div>

              {/* Error message */}
              {errorMsg && (
                <div className="p-2 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 px-4 rounded-xl bg-sky-500 hover:bg-sky-600 active:bg-sky-700 text-white font-bold text-sm tracking-wide shadow-xs flex items-center justify-center gap-2 transition-colors disabled:opacity-50 cursor-pointer"
              >
                {submitting ? (
                  <>
                    <Snowflake className="w-4 h-4 animate-spin text-white" />
                    <span>ऑर्डर सेव हो रहा है...</span>
                  </>
                ) : (
                  <>
                    <span>ऑर्डर बुक करें (₹{totalAmount})</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Contact Strip with Business Contact +91 8896332066 */}
            <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>सहायता के लिए संपर्क करें:</span>
              <div className="flex items-center gap-3">
                <a
                  href={BUSINESS_CALL_HREF}
                  className="text-sky-700 font-bold hover:underline flex items-center gap-1"
                  title={`कॉल करें (${BUSINESS_PHONE_DISPLAY})`}
                >
                  <Phone className="w-3 h-3" />
                  <span>कॉल ({BUSINESS_PHONE_DISPLAY})</span>
                </a>
                <a
                  href={getFormWhatsAppInquiryLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
                  title={`WhatsApp (${BUSINESS_PHONE_DISPLAY})`}
                >
                  <MessageCircle className="w-3 h-3" />
                  <span>व्हाट्सएप</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
