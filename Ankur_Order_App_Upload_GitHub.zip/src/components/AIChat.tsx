import React, { useState } from 'react';
import { MessageCircle, Loader2, Send } from 'lucide-react';
import { authHeaders, getApiBase } from '../utils/apiBase';

export const AIChat: React.FC<{ context: string }> = ({ context }) => {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: 'नमस्ते! मैं आपकी ऑर्डर डिटेल्स का विश्लेषण कर सकता हूँ। आप क्या जानना चाहेंगे?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;
    
    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setLoading(true);

    try {
      const base = getApiBase();
      if (base === null) {
        setMessages(prev => [...prev, { role: 'ai', text: 'AI चैट सर्वर इस ऐप में जुड़ा नहीं है (VITE_API_BASE_URL सेट नहीं)।' }]);
        return;
      }
      const response = await fetch(`${base}/api/gemini/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(await authHeaders()) },
        body: JSON.stringify({ message: userMessage, context }),
      });
      if (response.status === 401 || response.status === 403) {
        setMessages(prev => [...prev, { role: 'ai', text: 'यह सुविधा सिर्फ़ मालिक के लॉगिन से चलती है।' }]);
        return;
      }
      const data = await response.json();
      setMessages(prev => [...prev, { role: 'ai', text: data.response || 'क्षमा करें, मैं अभी जवाब देने में असमर्थ हूँ।' }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'ai', text: 'सर्वर त्रुटि। कृपया पुनः प्रयास करें।' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[520px] border border-slate-200 rounded-2xl bg-slate-50 p-3 sm:p-4 shadow-xs">
      <div className="flex-1 overflow-y-auto space-y-2.5 mb-3 pr-1">
        {messages.map((msg, i) => (
          <div 
            key={i} 
            className={`p-3 rounded-2xl text-xs sm:text-sm max-w-[85%] leading-relaxed whitespace-pre-wrap ${
              msg.role === 'user' 
                ? 'bg-sky-500 text-white ml-auto shadow-2xs rounded-br-xs' 
                : 'bg-white border border-slate-200 text-slate-800 shadow-2xs rounded-bl-xs'
            }`}
          >
            {msg.text}
          </div>
        ))}
        {loading && (
          <div className="p-3 text-slate-500 bg-white border border-slate-200 rounded-2xl max-w-[80px] flex items-center justify-center">
            <Loader2 className="animate-spin w-4 h-4 text-sky-600" />
          </div>
        )}
      </div>
      <div className="flex items-center gap-2 pt-2 border-t border-slate-200/80">
        <input 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          className="flex-1 px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500"
          placeholder="ऑर्डर्स के बारे में कुछ भी पूछें (उदा. आज कुल कितनी बुकिंग हुई?)..."
        />
        <button 
          onClick={sendMessage} 
          disabled={loading || !input.trim()}
          className="p-2.5 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white rounded-xl cursor-pointer transition-colors shadow-2xs shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
