import type { Order } from '../types';
import type { PickupState } from './selfPickup';
export interface PickupViewer { uid: string; isOwner: boolean; }
/** UI visibility only; Firebase rules must independently authorize reads. */
export function canViewPickupReceipt(order: Order, pickup: PickupState, viewer: PickupViewer): boolean {
  return !!viewer.uid && (viewer.isOwner || order.userId === viewer.uid)
    && pickup.status === 'pickup_completed' && pickup.receiptStatus === 'valid'
    && !!pickup.completedAt && !!pickup.completedBy;
}
