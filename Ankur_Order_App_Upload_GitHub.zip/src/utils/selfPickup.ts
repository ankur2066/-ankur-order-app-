/** Self Pickup business rules. No Firebase writes or notifications occur in this module. */
export const PICKUP_UNDO_WINDOW_MS = 5 * 60 * 1000;

export type PickupReceiptStatus = 'valid' | 'cancelled';
export type PickupStatus = 'pickup_pending' | 'pickup_completed';

export interface PickupAudit {
  orderId: string;
  actorUid: string;
  action: 'pickup_confirmed' | 'pickup_undone';
  at: string;
  reason?: string;
}

export interface PickupState {
  status: PickupStatus;
  completedAt?: string;
  completedBy?: string;
  receiptStatus?: PickupReceiptStatus;
}

export function canUndoPickup(
  state: PickupState,
  nowMs: number,
  actorUid: string,
  isOwner: boolean,
): boolean {
  if (state.status !== 'pickup_completed') return false;
  if (isOwner) return true;
  if (!state.completedAt || !state.completedBy || actorUid !== state.completedBy) return false;
  const elapsed = nowMs - Date.parse(state.completedAt);
  return Number.isFinite(elapsed) && elapsed >= 0 && elapsed <= PICKUP_UNDO_WINDOW_MS;
}

export function confirmPickup(
  state: PickupState,
  orderId: string,
  actorUid: string,
  at: string,
): { state: PickupState; audit: PickupAudit } {
  if (state.status !== 'pickup_pending') throw new Error('Order is not awaiting pickup');
  if (!actorUid || !Number.isFinite(Date.parse(at))) throw new Error('Invalid pickup confirmation');
  return {
    state: { status: 'pickup_completed', completedAt: at, completedBy: actorUid, receiptStatus: 'valid' },
    audit: { orderId, actorUid, action: 'pickup_confirmed', at },
  };
}

export function undoPickup(
  state: PickupState,
  orderId: string,
  actorUid: string,
  isOwner: boolean,
  at: string,
  reason: string,
): { state: PickupState; audit: PickupAudit } {
  if (!reason.trim()) throw new Error('Undo reason is required');
  if (!canUndoPickup(state, Date.parse(at), actorUid, isOwner)) throw new Error('Pickup undo not permitted');
  return {
    state: { ...state, status: 'pickup_pending', receiptStatus: 'cancelled' },
    audit: { orderId, actorUid, action: 'pickup_undone', at, reason: reason.trim() },
  };
}
