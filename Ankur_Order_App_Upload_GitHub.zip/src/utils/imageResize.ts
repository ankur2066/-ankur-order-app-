/**
 * Shrinks a picked image in the browser before upload (max side, JPEG).
 * Keeps product photos small so the storefront stays fast on mobile data.
 */
export async function resizeImageToJpeg(file: File, maxSide = 900, quality = 0.82): Promise<Blob> {
  const bitmapUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('इमेज पढ़ी नहीं जा सकी'));
      el.src = bitmapUrl;
    });
    const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
    const w = Math.max(1, Math.round(img.width * scale));
    const h = Math.max(1, Math.round(img.height * scale));
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('इमेज प्रोसेस नहीं हो सकी');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/jpeg', quality));
    if (!blob) throw new Error('इमेज सेव नहीं हो सकी');
    return blob;
  } finally {
    URL.revokeObjectURL(bitmapUrl);
  }
}
