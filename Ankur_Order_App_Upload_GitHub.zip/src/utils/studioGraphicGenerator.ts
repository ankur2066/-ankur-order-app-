/**
 * Ankur Dry Ice & Events - Studio Graphic Engine
 * Generates ultra high-definition vector posters and visual mockups
 * for dry ice stage effects, wedding fog entries, mocktails, and packaging.
 */

export interface GraphicOptions {
  prompt?: string;
  theme?: 'wedding' | 'pyro' | 'cocktail' | 'box' | 'ratecard' | 'custom';
  aspectRatio?: '1:1' | '9:16' | '16:9';
  customTitle?: string;
  customSubtitle?: string;
  eventDate?: string;
  venue?: string;
  contactNumber?: string;
}

export function generateStudioGraphicSvg(options: GraphicOptions = {}): string {
  const {
    prompt = '',
    aspectRatio = '1:1',
    customTitle,
    customSubtitle,
    eventDate,
    venue,
    contactNumber = '+91 8896332066'
  } = options;

  let width = 1080;
  let height = 1080;
  if (aspectRatio === '9:16') {
    width = 1080;
    height = 1920;
  } else if (aspectRatio === '16:9') {
    width = 1920;
    height = 1080;
  }

  // Detect theme from prompt keywords or explicit option
  const p = prompt.toLowerCase();
  let theme = options.theme;
  if (!theme) {
    if (p.includes('शादी') || p.includes('wedding') || p.includes('dulha') || p.includes('stage') || p.includes('वरमाला')) {
      theme = 'wedding';
    } else if (p.includes('pyro') || p.includes('पायरो') || p.includes('spark') || p.includes('पटाखे') || p.includes('आतिशबाजी')) {
      theme = 'pyro';
    } else if (p.includes('cocktail') || p.includes('मॉकटेल') || p.includes('drink') || p.includes('glass') || p.includes('गिलास')) {
      theme = 'cocktail';
    } else if (p.includes('box') || p.includes('डिलीवरी') || p.includes('थर्माकोल') || p.includes('packing') || p.includes('पैकेट')) {
      theme = 'box';
    } else if (p.includes('rate') || p.includes('रेट') || p.includes('प्राइस') || p.includes('ऑफर')) {
      theme = 'ratecard';
    } else {
      theme = 'wedding'; // default to wedding stage smoke
    }
  }

  const title = customTitle || (
    theme === 'wedding' ? 'भव्य शादी स्टेज ड्राई आइस स्मोक' :
    theme === 'pyro' ? 'कोल्ड पायरो & स्टेज स्पेशल इफेक्ट्स' :
    theme === 'cocktail' ? 'स्मोकी मॉकटेल & पार्टी कूलिंग' :
    theme === 'box' ? 'प्रीमियम ड्राई आइस बॉक्स पैकिंग' :
    'अंकुर ड्राई आइस & स्पेशल इवेंट्स'
  );

  const subtitle = customSubtitle || (
    theme === 'wedding' ? 'ग्रैंड लो-लाइंग डेंस व्हाइट फॉग • वरमाला & एंट्री स्पेशल' :
    theme === 'pyro' ? 'धुआं-रहित सुरक्षित इनडोर व आउटडोर स्पार्कलर्स' :
    theme === 'cocktail' ? '100% फूड ग्रेड -78.5°C क्रिस्टल स्मोक इफ़ेक्ट' :
    theme === 'box' ? 'इंसुलेटेड थर्माकोल बॉक्स • 24 घंटे चिल्ड प्रोटेक्शन' :
    'ताज़ा ड्राई आइस सप्लायर • गोरखपुर व पूर्वांचल'
  );

  const cx = width / 2;
  const isTall = aspectRatio === '9:16';
  const isWide = aspectRatio === '16:9';

  const titleY = isTall ? 320 : isWide ? 160 : 200;
  const subtitleY = titleY + 60;
  const fogBottomY = height;

  // Color schemes based on theme
  let bgGradStart = '#070b19';
  let bgGradMid = '#0f172a';
  let bgGradEnd = '#0284c7';
  let glowColor = '#38bdf8';
  let accentColor = '#38bdf8';

  if (theme === 'wedding') {
    bgGradStart = '#180728';
    bgGradMid = '#2e1065';
    bgGradEnd = '#0369a1';
    glowColor = '#c084fc';
    accentColor = '#f472b6';
  } else if (theme === 'pyro') {
    bgGradStart = '#1a0d00';
    bgGradMid = '#451a03';
    bgGradEnd = '#9a3412';
    glowColor = '#f59e0b';
    accentColor = '#fbbf24';
  } else if (theme === 'cocktail') {
    bgGradStart = '#022c22';
    bgGradMid = '#064e3b';
    bgGradEnd = '#0284c7';
    glowColor = '#34d399';
    accentColor = '#2dd4bf';
  } else if (theme === 'box') {
    bgGradStart = '#0c1a2e';
    bgGradMid = '#1e293b';
    bgGradEnd = '#0284c7';
    glowColor = '#60a5fa';
    accentColor = '#38bdf8';
  }

  // Generate SVG code
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">
  <defs>
    <!-- Background Gradient -->
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="${bgGradStart}" />
      <stop offset="50%" stop-color="${bgGradMid}" />
      <stop offset="100%" stop-color="${bgGradEnd}" />
    </linearGradient>

    <!-- Fog radial glow -->
    <radialGradient id="fogCenterGlow" cx="50%" cy="85%" r="65%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.85" />
      <stop offset="40%" stop-color="#e0f2fe" stop-opacity="0.6" />
      <stop offset="75%" stop-color="${glowColor}" stop-opacity="0.2" />
      <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
    </radialGradient>

    <!-- Spotlight beam left -->
    <linearGradient id="spotlightLeft" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${glowColor}" stop-opacity="0.4" />
      <stop offset="80%" stop-color="${glowColor}" stop-opacity="0" />
    </linearGradient>

    <!-- Spotlight beam right -->
    <linearGradient id="spotlightRight" x1="100%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="${accentColor}" stop-opacity="0.4" />
      <stop offset="80%" stop-color="${accentColor}" stop-opacity="0" />
    </linearGradient>

    <!-- Badge gradient -->
    <linearGradient id="badgeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#0284c7" />
      <stop offset="100%" stop-color="#2563eb" />
    </linearGradient>

    <!-- Soft blur filter -->
    <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="16" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>

    <filter id="heavyFog" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="28" />
    </filter>
  </defs>

  <!-- Background -->
  <rect width="${width}" height="${height}" fill="url(#bgGrad)" />

  <!-- Stage Lights & Light Beams -->
  <polygon points="100,0 260,0 ${cx - 50},${height - 150} 80,${height - 100}" fill="url(#spotlightLeft)" opacity="0.6" />
  <polygon points="${width - 100},0 ${width - 260},0 ${cx + 50},${height - 150} ${width - 80},${height - 100}" fill="url(#spotlightRight)" opacity="0.6" />

  <!-- Stars / Sparkles -->
  <g fill="#ffffff" opacity="0.75">
    <circle cx="${cx - 380}" cy="${titleY - 80}" r="3" />
    <circle cx="${cx - 260}" cy="${titleY + 120}" r="2" />
    <circle cx="${cx + 340}" cy="${titleY - 60}" r="4" />
    <circle cx="${cx + 220}" cy="${titleY + 140}" r="2.5" />
    <circle cx="${cx - 150}" cy="${titleY - 100}" r="3.5" />
    <circle cx="${cx + 420}" cy="${titleY + 40}" r="2" />
    <circle cx="${cx - 420}" cy="${titleY + 220}" r="3" />
    <circle cx="${cx + 120}" cy="${titleY + 260}" r="2" />
  </g>

  <!-- Top Brand Banner Header -->
  <g transform="translate(${cx}, ${isTall ? 140 : isWide ? 60 : 80})">
    <!-- Brand Pill -->
    <rect x="-240" y="-30" width="480" height="52" rx="26" fill="#0f172a" fill-opacity="0.7" stroke="${glowColor}" stroke-width="1.5" />
    <text x="0" y="5" font-family="'Segoe UI', Roboto, sans-serif" font-size="22" font-weight="bold" fill="#ffffff" text-anchor="middle" letter-spacing="1">
      ❄️ ANKUR DRY ICE &amp; EVENTS ❄️
    </text>
  </g>

  <!-- Main Title -->
  <text x="${cx}" y="${titleY}" font-family="'Segoe UI', Roboto, 'Nirmala UI', sans-serif" font-size="${isWide ? 52 : 56}" font-weight="900" fill="#ffffff" text-anchor="middle" filter="url(#softGlow)">
    ${title}
  </text>

  <!-- Subtitle -->
  <text x="${cx}" y="${subtitleY}" font-family="'Segoe UI', Roboto, 'Nirmala UI', sans-serif" font-size="${isWide ? 26 : 28}" font-weight="600" fill="#bae6fd" text-anchor="middle">
    ${subtitle}
  </text>

  ${eventDate || venue ? `
  <!-- Event Info Pill (If provided) -->
  <g transform="translate(${cx}, ${subtitleY + 60})">
    <rect x="-260" y="-24" width="520" height="48" rx="24" fill="#0369a1" fill-opacity="0.85" stroke="#ffffff" stroke-width="1.5" />
    <text x="0" y="8" font-family="'Segoe UI', Roboto, sans-serif" font-size="20" font-weight="bold" fill="#ffffff" text-anchor="middle">
      ${[eventDate, venue].filter(Boolean).join(' • ')}
    </text>
  </g>
  ` : ''}

  <!-- Center Stage Visual Art / Illustration -->
  ${theme === 'wedding' ? `
    <!-- Wedding Floral Stage & Pyro Fountain Silhouette -->
    <g transform="translate(${cx}, ${height / 2 + (isTall ? 60 : 30)})">
      <!-- Glow disc -->
      <circle cx="0" cy="0" r="${isWide ? 180 : 220}" fill="${glowColor}" opacity="0.25" filter="url(#heavyFog)" />
      
      <!-- Stage Arc -->
      <path d="M -220,120 Q 0,-140 220,120" stroke="#fef08a" stroke-width="4" fill="none" opacity="0.8" />
      <path d="M -200,120 Q 0,-120 200,120" stroke="${glowColor}" stroke-width="2" fill="none" opacity="0.5" />

      <!-- Cold Pyro Left Fountain -->
      <g transform="translate(-190, 100)">
        <polygon points="-8,0 8,0 16,-180 -16,-180" fill="#fbbf24" opacity="0.75" />
        <polygon points="-4,0 4,0 8,-220 -8,-220" fill="#ffffff" opacity="0.9" />
      </g>
      <!-- Cold Pyro Right Fountain -->
      <g transform="translate(190, 100)">
        <polygon points="-8,0 8,0 16,-180 -16,-180" fill="#fbbf24" opacity="0.75" />
        <polygon points="-4,0 4,0 8,-220 -8,-220" fill="#ffffff" opacity="0.9" />
      </g>

      <!-- Center Silhouette (Couple / Stage Entry) -->
      <circle cx="-25" cy="-20" r="18" fill="#ffffff" opacity="0.95" />
      <path d="M -45,70 Q -40,10 -25,0 Q -10,10 -5,70 Z" fill="#ffffff" opacity="0.95" />
      <circle cx="25" cy="-15" r="16" fill="#fbcfe8" opacity="0.95" />
      <path d="M 5,75 Q 15,10 25,2 Q 35,10 45,75 Z" fill="#fbcfe8" opacity="0.95" />
    </g>
  ` : theme === 'pyro' ? `
    <!-- Cold Pyro Stage Sparkles Visual -->
    <g transform="translate(${cx}, ${height / 2 + (isTall ? 60 : 30)})">
      <circle cx="0" cy="0" r="240" fill="#f59e0b" opacity="0.2" filter="url(#heavyFog)" />
      <!-- Giant Spark Fountains -->
      <polygon points="-160,120 -130,120 -100,-240 -190,-240" fill="#fef08a" opacity="0.8" />
      <polygon points="130,120 160,120 190,-240 100,-240" fill="#fef08a" opacity="0.8" />
      <polygon points="-15,120 15,120 40,-260 -40,-260" fill="#ffffff" opacity="0.95" />
      <text x="0" y="40" font-family="'Segoe UI', Roboto, sans-serif" font-size="34" font-weight="900" fill="#ffffff" text-anchor="middle" filter="url(#softGlow)">
        ✨ SAFE COLD SPARKS ✨
      </text>
    </g>
  ` : theme === 'cocktail' ? `
    <!-- Mocktail Dry Ice Glass Visual -->
    <g transform="translate(${cx}, ${height / 2 + (isTall ? 40 : 20)})">
      <circle cx="0" cy="0" r="200" fill="#2dd4bf" opacity="0.2" filter="url(#heavyFog)" />
      <!-- Glass Shape -->
      <polygon points="-90,-60 90,-60 15,60 -15,60" fill="#ffffff" fill-opacity="0.2" stroke="#ffffff" stroke-width="3" />
      <line x1="0" y1="60" x2="0" y2="130" stroke="#ffffff" stroke-width="5" />
      <line x1="-50" y1="130" x2="50" y2="130" stroke="#ffffff" stroke-width="5" />
      <!-- Smoke billowing from glass -->
      <path d="M -60,-60 Q -90,-160 0,-190 Q 90,-160 60,-60 Z" fill="#ffffff" fill-opacity="0.7" filter="url(#softGlow)" />
      <text x="0" y="30" font-family="'Segoe UI', Roboto, sans-serif" font-size="28" font-weight="900" fill="#ffffff" text-anchor="middle">
        CHILLED FOOD-GRADE SMOKE
      </text>
    </g>
  ` : `
    <!-- Box & Pellets Visual -->
    <g transform="translate(${cx}, ${height / 2 + (isTall ? 50 : 25)})">
      <circle cx="0" cy="0" r="220" fill="#38bdf8" opacity="0.2" filter="url(#heavyFog)" />
      <!-- Thermocol Box -->
      <rect x="-160" y="-80" width="320" height="180" rx="16" fill="#f8fafc" stroke="#38bdf8" stroke-width="4" />
      <line x1="-160" y1="-20" x2="160" y2="-20" stroke="#cbd5e1" stroke-width="3" />
      <text x="0" y="40" font-family="'Segoe UI', Roboto, sans-serif" font-size="32" font-weight="900" fill="#0369a1" text-anchor="middle">
        -78.5°C DRY ICE
      </text>
      <text x="0" y="70" font-family="'Segoe UI', Roboto, sans-serif" font-size="18" font-weight="bold" fill="#64748b" text-anchor="middle">
        प्रीमियम इंसुलेटेड पैकिंग
      </text>
    </g>
  `}

  <!-- Low-Lying Dry Ice Fog Cloud Layers (The signature effect!) -->
  <g>
    <!-- Background fog glow -->
    <rect x="0" y="${height - (isTall ? 600 : isWide ? 380 : 480)}" width="${width}" height="${isTall ? 600 : isWide ? 380 : 480}" fill="url(#fogCenterGlow)" />

    <!-- Wave 1 (Soft dense base fog) -->
    <path d="M 0,${height - 300} Q ${width * 0.25},${height - 400} ${width * 0.5},${height - 320} T ${width},${height - 350} L ${width},${height} L 0,${height} Z" fill="#ffffff" fill-opacity="0.4" filter="url(#heavyFog)" />

    <!-- Wave 2 (Middle thick vapor cloud) -->
    <path d="M 0,${height - 240} Q ${width * 0.2},${height - 180} ${width * 0.4},${height - 270} T ${width * 0.8},${height - 220} T ${width},${height - 280} L ${width},${height} L 0,${height} Z" fill="#e0f2fe" fill-opacity="0.6" filter="url(#heavyFog)" />

    <!-- Wave 3 (Foreground pure white dense rolling smoke) -->
    <path d="M 0,${height - 180} C ${width * 0.15},${height - 230} ${width * 0.35},${height - 140} ${width * 0.55},${height - 210} C ${width * 0.75},${height - 260} ${width * 0.9},${height - 160} ${width},${height - 200} L ${width},${height} L 0,${height} Z" fill="#ffffff" fill-opacity="0.85" />
  </g>

  <!-- Footer Information Bar -->
  <g transform="translate(${cx}, ${height - (isTall ? 120 : isWide ? 70 : 90)})">
    <!-- Bottom Dark Pill -->
    <rect x="-380" y="-38" width="760" height="76" rx="38" fill="#0f172a" stroke="#38bdf8" stroke-width="2" />
    
    <!-- Phone / WhatsApp Contact -->
    <text x="-160" y="8" font-family="'Segoe UI', Roboto, sans-serif" font-size="24" font-weight="900" fill="#22c55e" text-anchor="middle">
      📞 ${contactNumber}
    </text>

    <!-- Divider -->
    <line x1="10" y1="-20" x2="10" y2="20" stroke="#475569" stroke-width="2" />

    <!-- Rate / Location -->
    <text x="180" y="8" font-family="'Segoe UI', Roboto, sans-serif" font-size="22" font-weight="bold" fill="#ffffff" text-anchor="middle">
      ₹60/KG • गोरखपुर &amp; पूर्वांचल
    </text>
  </g>

  <!-- Quality Guarantee Badge (Top Right) -->
  <g transform="translate(${width - 120}, ${isTall ? 140 : 100})">
    <circle cx="0" cy="0" r="46" fill="url(#badgeGrad)" stroke="#ffffff" stroke-width="2.5" />
    <text x="0" y="-8" font-family="'Segoe UI', Roboto, sans-serif" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">
      100% PURE
    </text>
    <text x="0" y="10" font-family="'Segoe UI', Roboto, sans-serif" font-size="15" font-weight="900" fill="#fef08a" text-anchor="middle">
      -78.5°C
    </text>
    <text x="0" y="24" font-family="'Segoe UI', Roboto, sans-serif" font-size="10" font-weight="bold" fill="#e0f2fe" text-anchor="middle">
      DRY ICE
    </text>
  </g>
</svg>`;
}

export function generateStudioGraphicDataUrl(options: GraphicOptions = {}): string {
  const svg = generateStudioGraphicSvg(options);
  // Safely handle both browser and node environments
  try {
    if (typeof window !== 'undefined' && typeof window.btoa === 'function') {
      const base64 = window.btoa(unescape(encodeURIComponent(svg)));
      return `data:image/svg+xml;base64,${base64}`;
    }
  } catch {
    // fallback to url encoded utf-8
  }

  if (typeof Buffer !== 'undefined') {
    const base64 = Buffer.from(svg, 'utf-8').toString('base64');
    return `data:image/svg+xml;base64,${base64}`;
  }

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
