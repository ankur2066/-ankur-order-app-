/**
 * Royal Indian Wedding Celebration Stage & Event Visualizer Engine
 * Features detailed Bride & Groom in royal wedding attire (Sherwani, Pagdi/Kalgi, Bridal Lehenga),
 * relatives & guests in the background showering flower petals, grand floral mandap,
 * dense rolling white low-fog clouds, active cold pyros, and the customer's personalized backdrop.
 */

export interface WeddingGraphicOptions {
  prompt?: string;
  theme?: 'varmala' | 'cloud-dance' | 'pyro-blast' | 'sangeet' | 'baraat' | 'doli';
  aspectRatio?: '1:1' | '9:16' | '16:9';
  groomBrideName?: string;
  backdropBanner?: string;
  firmOrFamilyName?: string;
  eventDate?: string;
  venue?: string;
  userPhotoUrl?: string | null;
  namePosition?: 'backdrop' | 'arch' | 'golden-board';
}

export function generateWeddingStageSvg(options: WeddingGraphicOptions = {}): string {
  const {
    prompt = '',
    aspectRatio = '1:1',
    groomBrideName = 'रोहन 💖 अंजलि',
    backdropBanner = 'शुभ विवाह • GRAND ROYAL WEDDING',
    firmOrFamilyName = 'ROYAL EVENTS & ENTERTAINMENT',
    eventDate = '28 नवम्बर 2026',
    venue = 'गोरखपुर पैलेस',
    userPhotoUrl = null
  } = options;

  let width = 1080;
  let height = 1080;
  if (aspectRatio === '9:16') {
    width = 1080;
    height = 1920;
  } else if (aspectRatio === '16:9') {
    width = 1920;
    height = 1080;
  }

  const cx = width / 2;
  const isTall = aspectRatio === '9:16';
  const isWide = aspectRatio === '16:9';

  // Detect theme
  const p = prompt.toLowerCase();
  let theme = options.theme;
  if (!theme) {
    if (p.includes('dance') || p.includes('क्लाउड') || p.includes('cloud')) {
      theme = 'cloud-dance';
    } else if (p.includes('pyro') || p.includes('पायरो') || p.includes('आतिशबाजी') || p.includes('spark')) {
      theme = 'pyro-blast';
    } else if (p.includes('संगीत') || p.includes('sangeet') || p.includes('dj') || p.includes('लेज़र')) {
      theme = 'sangeet';
    } else if (p.includes('बारात') || p.includes('baraat') || p.includes('दूल्हा')) {
      theme = 'baraat';
    } else if (p.includes('डोली') || p.includes('doli') || p.includes('दुल्हन')) {
      theme = 'doli';
    } else {
      theme = 'varmala';
    }
  }

  // Theme-specific color schemes & stage ambiances
  let bgTop = '#1a030c';
  let bgMid = '#3b0615';
  let bgBottom = '#08010d';
  let lightBeamL = '#fbbf24';
  let lightBeamR = '#f43f5e';
  let eventBadge = 'शाही वरमाला सेरेमनी • ROYAL WEDDING';

  if (theme === 'cloud-dance') {
    bgTop = '#0a0217';
    bgMid = '#20053b';
    bgBottom = '#02010a';
    lightBeamL = '#818cf8';
    lightBeamR = '#e879f9';
    eventBadge = 'जयमाला क्लाउड डांस • WALKING ON CLOUDS';
  } else if (theme === 'pyro-blast') {
    bgTop = '#1c0500';
    bgMid = '#3d0d02';
    bgBottom = '#050100';
    lightBeamL = '#f97316';
    lightBeamR = '#fbbf24';
    eventBadge = 'कोल्ड पायरो आतिशबाजी • STAGE FIREWORKS';
  } else if (theme === 'sangeet') {
    bgTop = '#140324';
    bgMid = '#3b0764';
    bgBottom = '#06010d';
    lightBeamL = '#06b6d4';
    lightBeamR = '#f43f5e';
    eventBadge = 'धमाकेदार संगीत & डीजे शो • CELEBRATION NIGHT';
  } else if (theme === 'baraat') {
    bgTop = '#2b0707';
    bgMid = '#581010';
    bgBottom = '#080101';
    lightBeamL = '#f59e0b';
    lightBeamR = '#ea580c';
    eventBadge = 'रॉयल बारात & दूल्हा एंट्री • GRAND ENTRY';
  } else if (theme === 'doli') {
    bgTop = '#18031a';
    bgMid = '#3d0542';
    bgBottom = '#060108';
    lightBeamL = '#f472b6';
    lightBeamR = '#fb7185';
    eventBadge = 'परीकथा दुल्हन डोली वॉक • BRIDAL ENTRY';
  }

  // Vertical placement adjustments
  const backdropY = isTall ? 380 : isWide ? 200 : 240;
  const coupleStageY = height - (isTall ? 520 : isWide ? 340 : 380);

  // Clean text inputs
  const safeNames = (groomBrideName || 'रोहन 💖 अंजलि').replace(/&/g, '&amp;');
  const safeBackdrop = (backdropBanner || 'शुभ विवाह').replace(/&/g, '&amp;');
  const safeFirm = (firmOrFamilyName || 'ROYAL EVENTS & ENTERTAINMENT').replace(/&/g, '&amp;');
  const safeDate = (eventDate || '').replace(/&/g, '&amp;');
  const safeVenue = (venue || '').replace(/&/g, '&amp;');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">
  <defs>
    <!-- Background Gradient -->
    <linearGradient id="weddingBg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="${bgTop}" />
      <stop offset="45%" stop-color="${bgMid}" />
      <stop offset="85%" stop-color="${bgBottom}" />
      <stop offset="100%" stop-color="#000000" />
    </linearGradient>

    <!-- Golden Foil Gradient -->
    <linearGradient id="goldLuxury" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fef08a" />
      <stop offset="25%" stop-color="#f59e0b" />
      <stop offset="50%" stop-color="#fbbf24" />
      <stop offset="75%" stop-color="#d97706" />
      <stop offset="100%" stop-color="#fef08a" />
    </linearGradient>

    <!-- Royal Sherwani Gradient for Groom -->
    <linearGradient id="sherwaniGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fefce8" />
      <stop offset="40%" stop-color="#fef08a" />
      <stop offset="70%" stop-color="#fde047" />
      <stop offset="100%" stop-color="#ca8a04" />
    </linearGradient>

    <!-- Bridal Red Lehenga Gradient -->
    <linearGradient id="bridalRed" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#dc2626" />
      <stop offset="40%" stop-color="#b91c1c" />
      <stop offset="80%" stop-color="#7f1d1d" />
      <stop offset="100%" stop-color="#450a0a" />
    </linearGradient>

    <!-- LED Stage Screen Gradient -->
    <linearGradient id="screenLed" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#190724" />
      <stop offset="50%" stop-color="#38094a" />
      <stop offset="100%" stop-color="#190724" />
    </linearGradient>

    <!-- Spotlights -->
    <linearGradient id="spotL" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${lightBeamL}" stop-opacity="0.6" />
      <stop offset="80%" stop-color="${lightBeamL}" stop-opacity="0.05" />
      <stop offset="100%" stop-color="${lightBeamL}" stop-opacity="0" />
    </linearGradient>

    <linearGradient id="spotR" x1="100%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="${lightBeamR}" stop-opacity="0.6" />
      <stop offset="80%" stop-color="${lightBeamR}" stop-opacity="0.05" />
      <stop offset="100%" stop-color="${lightBeamR}" stop-opacity="0" />
    </linearGradient>

    <!-- Cloud Fog Radial Glow -->
    <radialGradient id="stageFogRadial" cx="50%" cy="85%" r="65%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.96" />
      <stop offset="30%" stop-color="#e0f2fe" stop-opacity="0.85" />
      <stop offset="70%" stop-color="#bae6fd" stop-opacity="0.3" />
      <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
    </radialGradient>

    <filter id="softGlowFilter" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="6" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>

    <filter id="heavyFogFilter" x="-30%" y="-30%" width="160%" height="160%">
      <feGaussianBlur stdDeviation="28" />
    </filter>
  </defs>

  <!-- Stage Background Layer (or user uploaded photo if present) -->
  ${userPhotoUrl ? `
    <image href="${userPhotoUrl}" width="${width}" height="${height}" preserveAspectRatio="xMidYMid slice" />
    <rect width="${width}" height="${height}" fill="#000000" opacity="0.3" />
  ` : `
    <rect width="${width}" height="${height}" fill="url(#weddingBg)" />
  `}

  <!-- Stage Sweeping Spotlight Beams -->
  <polygon points="100,0 260,0 ${cx - 50},${height - 180} 60,${height - 100}" fill="url(#spotL)" />
  <polygon points="${width - 100},0 ${width - 260},0 ${cx + 50},${height - 180} ${width - 60},${height - 100}" fill="url(#spotR)" />

  <!-- Top Fairy Light Festoons & Flower Garlands -->
  <g opacity="0.85">
    <path d="M 0,35 Q ${width * 0.25},70 ${width * 0.5},35 T ${width},35" stroke="url(#goldLuxury)" stroke-width="2.5" fill="none" />
    <path d="M 0,55 Q ${width * 0.25},90 ${width * 0.5},55 T ${width},55" stroke="#f472b6" stroke-width="1.5" fill="none" stroke-dasharray="6 6" />
    ${[80, 180, 280, 380, 480, 600, 700, 800, 900, 1000].filter(x => x < width).map(x => `
      <circle cx="${x}" cy="45" r="4.5" fill="#fef08a" filter="url(#softGlowFilter)" />
      <line x1="${x}" y1="45" x2="${x}" y2="70" stroke="#fef08a" stroke-width="1" />
      <circle cx="${x}" cy="72" r="3" fill="#f43f5e" />
    `).join('')}
  </g>

  <!-- CUSTOMER'S GRAND STAGE BACKDROP LED BOARD -->
  <g transform="translate(${cx}, ${backdropY})">
    <!-- Screen Outer Frame -->
    <rect x="-380" y="-120" width="760" height="225" rx="18" fill="url(#screenLed)" stroke="url(#goldLuxury)" stroke-width="4.5" filter="url(#softGlowFilter)" />
    <!-- Golden Border Detail -->
    <rect x="-370" y="-110" width="740" height="205" rx="12" fill="none" stroke="#fef08a" stroke-width="1.5" stroke-dasharray="8 6" opacity="0.7" />

    <!-- Backdrop Top Banner Text -->
    <text x="0" y="-65" font-family="'Segoe UI', Roboto, 'Nirmala UI', sans-serif" font-size="20" font-weight="900" fill="#fbcfe8" text-anchor="middle" letter-spacing="2">
      ${safeBackdrop}
    </text>

    <!-- Couple Name (BIG GLOWING LUXURY SCRIPT) -->
    <text x="0" y="2" font-family="'Playfair Display', Georgia, 'Nirmala UI', serif" font-size="${isWide ? 52 : 54}" font-weight="900" fill="#ffffff" text-anchor="middle" filter="url(#softGlowFilter)">
      ${safeNames}
    </text>
    <text x="0" y="2" font-family="'Playfair Display', Georgia, 'Nirmala UI', serif" font-size="${isWide ? 52 : 54}" font-weight="900" fill="url(#goldLuxury)" text-anchor="middle">
      ${safeNames}
    </text>

    <!-- Date & Venue Pill on the Backdrop Screen -->
    <g transform="translate(0, 52)">
      <rect x="-240" y="-18" width="480" height="36" rx="18" fill="#180728" stroke="#f59e0b" stroke-width="1.5" />
      <text x="0" y="6" font-family="'Segoe UI', Roboto, sans-serif" font-size="16" font-weight="bold" fill="#fef08a" text-anchor="middle">
        📅 ${safeDate} ${safeVenue ? `• 📍 ${safeVenue}` : ''}
      </text>
    </g>
  </g>

  <!-- CROWD / BARATIS / RELATIVES IN THE BACKGROUND (पीछे लोग & बाराती) -->
  <g transform="translate(${cx}, ${coupleStageY - 30})" opacity="0.65">
    <!-- Left Wing Guests/Relatives -->
    <g transform="translate(-260, 0)">
      <!-- Guest 1 (Woman in Saree clapping) -->
      <circle cx="-50" cy="-30" r="14" fill="#fbcfe8" />
      <path d="M -65,30 Q -60,-15 -50,-15 Q -40,-15 -35,30 Z" fill="#ec4899" />
      <line x1="-35" y1="5" x2="-25" y2="-10" stroke="#fbcfe8" stroke-width="3" />
      <!-- Guest 2 (Man in Kurta clapping) -->
      <circle cx="-15" cy="-35" r="15" fill="#fef08a" />
      <path d="M -30,30 Q -25,-20 -15,-20 Q -5,-20 0,30 Z" fill="#3b82f6" />
      <circle cx="-2" cy="-12" r="4" fill="#fef08a" />
      <!-- Guest 3 (Elder with Pagdi) -->
      <circle cx="20" cy="-38" r="15" fill="#fed7aa" />
      <ellipse cx="20" cy="-48" rx="14" ry="7" fill="#f97316" />
      <path d="M 5,30 Q 10,-22 20,-22 Q 30,-22 35,30 Z" fill="#d97706" />
    </g>

    <!-- Right Wing Guests/Relatives -->
    <g transform="translate(260, 0)">
      <!-- Guest 4 (Young relative taking phone photo) -->
      <circle cx="-25" cy="-36" r="14" fill="#fed7aa" />
      <path d="M -40,30 Q -35,-20 -25,-20 Q -15,-20 -10,30 Z" fill="#8b5cf6" />
      <rect x="-18" y="-22" width="12" height="7" rx="1.5" fill="#ffffff" />
      <!-- Guest 5 (Woman in Golden Lehenga) -->
      <circle cx="15" cy="-32" r="14" fill="#fbcfe8" />
      <path d="M 0,30 Q 5,-16 15,-16 Q 25,-16 30,30 Z" fill="#f59e0b" />
      <!-- Guest 6 (Cheering man) -->
      <circle cx="50" cy="-34" r="15" fill="#fed7aa" />
      <path d="M 35,30 Q 40,-18 50,-18 Q 60,-18 65,30 Z" fill="#10b981" />
      <line x1="60" y1="0" x2="72" y2="-20" stroke="#fed7aa" stroke-width="3" />
    </g>
  </g>

  <!-- SHOWER OF ROSE PETALS & FLOWER CONFETTI (पुष्प वर्षा) -->
  <g fill="#f43f5e" opacity="0.9">
    <ellipse cx="${cx - 160}" cy="${coupleStageY - 140}" rx="6" ry="3.5" transform="rotate(-25 ${cx - 160} ${coupleStageY - 140})" />
    <ellipse cx="${cx - 90}" cy="${coupleStageY - 180}" rx="5" ry="3" transform="rotate(35 ${cx - 90} ${coupleStageY - 180})" fill="#fbbf24" />
    <ellipse cx="${cx - 40}" cy="${coupleStageY - 130}" rx="6" ry="3.5" transform="rotate(15 ${cx - 40} ${coupleStageY - 130})" />
    <ellipse cx="${cx + 30}" cy="${coupleStageY - 160}" rx="5.5" ry="3" transform="rotate(-40 ${cx + 30} ${coupleStageY - 160})" fill="#fbbf24" />
    <ellipse cx="${cx + 110}" cy="${coupleStageY - 145}" rx="6" ry="3.5" transform="rotate(20 ${cx + 110} ${coupleStageY - 145})" />
    <ellipse cx="${cx + 170}" cy="${coupleStageY - 190}" rx="5" ry="3" transform="rotate(-15 ${cx + 170} ${coupleStageY - 190})" />
    <ellipse cx="${cx - 210}" cy="${coupleStageY - 90}" rx="5" ry="3" transform="rotate(45 ${cx - 210} ${coupleStageY - 90})" />
    <ellipse cx="${cx + 220}" cy="${coupleStageY - 80}" rx="5" ry="3" transform="rotate(-30 ${cx + 220} ${coupleStageY - 80})" />
  </g>

  <!-- GRAND WEDDING COUPLE ON STAGE (दूल्हा और दुल्हन विस्तृत दृश्य) -->
  <g transform="translate(${cx}, ${coupleStageY})">
    <!-- Mandap Stage Carpet Platform -->
    <polygon points="-280,120 280,120 250,150 -250,150" fill="#991b1b" stroke="url(#goldLuxury)" stroke-width="3" />

    <!-- ==================== GROOM (दूल्हा) ==================== -->
    <g transform="translate(-65, 0)">
      <!-- Royal Safa / Pagdi (साफ़ा व कलगी) -->
      <ellipse cx="0" cy="-78" rx="22" ry="12" fill="#b91c1c" />
      <path d="M -18,-86 Q 0,-98 18,-86 Q 22,-74 12,-68 Q -10,-68 -18,-86 Z" fill="#dc2626" />
      <!-- Golden Kalgi Feather & Brooch -->
      <line x1="0" y1="-86" x2="-2" y2="-106" stroke="#fbbf24" stroke-width="2.5" />
      <polygon points="-2,-106 -5,-116 0,-112 5,-116 2,-106" fill="#fef08a" />
      <circle cx="0" cy="-84" r="3.5" fill="#38bdf8" stroke="#fbbf24" stroke-width="1.5" />
      <!-- Groom Face & Royal Beard/Moustache -->
      <circle cx="0" cy="-58" r="18" fill="#fed7aa" />
      <path d="M -8,-52 Q 0,-47 8,-52" stroke="#451a03" stroke-width="2.5" fill="none" stroke-linecap="round" />
      
      <!-- Pearl Necklace (मोतियों की माला) -->
      <path d="M -10,-40 Q 0,-25 10,-40" stroke="#ffffff" stroke-width="2" fill="none" />
      <path d="M -12,-35 Q 0,-18 12,-35" stroke="#fbbf24" stroke-width="2" fill="none" />

      <!-- Royal Zari Embroidered Sherwani (शेरवानी) -->
      <path d="M -26,-40 L -30,65 L 18,65 L 14,-40 Z" fill="url(#sherwaniGrad)" stroke="#b45309" stroke-width="1.5" />
      <!-- Sherwani Buttons & Golden Border Placket -->
      <line x1="-6" y1="-40" x2="-6" y2="65" stroke="#b45309" stroke-width="2" />
      <circle cx="-6" cy="-30" r="2" fill="#78350f" />
      <circle cx="-6" cy="-18" r="2" fill="#78350f" />
      <circle cx="-6" cy="-6" r="2" fill="#78350f" />
      <circle cx="-6" cy="6" r="2" fill="#78350f" />
      <!-- Royal Stole / Dupatta across shoulder -->
      <path d="M -26,-36 Q -12,0 -20,65" stroke="#991b1b" stroke-width="6" fill="none" />

      <!-- Groom's Arm holding Varmala -->
      <path d="M 12,-30 Q 32,-10 40,-12" stroke="#fde047" stroke-width="7" fill="none" stroke-linecap="round" />
      <circle cx="40" cy="-12" r="5" fill="#fed7aa" />
    </g>

    <!-- ==================== BRIDE (दुल्हन) ==================== -->
    <g transform="translate(65, 0)">
      <!-- Bridal Hair Bun with Gajra (जूड़ा व गजरा) -->
      <circle cx="0" cy="-60" r="18" fill="#1c1917" />
      <circle cx="0" cy="-62" r="20" stroke="#fef08a" stroke-width="3" fill="none" stroke-dasharray="4 4" />

      <!-- Bride Face -->
      <circle cx="0" cy="-56" r="17" fill="#fed7aa" />
      <!-- Maang Tikka & Bindi on Forehead -->
      <circle cx="0" cy="-68" r="3" fill="#f59e0b" />
      <line x1="0" y1="-72" x2="0" y2="-68" stroke="#fbbf24" stroke-width="1.5" />
      <circle cx="0" cy="-60" r="1.5" fill="#dc2626" />
      <!-- Golden Jhumkas (झुमके) -->
      <polygon points="-16,-52 -13,-45 -19,-45" fill="#fbbf24" />
      <polygon points="16,-52 13,-45 19,-45" fill="#fbbf24" />

      <!-- Bridal Choli / Blouse -->
      <path d="M -16,-38 L -18,-15 L 18,-15 L 16,-38 Z" fill="#991b1b" stroke="#fbbf24" stroke-width="1.5" />
      <!-- Gold Necklace (रानी हार) -->
      <path d="M -10,-38 Q 0,-26 10,-38" stroke="#fbbf24" stroke-width="3.5" fill="none" />

      <!-- Heavy Bridal Lehenga (लहंगा) with Gold Zari Border -->
      <path d="M -18,-15 L -42,75 L 42,75 L 18,-15 Z" fill="url(#bridalRed)" stroke="#fbbf24" stroke-width="2" />
      <!-- Golden Zari Embroidery horizontal patterns on lehenga -->
      <path d="M -24,10 Q 0,16 24,10" stroke="#fef08a" stroke-width="2" fill="none" />
      <path d="M -32,38 Q 0,46 32,38" stroke="#fef08a" stroke-width="2.5" fill="none" />
      <path d="M -40,68 L 40,68" stroke="#f59e0b" stroke-width="5" />

      <!-- Red Sheer Bridal Dupatta draped over head -->
      <path d="M -16,-66 Q 0,-76 16,-66 Q 30,-30 38,40" stroke="#ef4444" stroke-width="4.5" fill="none" opacity="0.85" />
      
      <!-- Bride Arms with Red Choora & Gold Bangles -->
      <path d="M -16,-30 Q -32,-10 -38,-12" stroke="#b91c1c" stroke-width="6" fill="none" stroke-linecap="round" />
      <circle cx="-38" cy="-12" r="5" fill="#fed7aa" />
    </g>

    <!-- ==================== VARMALA GARLAND (जयमाला) ==================== -->
    <!-- Beautiful Rose & Jasmine garland connecting the couple -->
    <path d="M -24,-12 Q 0,22 26,-12" stroke="#f43f5e" stroke-width="7" fill="none" stroke-linecap="round" />
    <path d="M -24,-12 Q 0,22 26,-12" stroke="#fef08a" stroke-width="3" fill="none" stroke-dasharray="6 6" />
  </g>

  <!-- DENSE LOW-LYING WHITE STAGE CLOUD SMOKE (भारी घना सफेद फॉग) -->
  <g>
    <!-- Deep floor glow -->
    <rect x="0" y="${height - (isTall ? 580 : isWide ? 380 : 440)}" width="${width}" height="${isTall ? 580 : isWide ? 380 : 440}" fill="url(#stageFogRadial)" />

    <!-- Wave 1 (Soft dense ground clouds) -->
    <path d="M 0,${height - 300} Q ${width * 0.25},${height - 400} ${width * 0.5},${height - 310} T ${width},${height - 340} L ${width},${height} L 0,${height} Z" fill="#ffffff" fill-opacity="0.5" filter="url(#heavyFogFilter)" />

    <!-- Wave 2 (Rolling billowy cumulus smoke pillows) -->
    <path d="M 0,${height - 230} Q ${width * 0.18},${height - 170} ${width * 0.38},${height - 260} T ${width * 0.72},${height - 200} T ${width},${height - 270} L ${width},${height} L 0,${height} Z" fill="#f0f9ff" fill-opacity="0.8" filter="url(#heavyFogFilter)" />

    <!-- Wave 3 (Foreground pure white thick clouds hugging stage floor) -->
    <path d="M 0,${height - 150} C ${width * 0.14},${height - 210} ${width * 0.32},${height - 120} ${width * 0.5},${height - 180} C ${width * 0.68},${height - 230} ${width * 0.86},${height - 130} ${width},${height - 170} L ${width},${height} L 0,${height} Z" fill="#ffffff" fill-opacity="0.96" />
  </g>

  <!-- ACTIVE COLD PYRO SPARKLER FOUNTAINS (Left & Right Stage Wings) -->
  <g>
    <!-- Left Stage Cold Pyro Fountain -->
    <g transform="translate(${width * 0.14}, ${height - 140})">
      <polygon points="-14,0 14,0 26,-360 -26,-360" fill="#fbbf24" opacity="0.75" filter="url(#softGlowFilter)" />
      <polygon points="-7,0 7,0 14,-410 -14,-410" fill="#ffffff" opacity="0.95" />
      <polygon points="-3,0 3,0 6,-450 -6,-450" fill="#fef08a" opacity="0.98" />
    </g>

    <!-- Right Stage Cold Pyro Fountain -->
    <g transform="translate(${width * 0.86}, ${height - 140})">
      <polygon points="-14,0 14,0 26,-360 -26,-360" fill="#fbbf24" opacity="0.75" filter="url(#softGlowFilter)" />
      <polygon points="-7,0 7,0 14,-410 -14,-410" fill="#ffffff" opacity="0.95" />
      <polygon points="-3,0 3,0 6,-450 -6,-450" fill="#fef08a" opacity="0.98" />
    </g>
  </g>

  <!-- CUSTOMER'S BRANDING & ORGANIZER CREDIT BAR AT BOTTOM -->
  <g transform="translate(${cx}, ${height - (isTall ? 110 : isWide ? 60 : 70)})">
    <rect x="-360" y="-32" width="720" height="64" rx="32" fill="#090d16" stroke="url(#goldLuxury)" stroke-width="2.5" />
    <text x="0" y="8" font-family="'Segoe UI', Roboto, 'Nirmala UI', sans-serif" font-size="20" font-weight="900" fill="#fbbf24" text-anchor="middle" letter-spacing="1">
      👑 ${safeFirm} 👑
    </text>
  </g>

  <!-- Golden Luxury Corner Ornaments -->
  <g stroke="url(#goldLuxury)" stroke-width="3" fill="none" opacity="0.85">
    <path d="M 25,75 L 25,25 L 75,25" />
    <circle cx="25" cy="25" r="4.5" fill="#fbbf24" />
    <path d="M ${width - 25},75 L ${width - 25},25 L ${width - 75},25" />
    <circle cx="${width - 25}" cy="25" r="4.5" fill="#fbbf24" />
  </g>
</svg>`;
}

export function generateWeddingStageDataUrl(options: WeddingGraphicOptions = {}): string {
  const svg = generateWeddingStageSvg(options);
  try {
    if (typeof window !== 'undefined' && typeof window.btoa === 'function') {
      const base64 = window.btoa(unescape(encodeURIComponent(svg)));
      return `data:image/svg+xml;base64,${base64}`;
    }
  } catch {
    // fallback
  }

  if (typeof Buffer !== 'undefined') {
    const base64 = Buffer.from(svg, 'utf-8').toString('base64');
    return `data:image/svg+xml;base64,${base64}`;
  }

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
