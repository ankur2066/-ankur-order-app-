import { Capacitor } from '@capacitor/core';
import { auth } from '../firebase';

/**
 * Base URL of the OPTIONAL hosted backend (server.ts). It is needed only for
 * AI video generation and the owner AI chat, because API keys must never be
 * inside the APK.
 *
 * Set VITE_API_BASE_URL at build time, e.g. https://api.example.com
 * - Browser dev (npm run dev): same origin is used when unset.
 * - Installed APK: when unset, server features report "not configured".
 */
export function getApiBase(): string | null {
  const configured = (import.meta.env?.VITE_API_BASE_URL as string | undefined)?.trim();
  if (configured) return configured.replace(/\/+$/, '');
  if (Capacitor.isNativePlatform()) return null;
  return '';
}

export async function authHeaders(): Promise<Record<string, string>> {
  const token = await auth.currentUser?.getIdToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}
