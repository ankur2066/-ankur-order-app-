import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Order } from '../types';
import { Expense } from '../components/ExpensesView';

export const generateMonthlyPDF = (orders: Order[], expenses: Expense[]) => {
  const doc = new jsPDF();
  doc.text('Monthly Report', 10, 10);
  
  const orderTableData = orders.map(o => [o.orderId, o.customerName, o.quantityKg, o.totalAmount]);
  (doc as any).autoTable({
    head: [['ID', 'Customer', 'KG', 'Amount']],
    body: orderTableData,
  });

  doc.text('Expenses', 10, (doc as any).lastAutoTable.finalY + 10);
  const expenseTableData = expenses.map(e => [e.category, e.amount, e.description]);
  (doc as any).autoTable({
    head: [['Category', 'Amount', 'Description']],
    body: expenseTableData,
    startY: (doc as any).lastAutoTable.finalY + 15
  });

  doc.save('monthly_report.pdf');
};
