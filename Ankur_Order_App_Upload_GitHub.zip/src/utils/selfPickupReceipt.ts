/** Downloadable handover receipt, distinct from a verified payment receipt. */
import jsPDF from 'jspdf';
import type { Order } from '../types';
import type { PickupState } from './selfPickup';

export interface SelfPickupReceiptDetails {
  order: Order;
  pickup: PickupState;
  staffDisplayName?: string;
  boxes?: number;
  receivedAmount?: number;
}

export function getSelfPickupReceiptData(details: SelfPickupReceiptDetails) {
  const { order, pickup } = details;
  if (pickup.status !== 'pickup_completed' || pickup.receiptStatus !== 'valid' || !pickup.completedAt || !pickup.completedBy) {
    throw new Error('A valid confirmed pickup is required to issue a receipt');
  }
  const total = Number(order.totalAmount);
  if (details.receivedAmount === undefined || details.receivedAmount === null) throw new Error('Verified received amount is required');
  const received = Number(details.receivedAmount);
  if (!Number.isFinite(total) || !Number.isFinite(received) || total < 0 || received < 0 || received > total) {
    throw new Error('Verified payment amounts are required; do not assume an order is paid');
  }
  const boxes = details.boxes;
  if (boxes === undefined || !Number.isInteger(boxes) || boxes < 1) throw new Error('Verified box count is required');
  return {
    orderId: order.orderId,
    customer: order.customerName,
    district: order.district,
    quantityKg: order.quantityKg,
    boxes,
    completedAt: pickup.completedAt,
    staff: details.staffDisplayName || pickup.completedBy,
    total,
    received,
    due: total - received,
    paymentLabel: total - received === 0 ? 'No outstanding balance' : 'Outstanding balance',
  };
}

/** Call only after authenticated customer access is verified by the caller. */
export function downloadSelfPickupReceipt(details: SelfPickupReceiptDetails) {
  const data = getSelfPickupReceiptData(details);
  const pdf = new jsPDF();
  let y = 22;
  const line = (label: string, value: string | number) => {
    pdf.text(`${label}: ${String(value)}`, 15, y);
    y += 10;
  };
  pdf.setFontSize(17);
  pdf.text('ANKUR DRYICE AND EVENTS', 15, y);
  y += 13;
  pdf.setFontSize(12);
  pdf.text('SELF PICKUP HANDOVER RECEIPT', 15, y);
  y += 15;
  line('Order ID', data.orderId);
  line('Customer', data.customer);
  line('District', data.district);
  line('Quantity (KG)', data.quantityKg);
  line('Boxes', data.boxes ?? 'Not recorded');
  line('Pickup confirmed at', data.completedAt);
  line('Confirmed by staff', data.staff);
  line('Total (INR)', data.total.toFixed(2));
  line('Verified received (INR)', data.received.toFixed(2));
  line('Outstanding (INR)', data.due.toFixed(2));
  line('Payment status', data.paymentLabel);
  y += 6;
  pdf.setFontSize(10);
  pdf.text('Proof of handover only. This is NOT a verified payment receipt.', 15, y);
  pdf.save(`self-pickup-${data.orderId.replace(/[^a-zA-Z0-9_-]/g, '_')}.pdf`);
}
