import type { ProductItem, RateSettings } from '../types';

/** Product ids that existed before the storefront redesign. They keep following the global rates in settings/rates. */
export const LEGACY_PRODUCT_IDS = ['dry_ice_standard', 'dry_ice_pellets', 'dry_ice_blocks'];

export const CATEGORY_META: Record<string, { label: string }> = {
  dry_ice: { label: 'ड्राई आइस' },
  pellets: { label: 'पेलेट्स' },
  blocks: { label: 'ब्लॉक' },
  event_packs: { label: 'इवेंट पैक' },
  accessories: { label: 'एक्सेसरीज़' },
};

export const CATEGORY_OPTIONS = Object.keys(CATEGORY_META);

export function categoryLabel(id: string): string {
  return CATEGORY_META[id]?.label || id;
}

export function followsGlobalRates(p: ProductItem): boolean {
  if (typeof p.useGlobalRates === 'boolean') return p.useGlobalRates;
  return LEGACY_PRODUCT_IDS.includes(p.id);
}

/** Rates used when a customer books this product (transport always comes from global settings). */
export function applyProductRates(base: RateSettings, p: ProductItem): RateSettings {
  if (followsGlobalRates(p)) return base;
  return { ...base, dryIceRate: p.ratePerKg, thermocolRate: p.thermocolPerKg };
}

/** All-in price per kg shown on product cards. */
export function displayPricePerKg(p: ProductItem, base: RateSettings): number {
  const r = applyProductRates(base, p);
  return r.dryIceRate + r.thermocolRate;
}

export function orderProductName(p: ProductItem | null | undefined): string {
  if (!p) return 'ड्राई आइस (Dry Ice)';
  return `${p.hindiName} (${p.name})`.slice(0, 100);
}
