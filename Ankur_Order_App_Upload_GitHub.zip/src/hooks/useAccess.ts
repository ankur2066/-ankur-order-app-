import { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { auth, db, accessFromUserDoc, type AccessInfo } from '../firebase';
import type { UserProfile } from '../types';

const NO_ACCESS: AccessInfo = {
  role: null,
  permissions: { viewOrders: false, updateStatus: false, toggleProducts: false },
};

/**
 * Tracks the signed-in user AND their role live.
 * The role document is watched, so when the owner approves a staff request the
 * app switches to the Staff Dashboard without a restart (and revoking access
 * switches it back).
 */
export function useAccess() {
  const [user, setUser] = useState<User | null>(auth.currentUser);
  const [access, setAccess] = useState<AccessInfo>(NO_ACCESS);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let unsubDoc: (() => void) | null = null;
    const unsubAuth = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (unsubDoc) {
        unsubDoc();
        unsubDoc = null;
      }
      if (!u) {
        setAccess(NO_ACCESS);
        setReady(true);
        return;
      }
      unsubDoc = onSnapshot(
        doc(db, 'users', u.uid),
        (snap) => {
          setAccess(accessFromUserDoc(u, snap.exists() ? (snap.data() as Partial<UserProfile>) : undefined));
          setReady(true);
        },
        (err) => {
          console.warn('Role listener error:', err?.message || err);
          setAccess(accessFromUserDoc(u, undefined));
          setReady(true);
        }
      );
    });
    return () => {
      unsubAuth();
      if (unsubDoc) unsubDoc();
    };
  }, []);

  return { user, access, ready };
}
