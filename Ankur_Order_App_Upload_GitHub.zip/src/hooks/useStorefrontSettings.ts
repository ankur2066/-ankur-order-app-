import { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import type { HomeSettings, LuckyWinner, PromoBanner } from '../types';

export const DEFAULT_BANNERS: PromoBanner[] = [
  { id: 'b1', title: 'शादी और इवेंट के लिए ड्राई आइस', subtitle: 'स्मोक व फॉग एंट्री के लिए बुक करें', action: 'order' },
  { id: 'b2', title: 'आज सुबह 12 PM तक बुकिंग', subtitle: 'शाम व कल के स्लॉट भी उपलब्ध', action: 'order' },
  { id: 'b3', title: 'थोक ऑर्डर? सीधे बात करें', subtitle: 'कॉल या WhatsApp पर रेट पूछें', action: 'whatsapp' },
];

/** Public storefront settings: promo banners + lucky winner. Both live in the publicly readable `settings` collection. */
export function useStorefrontSettings() {
  const [banners, setBanners] = useState<PromoBanner[]>(DEFAULT_BANNERS);
  const [winner, setWinner] = useState<LuckyWinner | null>(null);

  useEffect(() => {
    const unsubHome = onSnapshot(
      doc(db, 'settings', 'home'),
      (snap) => {
        const data = snap.exists() ? (snap.data() as HomeSettings) : null;
        if (data && Array.isArray(data.banners) && data.banners.length > 0) {
          setBanners(data.banners.slice(0, 6));
        } else {
          setBanners(DEFAULT_BANNERS);
        }
      },
      () => setBanners(DEFAULT_BANNERS)
    );
    const unsubWinner = onSnapshot(
      doc(db, 'settings', 'luckyWinner'),
      (snap) => {
        const data = snap.exists() ? (snap.data() as LuckyWinner) : null;
        setWinner(data && data.active && data.name ? data : null);
      },
      () => setWinner(null)
    );
    return () => {
      unsubHome();
      unsubWinner();
    };
  }, []);

  return { banners, winner };
}
