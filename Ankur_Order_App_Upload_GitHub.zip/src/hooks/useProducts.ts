import { useEffect, useState } from 'react';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import { db } from '../firebase';
import { INITIAL_PRODUCTS } from '../data/products';
import type { ProductItem } from '../types';

function sortProducts(list: ProductItem[]): ProductItem[] {
  return [...list].sort((a, b) => {
    const sa = a.sortOrder ?? 1000;
    const sb = b.sortOrder ?? 1000;
    if (sa !== sb) return sa - sb;
    return (a.hindiName || a.name).localeCompare(b.hindiName || b.name);
  });
}

/**
 * Products shown to customers: ACTIVE ONLY.
 * The query includes where('active','==',true) because firestore.rules only
 * lets the public read active products.
 *
 * Until the owner saves the catalog once (settings/catalog.seeded), the 3
 * built-in products are shown so the app keeps working exactly as before.
 */
export function useStorefrontProducts() {
  const [seeded, setSeeded] = useState<boolean | null>(null);
  const [remote, setRemote] = useState<ProductItem[]>([]);
  const [remoteLoaded, setRemoteLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(
      doc(db, 'settings', 'catalog'),
      (snap) => setSeeded(snap.exists() && snap.data().seeded === true),
      () => setSeeded(false)
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'products'), where('active', '==', true));
    const unsub = onSnapshot(
      q,
      (snap) => {
        setRemote(snap.docs.map((d) => ({ ...(d.data() as ProductItem), id: d.id })));
        setRemoteLoaded(true);
        setError(null);
      },
      (err) => {
        console.warn('Products listener error:', err?.message || err);
        setError('प्रोडक्ट लिस्ट लोड नहीं हो सकी।');
        setRemoteLoaded(true);
      }
    );
    return () => unsub();
  }, []);

  let products = remote;
  if (seeded === false) {
    const ids = new Set(remote.map((p) => p.id));
    products = [...remote, ...INITIAL_PRODUCTS.filter((p) => p.active && !ids.has(p.id))];
  }

  return {
    products: sortProducts(products.filter((p) => p.active)),
    loading: seeded === null || !remoteLoaded,
    error,
  };
}

/** Owner/staff view: every product, including inactive ones. */
export function useAllProducts(enabled: boolean) {
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [seeded, setSeeded] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!enabled) return;
    const unsubProducts = onSnapshot(
      collection(db, 'products'),
      (snap) => {
        setProducts(sortProducts(snap.docs.map((d) => ({ ...(d.data() as ProductItem), id: d.id }))));
        setLoading(false);
        setError(null);
      },
      (err) => {
        setError(err?.message || 'प्रोडक्ट लोड नहीं हुए');
        setLoading(false);
      }
    );
    const unsubSeed = onSnapshot(doc(db, 'settings', 'catalog'), (snap) => {
      setSeeded(snap.exists() && snap.data().seeded === true);
    });
    return () => {
      unsubProducts();
      unsubSeed();
    };
  }, [enabled]);

  return { products, loading, seeded, error };
}

/**
 * Owner action: copies the 3 built-in products into Firestore (never overwrites an
 * existing document) and marks the catalog as saved.
 */
export async function seedCatalog(): Promise<number> {
  let created = 0;
  let order = 1;
  for (const p of INITIAL_PRODUCTS) {
    const ref = doc(db, 'products', p.id);
    const existing = await getDoc(ref);
    if (!existing.exists()) {
      await setDoc(ref, {
        ...p,
        useGlobalRates: true,
        sortOrder: order,
        updatedAt: serverTimestamp(),
      });
      created += 1;
    }
    order += 1;
  }
  await setDoc(doc(db, 'settings', 'catalog'), { seeded: true, updatedAt: serverTimestamp() }, { merge: true });
  return created;
}
