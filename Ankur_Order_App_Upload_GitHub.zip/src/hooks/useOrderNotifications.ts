import { useCallback, useEffect, useRef, useState } from 'react';
import { collection, doc, getDocs, onSnapshot, query, where } from 'firebase/firestore';
import type { User } from 'firebase/auth';
import { db } from '../firebase';
import type { OrderStatus, OrderTracking } from '../types';

/**
 * In-app order notifications.
 *
 * HONEST LIMITS: this watches order_tracking documents while the app is open
 * (or when it is opened again) and raises an in-app alert when a status
 * changes. It is NOT background push: nothing is delivered when the app is
 * closed. Real push needs Firebase Cloud Messaging + a server/Cloud Function.
 */

export interface AppNotice {
  id: string;
  orderId: string;
  title: string;
  body: string;
  at: number;
  read: boolean;
}

const NOTICES_KEY = 'ankur_notices_v1';
const STATUS_KEY = 'ankur_order_status_v1';
const PLACED_KEY = 'ankur_dryice_placed_orders_v1';
const MAX_NOTICES = 30;
const MAX_WATCHED = 8;

const STATUS_TEXT: Record<OrderStatus, string> = {
  pending: 'ऑर्डर प्राप्त हुआ',
  confirmed: 'ऑर्डर कन्फर्म हो गया',
  in_packing: 'आपका ऑर्डर पैक हो रहा है',
  dispatched: 'आपका ऑर्डर डिस्पैच हो गया',
  delivered: 'ऑर्डर डिलीवर हो गया',
  cancelled: 'ऑर्डर रद्द किया गया',
};

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable: notifications just won't persist */
  }
}

/** Orders this device placed (works for guests too). */
export function readPlacedOrders(): any[] {
  const list = readJson<any[]>(PLACED_KEY, []);
  return Array.isArray(list) ? list : [];
}

export function useOrderNotifications(currentUser: User | null) {
  const [notices, setNotices] = useState<AppNotice[]>(() => readJson<AppNotice[]>(NOTICES_KEY, []));
  const [toast, setToast] = useState<AppNotice | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  const pushNotice = useCallback((n: Omit<AppNotice, 'id' | 'at' | 'read'>) => {
    const notice: AppNotice = { ...n, id: `${n.orderId}_${Date.now()}`, at: Date.now(), read: false };
    setNotices((prev) => {
      const next = [notice, ...prev].slice(0, MAX_NOTICES);
      writeJson(NOTICES_KEY, next);
      return next;
    });
    setToast(notice);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 6000);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const unsubs: Array<() => void> = [];

    async function start() {
      const tokens = new Map<string, string>(); // trackingToken -> orderId

      readPlacedOrders()
        .slice(-MAX_WATCHED)
        .forEach((o) => {
          if (o?.trackingToken && o?.orderId) tokens.set(o.trackingToken, o.orderId);
        });

      if (currentUser) {
        try {
          const snap = await getDocs(query(collection(db, 'orders'), where('userId', '==', currentUser.uid)));
          snap.docs
            .map((d) => d.data() as any)
            .filter((o) => !o.isTrash && o.trackingToken)
            .sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))
            .slice(0, MAX_WATCHED)
            .forEach((o) => tokens.set(o.trackingToken, o.orderId));
        } catch (err) {
          console.warn('Could not load own orders for notifications:', err);
        }
      }
      if (cancelled) return;

      const lastStatus = readJson<Record<string, string>>(STATUS_KEY, {});

      tokens.forEach((orderId, token) => {
        const unsub = onSnapshot(
          doc(db, 'order_tracking', token),
          (snap) => {
            if (!snap.exists()) return;
            const t = snap.data() as OrderTracking;
            const previous = lastStatus[orderId];
            if (previous && previous !== t.status) {
              pushNotice({
                orderId,
                title: STATUS_TEXT[t.status] || 'ऑर्डर अपडेट',
                body: t.lastStatusUpdate || `ऑर्डर ${orderId} की स्थिति बदली है।`,
              });
            }
            lastStatus[orderId] = t.status;
            writeJson(STATUS_KEY, lastStatus);
          },
          (err) => console.warn('Tracking listener error:', err?.message || err)
        );
        unsubs.push(unsub);
      });
    }

    start();
    return () => {
      cancelled = true;
      unsubs.forEach((u) => u());
      window.clearTimeout(toastTimer.current);
    };
  }, [currentUser?.uid, pushNotice]);

  const markAllRead = useCallback(() => {
    setNotices((prev) => {
      const next = prev.map((n) => ({ ...n, read: true }));
      writeJson(NOTICES_KEY, next);
      return next;
    });
  }, []);

  const clearToast = useCallback(() => setToast(null), []);

  return {
    notices,
    unreadCount: notices.filter((n) => !n.read).length,
    toast,
    clearToast,
    markAllRead,
  };
}
