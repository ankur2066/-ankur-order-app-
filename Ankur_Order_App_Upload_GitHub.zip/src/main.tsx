import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { applyCachedTheme } from './theme/themes';

// Apply the last-used theme immediately so there is no colour flash on startup.
applyCachedTheme();

createRoot(document.getElementById('root')!).render(<App />);
