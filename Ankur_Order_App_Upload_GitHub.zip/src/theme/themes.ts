import type { ThemeId } from '../types';

/**
 * Owner-selectable themes.
 *
 * How it works: the app's existing screens use Tailwind's `sky-*` colours as
 * their accent. Tailwind v4 compiles those utilities to CSS variables
 * (`--color-sky-500` ...), so re-pointing that scale re-colours existing owner,
 * staff and customer screens without touching each component. New storefront
 * screens use the semantic `--brand*` variables directly.
 */

export interface ThemeDef {
  id: ThemeId;
  label: string;      // English
  hindi: string;      // Hindi label shown to owner
  swatch: string;     // preview colour
  isDark: boolean;
  themeColor: string; // browser/status bar colour
  vars: Record<string, string>;
}

const STEPS = ['50', '100', '200', '300', '400', '500', '600', '700', '800', '900', '950'];

function accentScale(values: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  STEPS.forEach((step, i) => {
    out[`--color-sky-${step}`] = values[i];
  });
  return out;
}

const ORANGE = ['#fff7ed', '#ffedd5', '#fed7aa', '#fdba74', '#fb923c', '#FF7A00', '#ea580c', '#c2410c', '#9a3412', '#7c2d12', '#431407'];
const EMERALD = ['#ecfdf5', '#d1fae5', '#a7f3d0', '#6ee7b7', '#34d399', '#10b981', '#059669', '#047857', '#065f46', '#064e3b', '#022c22'];
const BLUE = ['#eff6ff', '#dbeafe', '#bfdbfe', '#93c5fd', '#60a5fa', '#3b82f6', '#2563eb', '#1d4ed8', '#1e40af', '#1e3a8a', '#172554'];
const VIOLET = ['#f5f3ff', '#ede9fe', '#ddd6fe', '#c4b5fd', '#a78bfa', '#8b5cf6', '#7c3aed', '#6d28d9', '#5b21b6', '#4c1d95', '#2e1065'];

const LIGHT_SURFACES = {
  '--app-bg': '#F6F3EE',
  '--card-bg': '#FFFFFF',
  '--text-main': '#0F172A',
  '--text-sub': '#5B6577',
  '--line': '#E7E2DA',
};

export const THEMES: ThemeDef[] = [
  {
    id: 'saffron',
    label: 'Bhagwa Saffron',
    hindi: 'भगवा केसरी',
    swatch: '#FF7A00',
    isDark: false,
    themeColor: '#FF7A00',
    vars: {
      ...accentScale(ORANGE),
      ...LIGHT_SURFACES,
      '--brand': '#FF7A00',
      '--brand-deep': '#C2410C',
      '--brand-soft': '#FFF1E0',
      '--brand-ink': '#7C2D12',
      '--on-brand': '#FFFFFF',
      '--hero-1': '#5C2600',
      '--hero-2': '#241006',
    },
  },
  {
    id: 'emerald',
    label: 'Emerald Green',
    hindi: 'एमरल्ड हरा',
    swatch: '#059669',
    isDark: false,
    themeColor: '#059669',
    vars: {
      ...accentScale(EMERALD),
      ...LIGHT_SURFACES,
      '--brand': '#059669',
      '--brand-deep': '#047857',
      '--brand-soft': '#E3F6EE',
      '--brand-ink': '#064E3B',
      '--on-brand': '#FFFFFF',
      '--hero-1': '#065F46',
      '--hero-2': '#022C22',
    },
  },
  {
    id: 'royal-blue',
    label: 'Royal Blue',
    hindi: 'रॉयल नीला',
    swatch: '#1D4ED8',
    isDark: false,
    themeColor: '#1D4ED8',
    vars: {
      ...accentScale(BLUE),
      ...LIGHT_SURFACES,
      '--brand': '#1D4ED8',
      '--brand-deep': '#1E40AF',
      '--brand-soft': '#E6EDFF',
      '--brand-ink': '#172554',
      '--on-brand': '#FFFFFF',
      '--hero-1': '#1E3A8A',
      '--hero-2': '#0B1B4D',
    },
  },
  {
    id: 'purple',
    label: 'Purple',
    hindi: 'बैंगनी',
    swatch: '#7C3AED',
    isDark: false,
    themeColor: '#7C3AED',
    vars: {
      ...accentScale(VIOLET),
      ...LIGHT_SURFACES,
      '--brand': '#7C3AED',
      '--brand-deep': '#6D28D9',
      '--brand-soft': '#F0E9FF',
      '--brand-ink': '#3B0764',
      '--on-brand': '#FFFFFF',
      '--hero-1': '#4C1D95',
      '--hero-2': '#1E0A3C',
    },
  },
  {
    id: 'dark',
    label: 'Dark',
    hindi: 'डार्क',
    swatch: '#111827',
    isDark: true,
    themeColor: '#0B1020',
    vars: {
      ...accentScale(ORANGE),
      '--app-bg': '#0B1020',
      '--card-bg': '#141B2D',
      '--text-main': '#E5E7EB',
      '--text-sub': '#9AA6BD',
      '--line': '#26304A',
      '--brand': '#FF7A00',
      '--brand-deep': '#FB923C',
      '--brand-soft': '#2B1B0C',
      '--brand-ink': '#FFD7B0',
      '--on-brand': '#FFFFFF',
      '--hero-1': '#111A33',
      '--hero-2': '#050816',
    },
  },
];

export const DEFAULT_THEME_ID: ThemeId = 'saffron';
const CACHE_KEY = 'ankur_theme_v1';

export function getTheme(id: string | undefined | null): ThemeDef {
  return THEMES.find((t) => t.id === id) || THEMES[0];
}

export function applyTheme(id: string | undefined | null): ThemeDef {
  const theme = getTheme(id);
  if (typeof document === 'undefined') return theme;
  const root = document.documentElement;
  Object.entries(theme.vars).forEach(([key, value]) => root.style.setProperty(key, value));
  root.setAttribute('data-theme', theme.id);
  root.style.colorScheme = theme.isDark ? 'dark' : 'light';
  try {
    let meta = document.querySelector('meta[name="theme-color"]') as HTMLMetaElement | null;
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'theme-color';
      document.head.appendChild(meta);
    }
    meta.content = theme.themeColor;
    localStorage.setItem(CACHE_KEY, theme.id);
  } catch {
    /* storage can be unavailable; theme still applied for this session */
  }
  return theme;
}

/** Applies the last theme seen on this device (before Firestore answers) to avoid a colour flash. */
export function applyCachedTheme(): void {
  let cached: string | null = null;
  try {
    cached = localStorage.getItem(CACHE_KEY);
  } catch {
    cached = null;
  }
  applyTheme(cached || DEFAULT_THEME_ID);
}
