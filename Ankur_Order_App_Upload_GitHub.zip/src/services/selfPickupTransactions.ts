import { doc, runTransaction, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { confirmPickup, undoPickup, type PickupState } from '../utils/selfPickup';
import type { Order } from '../types';

/**
 * Draft transactional workflow. DO NOT expose in production UI until
 * Firestore rules enforce actor permissions and validate these transitions.
 * The order must already be explicitly classified as a Self Pickup order.
 */
export async function changeSelfPickupState(input: {
  orderId: string;
  actorUid: string;
  isOwner: boolean;
  action: 'confirm' | 'undo';
  reason?: string;
}) {
  if (!input.orderId || !input.actorUid) throw new Error('Authenticated actor and order are required');
  const orderRef = doc(db, 'orders', input.orderId);
  return runTransaction(db, async tx => {
    const snap = await tx.get(orderRef);
    if (!snap.exists()) throw new Error('Order not found');
    const order = snap.data() as Order;
    if (order.orderId !== input.orderId || order.isTrash) throw new Error('Invalid order');
    if (!order.selfPickup) throw new Error('Order is not explicitly enabled for Self Pickup');
    const current = order.selfPickup as PickupState;
    const at = new Date().toISOString();
    const result = input.action === 'confirm'
      ? confirmPickup(current, input.orderId, input.actorUid, at)
      : undoPickup(current, input.orderId, input.actorUid, input.isOwner, at, input.reason ?? '');
    // NOTE: client timestamps cannot be trusted for permission checks;
    // Firestore security rules must enforce the 5-minute window with request.time.
    tx.update(orderRef, { selfPickup: result.state, updatedAt: serverTimestamp() });
    const auditRef = doc(db, 'pickup_audit', `${input.orderId}_${crypto.randomUUID()}`);
    tx.set(auditRef, { ...result.audit, createdAt: serverTimestamp() });
    return result;
  });
}
