import { authHeaders, getApiBase } from '../utils/apiBase';

/**
 * Client for the OPTIONAL AI-video backend (server.ts).
 *
 * Nothing here fakes a result. If the backend URL is missing, the backend has
 * no Gemini key / Veo model configured, the user is not signed in, or the
 * request fails, the UI gets a clear error code and shows an honest message.
 * API keys live ONLY on the server.
 */

export type VideoAspect = '16:9' | '9:16';

export interface VideoRequest {
  prompt: string;
  aspectRatio: VideoAspect;
  referenceImage?: { mimeType: string; dataBase64: string };
}

export type VideoJobStatus = 'queued' | 'processing' | 'done' | 'failed';

export interface VideoJob {
  id: string;
  status: VideoJobStatus;
  error?: string;
}

export type VideoApiErrorCode =
  | 'not_configured'
  | 'not_signed_in'
  | 'quota'
  | 'network'
  | 'server'
  | 'failed';

export class VideoApiError extends Error {
  code: VideoApiErrorCode;
  constructor(code: VideoApiErrorCode, message: string) {
    super(message);
    this.code = code;
    this.name = 'VideoApiError';
  }
}

export interface ServiceStatus {
  available: boolean;
  reason?: string;
}

async function call(path: string, init: RequestInit = {}): Promise<Response> {
  const base = getApiBase();
  if (base === null) {
    throw new VideoApiError('not_configured', 'ऐप में वीडियो सर्वर का पता (VITE_API_BASE_URL) सेट नहीं है।');
  }
  const headers = { ...(init.headers as Record<string, string> | undefined), ...(await authHeaders()) };
  try {
    return await fetch(`${base}${path}`, { ...init, headers });
  } catch {
    throw new VideoApiError('network', 'वीडियो सर्वर से कनेक्ट नहीं हो सका। इंटरनेट या सर्वर चालू है या नहीं जाँचें।');
  }
}

async function readError(res: Response): Promise<VideoApiError> {
  let detail = '';
  try {
    const data = await res.json();
    detail = data?.error || '';
  } catch {
    /* non-JSON error body */
  }
  if (res.status === 401) return new VideoApiError('not_signed_in', 'वीडियो बनाने के लिए Google से लॉगिन करें।');
  if (res.status === 429) return new VideoApiError('quota', detail || 'आज की वीडियो सीमा पूरी हो चुकी है। कल फिर कोशिश करें।');
  if (res.status === 503) return new VideoApiError('not_configured', detail || 'वीडियो जनरेशन सर्वर पर अभी चालू नहीं है।');
  return new VideoApiError('server', detail || `सर्वर त्रुटि (${res.status})`);
}

export async function checkVideoService(): Promise<ServiceStatus> {
  const base = getApiBase();
  if (base === null) {
    return { available: false, reason: 'यह ऐप किसी वीडियो सर्वर से जुड़ा नहीं है (मालिक को सर्वर का पता सेट करना होगा)।' };
  }
  try {
    const res = await fetch(`${base}/api/video/health`);
    if (!res.ok) return { available: false, reason: `वीडियो सर्वर ने जवाब नहीं दिया (${res.status}).` };
    const data = await res.json();
    return data?.configured
      ? { available: true }
      : { available: false, reason: data?.reason || 'सर्वर पर Gemini/Veo की सेटिंग पूरी नहीं है।' };
  } catch {
    return { available: false, reason: 'वीडियो सर्वर तक पहुँच नहीं हो पाई।' };
  }
}

export async function startVideoJob(req: VideoRequest): Promise<string> {
  const res = await call('/api/video/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req),
  });
  if (!res.ok) throw await readError(res);
  const data = await res.json();
  if (!data?.jobId) throw new VideoApiError('server', 'सर्वर ने जॉब आईडी नहीं दी।');
  return data.jobId as string;
}

export async function getVideoJob(jobId: string): Promise<VideoJob> {
  const res = await call(`/api/video/jobs/${encodeURIComponent(jobId)}`);
  if (!res.ok) throw await readError(res);
  return (await res.json()) as VideoJob;
}

export async function fetchVideoBlob(jobId: string): Promise<Blob> {
  const res = await call(`/api/video/jobs/${encodeURIComponent(jobId)}/file`);
  if (!res.ok) throw await readError(res);
  return await res.blob();
}
