import { initializeApp } from 'firebase/app';
import { Capacitor } from '@capacitor/core';
import { FirebaseAuthentication } from '@capacitor-firebase/authentication';
import { 
  getAuth, 
  signInWithPopup, 
  signInWithCredential,
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged,
  type User 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc,
  getDocFromServer 
} from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { UserRole, UserProfile, StaffPermissions, DEFAULT_STAFF_PERMISSIONS } from './types';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

// Connect to configured database (supports named databases)
export const db = firebaseConfig.firestoreDatabaseId 
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
const googleProvider = new GoogleAuthProvider();

export const ADMIN_EMAIL = 'ankurdryicewholesalers@gmail.com';

export function isUserAdmin(user: User | null): boolean {
  if (!user) return false;
  return user.email === ADMIN_EMAIL && user.emailVerified === true;
}

export async function signInWithGoogle() {
  try {
    if (Capacitor.isNativePlatform()) {
      // Native Google account picker avoids Firebase popup/redirect sessionStorage errors.
      // Keep Firebase JS Auth signed in as Firestore and the app use the JS SDK.
      const result = await FirebaseAuthentication.signInWithGoogle({ skipNativeAuth: true });
      const idToken = result.credential?.idToken;
      if (!idToken) {
        throw new Error('Native Google Sign-In returned no ID token. Verify Firebase Android app, SHA-1/SHA-256, and google-services.json.');
      }
      return await signInWithCredential(auth, GoogleAuthProvider.credential(idToken));
    }
    return await signInWithPopup(auth, googleProvider);
  } catch (error) {
    console.error('Google Sign In Error:', error);
    throw error;
  }
}

export async function signOutUser() {
  await signOut(auth);
  if (Capacitor.isNativePlatform()) {
    try { await FirebaseAuthentication.signOut(); } catch (e) { console.warn('Native signout:', e); }
  }
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    return true;
  }
}

/**
 * Role resolution used by the UI. It mirrors firestore.rules exactly:
 *  - owner  = verified owner Google account (never read from the users collection)
 *  - staff / delivery = users/{uid}.role  (written only by the owner)
 *  - anything else (including a stored role of "admin") = customer
 * The UI is only a convenience: real enforcement is in firestore.rules.
 */
export interface AccessInfo {
  role: UserRole | null;
  permissions: StaffPermissions;
}

export const OWNER_PERMISSIONS: StaffPermissions = {
  viewOrders: true,
  updateStatus: true,
  toggleProducts: true,
};

export function accessFromUserDoc(user: User | null, data: Partial<UserProfile> | undefined): AccessInfo {
  if (isUserAdmin(user)) {
    return { role: 'admin', permissions: OWNER_PERMISSIONS };
  }
  const role = data?.role;
  if (role === 'staff' || role === 'delivery') {
    const p = data?.permissions || {};
    return {
      role,
      permissions: {
        viewOrders: p.viewOrders ?? DEFAULT_STAFF_PERMISSIONS.viewOrders,
        updateStatus: p.updateStatus ?? DEFAULT_STAFF_PERMISSIONS.updateStatus,
        toggleProducts: p.toggleProducts ?? DEFAULT_STAFF_PERMISSIONS.toggleProducts,
      },
    };
  }
  return { role: null, permissions: { viewOrders: false, updateStatus: false, toggleProducts: false } };
}

export async function getUserRole(uid: string): Promise<UserRole | null> {
  try {
    const userDoc = await getDoc(doc(db, 'users', uid));
    if (userDoc.exists()) {
      const role = (userDoc.data() as UserProfile).role;
      return role === 'staff' || role === 'delivery' ? role : null;
    }
    return null;
  } catch (error) {
    console.error('Error fetching user role:', error);
    return null;
  }
}

if (typeof window !== 'undefined') {
  testConnection();
}
