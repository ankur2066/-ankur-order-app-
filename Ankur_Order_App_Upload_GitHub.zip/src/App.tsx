import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, BellRing, Loader2, ShieldCheck, X } from 'lucide-react';
import { Header } from './components/Header';
import { OrderForm } from './components/OrderForm';
import { OrderTrackingView } from './components/OrderTrackingView';
import { CustomerOrders } from './components/CustomerOrders';
import { AdminDashboard } from './components/AdminDashboard';
import { StaffDashboard } from './components/StaffDashboard';
import { AIVideoStudio } from './components/AIVideoStudio';
import { RulesReviewModal } from './components/RulesReviewModal';
import { BottomNav, type CustomerTab } from './components/customer/BottomNav';
import { CustomerHome } from './components/customer/CustomerHome';
import { CategoriesTab } from './components/customer/CategoriesTab';
import { ProfileTab } from './components/customer/ProfileTab';
import { NotificationSheet } from './components/customer/NotificationSheet';
import { BrandMark } from './components/customer/BrandMark';
import { ThemeProvider } from './context/ThemeContext';
import { useAccess } from './hooks/useAccess';
import { useStorefrontProducts } from './hooks/useProducts';
import { useStorefrontSettings } from './hooks/useStorefrontSettings';
import { useOrderNotifications } from './hooks/useOrderNotifications';
import { subscribeToRates, getLocalRates } from './data/rates';
import { BUSINESS_CALL_HREF, BUSINESS_WHATSAPP_BASE } from './data/products';
import type { Order, OrderTracking, ProductItem, PromoAction, RateSettings } from './types';

type Tab = CustomerTab | 'order' | 'track' | 'admin';

const SubPageBar: React.FC<{ title: string; onBack: () => void }> = ({ title, onBack }) => (
  <div
    className="sticky top-0 z-40 c-card border-b b-line flex items-center gap-1 px-2"
    style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}
  >
    <button type="button" onClick={onBack} className="focus-ring w-11 h-11 flex items-center justify-center rounded-full cursor-pointer" aria-label="वापस">
      <ArrowLeft className="w-5 h-5 t-main" />
    </button>
    <span className="text-[15px] font-black t-main">{title}</span>
  </div>
);

function AppShell() {
  const { user: currentUser, access, ready } = useAccess();
  const role = access.role;
  const isFieldTeam = role === 'staff' || role === 'delivery';

  const [currentTab, setCurrentTab] = useState<Tab>('home');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);
  const [reorderData, setReorderData] = useState<Order | null>(null);
  const [activeTrackingId, setActiveTrackingId] = useState('');
  const [activeTrackingPin, setActiveTrackingPin] = useState('');
  const [trackBackTab, setTrackBackTab] = useState<Tab>('my-orders');
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);
  const [noticesOpen, setNoticesOpen] = useState(false);
  const [rates, setRates] = useState<RateSettings>(getLocalRates());

  const { products, loading: productsLoading, error: productsError } = useStorefrontProducts();
  const { banners, winner } = useStorefrontSettings();
  const notifications = useOrderNotifications(isFieldTeam ? null : currentUser);

  useEffect(() => {
    const unsub = subscribeToRates((loaded) => setRates(loaded));
    return () => unsub();
  }, []);

  // Owner lands on the Owner Dashboard when they sign in; anyone else can never stay on it.
  const previousRole = useRef<typeof role>(null);
  useEffect(() => {
    if (!ready) return;
    if (role === 'admin' && previousRole.current !== 'admin') setCurrentTab('admin');
    if (role !== 'admin' && currentTab === 'admin') setCurrentTab('home');
    previousRole.current = role;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role, ready]);

  const handleOrderSuccess = (orderId: string, trackingPin: string) => {
    setActiveTrackingId(orderId);
    setActiveTrackingPin(trackingPin);
  };

  const handleGoToTrack = (orderId: string, pin: string = '') => {
    setTrackBackTab(currentTab === 'admin' ? 'admin' : 'my-orders');
    setActiveTrackingId(orderId);
    setActiveTrackingPin(pin);
    setCurrentTab('track');
  };

  const handleBook = (product: ProductItem | null) => {
    setSelectedProduct(product);
    setReorderData(null);
    setCurrentTab('order');
  };

  const handleReorder = (pastOrder: Order) => {
    setSelectedProduct(null);
    setReorderData(pastOrder);
    setCurrentTab('order');
  };

  const handleQuickReorderFromTracking = (tracking: OrderTracking) => {
    const qty = tracking.quantityKg || 10;
    const partialOrder: Order = {
      orderId: tracking.orderId,
      trackingToken: tracking.trackingToken,
      trackingPin: '',
      customerName: '',
      customerPhone: '',
      district: tracking.district || '',
      address: tracking.district || '',
      quantityKg: qty,
      dispatchTiming: tracking.dispatchTiming,
      productName: tracking.productName || 'ड्राई आइस (Dry Ice)',
      dryIcePricePerKg: 50,
      dryIceSubtotal: qty * 50,
      thermocolPricePerKg: 10,
      thermocolSubtotal: qty * 10,
      totalAmount: qty * 60,
      status: 'pending',
      paymentStatus: 'pending_verification',
      paymentMethod: 'paytm_business_upi',
      userId: currentUser?.uid || 'guest',
      createdAt: null,
      updatedAt: null,
    };
    setSelectedProduct(null);
    setReorderData(partialOrder);
    setCurrentTab('order');
  };

  const handlePromoAction = (action: PromoAction) => {
    if (action === 'order') handleBook(null);
    else if (action === 'categories') setCurrentTab('categories');
    else if (action === 'call') window.location.href = BUSINESS_CALL_HREF;
    else if (action === 'whatsapp') window.open(BUSINESS_WHATSAPP_BASE, '_blank', 'noopener,noreferrer');
  };

  // ---- Loading splash while the sign-in state and role are being resolved ----
  if (!ready) {
    return (
      <div className="c-app min-h-screen flex flex-col items-center justify-center gap-3 t-brand" role="status" aria-live="polite">
        <BrandMark className="w-14 h-14" />
        <Loader2 className="w-5 h-5 animate-spin" />
        <span className="text-xs t-sub">लोड हो रहा है…</span>
      </div>
    );
  }

  // ---- Staff / delivery: locked to their dashboard (rules enforce this server-side) ----
  if (isFieldTeam) {
    return (
      <div className="min-h-screen min-w-0 overflow-x-hidden bg-white text-slate-900 flex flex-col font-sans">
        <Header currentTab="staff-dashboard" setCurrentTab={() => {}} currentUser={currentUser} userRole={role} />
        <main className="flex-1 min-w-0 pb-8">
          <StaffDashboard currentUser={currentUser} userRole={role} permissions={access.permissions} onLogoutSuccess={() => setCurrentTab('home')} />
        </main>
      </div>
    );
  }

  // ---- Customer app (and owner, who can also open the Owner Dashboard) ----
  const navActive: CustomerTab | null =
    currentTab === 'track' ? 'my-orders' : currentTab === 'order' || currentTab === 'admin' ? null : currentTab;

  const handleNavChange = (tab: CustomerTab) => {
    if (tab === 'categories' && currentTab !== 'categories') setSelectedCategory('all');
    setCurrentTab(tab);
  };

  return (
    <div className="min-h-screen min-w-0 overflow-x-hidden c-app t-main font-sans relative">
      {/* In-app status toast (shown only while the app is open) */}
      {notifications.toast && currentTab !== 'admin' && (
        <div
          className="fixed inset-x-3 z-[70] max-w-lg mx-auto c-card border b-line rounded-2xl p-3 shadow-lg flex items-start gap-3"
          style={{ top: 'calc(env(safe-area-inset-top, 0px) + 8px)' }}
          role="status"
        >
          <BellRing className="w-5 h-5 t-brand shrink-0 mt-0.5" />
          <button type="button" className="min-w-0 flex-1 text-left cursor-pointer" onClick={() => { notifications.clearToast(); setNoticesOpen(true); }}>
            <div className="text-sm font-extrabold t-main">{notifications.toast.title}</div>
            <div className="text-xs t-sub truncate">{notifications.toast.body}</div>
          </button>
          <button type="button" onClick={notifications.clearToast} aria-label="बंद करें" className="shrink-0 cursor-pointer">
            <X className="w-4 h-4 t-sub" />
          </button>
        </div>
      )}

      {currentTab === 'home' && (
        <CustomerHome
          products={products}
          productsLoading={productsLoading}
          productsError={productsError}
          rates={rates}
          banners={banners}
          winner={winner}
          currentUser={currentUser}
          unreadCount={notifications.unreadCount}
          onOpenNotifications={() => setNoticesOpen(true)}
          onOpenProfile={() => setCurrentTab('profile')}
          onBook={handleBook}
          onReorder={handleReorder}
          onPromoAction={handlePromoAction}
        />
      )}

      {currentTab === 'categories' && (
        <CategoriesTab
          products={products}
          loading={productsLoading}
          rates={rates}
          selected={selectedCategory}
          onSelect={setSelectedCategory}
          onBook={handleBook}
        />
      )}

      {currentTab === 'order' && (
        <div className="bg-white min-h-screen">
          <SubPageBar title="ड्राई आइस बुकिंग" onBack={() => setCurrentTab('home')} />
          <OrderForm
            currentUser={currentUser}
            onOrderSuccess={handleOrderSuccess}
            onGoToTrack={handleGoToTrack}
            onGoToMyOrders={() => setCurrentTab('my-orders')}
            reorderData={reorderData}
            onClearReorder={() => setReorderData(null)}
            selectedProduct={selectedProduct}
            onClearProduct={() => {
              setSelectedProduct(null);
              setCurrentTab('home');
            }}
          />
        </div>
      )}

      {currentTab === 'track' && (
        <div className="bg-white min-h-screen page-with-bottom-nav">
          <SubPageBar title="ऑर्डर ट्रैकिंग" onBack={() => setCurrentTab(trackBackTab)} />
          <OrderTrackingView
            initialOrderId={activeTrackingId}
            initialPin={activeTrackingPin}
            onQuickReorder={handleQuickReorderFromTracking}
          />
        </div>
      )}

      {currentTab === 'my-orders' && (
        <div className="bg-white min-h-screen page-with-bottom-nav" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
          <CustomerOrders
            currentUser={currentUser}
            onGoToTrack={handleGoToTrack}
            onGoToOrder={() => handleBook(null)}
            onReorder={handleReorder}
          />
        </div>
      )}

      {currentTab === 'ai-video' && <AIVideoStudio currentUser={currentUser} />}

      {currentTab === 'profile' && (
        <ProfileTab
          currentUser={currentUser}
          role={role}
          onGoOrders={() => setCurrentTab('my-orders')}
          onOpenOwnerDashboard={() => setCurrentTab('admin')}
          onOpenRulesReview={() => setIsRulesModalOpen(true)}
        />
      )}

      {currentTab === 'admin' && role === 'admin' && (
        <div className="bg-white min-h-screen text-slate-900">
          <div className="sticky top-0 z-40 bg-white border-b border-slate-200 px-3 flex items-center justify-between" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
            <span className="text-xs font-black text-slate-700 flex items-center gap-1.5 py-2.5">
              <ShieldCheck className="w-4 h-4 text-sky-600" /> ओनर पैनल
            </span>
            <button type="button" onClick={() => setCurrentTab('home')} className="text-xs font-extrabold text-sky-700 py-2.5 px-2 cursor-pointer">
              ग्राहक ऐप देखें
            </button>
          </div>
          <AdminDashboard
            currentUser={currentUser}
            onGoToTrack={handleGoToTrack}
            onGoToOrder={() => setCurrentTab('home')}
            onOpenRulesReview={() => setIsRulesModalOpen(true)}
          />
        </div>
      )}

      {currentTab !== 'admin' && currentTab !== 'order' && <BottomNav active={navActive} onChange={handleNavChange} />}

      <NotificationSheet
        open={noticesOpen}
        notices={notifications.notices}
        onClose={() => setNoticesOpen(false)}
        onMarkAllRead={notifications.markAllRead}
      />

      {/* Security rules review is available to the owner only */}
      {role === 'admin' && <RulesReviewModal isOpen={isRulesModalOpen} onClose={() => setIsRulesModalOpen(false)} />}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppShell />
    </ThemeProvider>
  );
}
