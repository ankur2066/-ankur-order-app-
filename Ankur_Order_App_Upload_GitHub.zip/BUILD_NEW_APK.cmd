@echo off
cd /d "%~dp0"
echo [1/4] Installing dependencies for NEW app...
call npm install --no-audit --no-fund
if errorlevel 1 goto fail
echo [2/4] Building latest app...
call npm run build
if errorlevel 1 goto fail
echo [3/4] Preparing Android project...
if not exist "android\gradlew.bat" (
  call npx cap add android
  if errorlevel 1 goto fail
)
call npx cap sync android
if errorlevel 1 goto fail
echo [4/4] Creating debug APK...
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto fail
echo.
echo SUCCESS: android\app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. Save this window screenshot.
pause
exit /b 1
