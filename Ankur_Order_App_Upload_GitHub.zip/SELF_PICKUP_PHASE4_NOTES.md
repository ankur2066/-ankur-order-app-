# Self Pickup Phase 4 — Customer receipt UI
- CustomerOrders displays PDF button only for authenticated owner of a valid confirmed pickup order.
- Missing verified received amount or box count causes a visible error, not invented data.
- Added optional order fields selfPickup, verifiedReceivedAmount, pickupBoxes; existing orders unchanged.
- Existing Firestore rules prevent customer updates, but staff pickup writes are not implemented.
- No Firebase writes, notifications, WhatsApp queue, owner alerts, or Android build performed.
- Production requires secured transactional pickup writes and owner/staff controls.
