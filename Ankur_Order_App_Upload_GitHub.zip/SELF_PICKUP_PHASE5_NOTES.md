# Phase 5: transaction groundwork (NOT production enabled)

Added `src/services/selfPickupTransactions.ts` with Firestore transaction scaffold for pickup confirmation and undo and a separate audit document. The function deliberately rejects orders without an explicit `selfPickup` field. It is not wired into staff buttons.

**Security blocker:** Current `firestore.rules` disallows `selfPickup` and `pickupBoxes` on orders and limits staff updates to `status`/`updatedAt`. There is no `pickup_audit` write rule. Thus this transaction currently fails securely, rather than bypassing rules. Do not deploy permissive rules merely to make it work. A trusted backend or strict Firestore rules using `request.time`, authenticated actor role and per-order permissions are required before enabling staff UI.

Other remaining work: owner pickup settings, real owner alerts, customer push, WhatsApp queue, receipt verification, integration tests and signed APK.
