# Phase 9 — Trusted Firebase Callable backend source (NOT deployed)

- `firebase-functions/index.js` implements authenticated callable `changeSelfPickup` with App Check required.
- Server checks owner email verification or staff role with explicit `viewOrders` and `updateStatus` permissions.
- Firestore transaction updates pickup state, writes immutable audit, and queues a notification event atomically.
- 5-minute staff undo is calculated using server time; same staff member only; owner can override; undo reason required.
- No WhatsApp messages are sent automatically; outbox records are only a queue, not a delivery implementation.
- `firebase-functions` is a separate Node 22 package, not wired into the existing frontend yet.
- Existing client transaction scaffold remains **unsafe to expose**; staff buttons stay disabled.
- Security note: deploy a Firestore rule that blocks direct client mutation of `selfPickup`, even by owner, once the callable is active; the current owner rules allow direct changes and do not ensure matching audits. Existing rules are NOT deployed by this ZIP.
- No Firebase credentials, live writes, deploy, GitHub push, emulator tests, or signed APK performed.
