# Phase 6 — Staff pickup status and secure audit boundary

- Staff Dashboard shows read-only pickup status for explicitly tagged Self Pickup orders.
- Confirm/Undo controls remain disabled pending secure Firebase implementation.
- `pickup_audit` is owner-readable and client-write-denied to prevent forged audit entries.
- No live Firestore changes, rule deployment, GitHub push or APK build.

Next: verified staff authorization, request.time-based 5-minute undo, atomic immutable audit, owner/customer alerts and tests.
