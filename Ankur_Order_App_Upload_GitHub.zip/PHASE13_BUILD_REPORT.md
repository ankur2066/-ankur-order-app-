# Phase 13 — Build and Firebase configuration checkpoint

- Added firebase.json for the existing `firebase-functions` directory and local Auth/Functions/Firestore emulator configuration. This does not deploy anything.
- `node --test firebase-functions/pickupPolicy.test.js`: 11 passed, 0 failed.
- `node --check firebase-functions/index.js`: passed.
- `npm ci --ignore-scripts --no-audit --no-fund`: timed out in this environment. TypeScript, Vite, Android, and Firebase Emulator tests **not verified**.
- `changeSelfPickup` requires Firebase App Check, and the code has not been deployed. Do not release an APK claiming Self Pickup works until deployed and end-to-end tested.
- No production Firebase modifications, GitHub push, or APK build.
