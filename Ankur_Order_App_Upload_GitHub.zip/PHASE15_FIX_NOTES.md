# Phase 15 — preserve pickup metadata

Fixed the Firebase callable confirm transition to preserve existing `selfPickup` fields (e.g. pickup configuration) instead of replacing the entire map. No deployment or production data change.

Existing unit tests only cover pickupPolicy, not Firestore transaction integration. Full app build and Firebase emulator testing still required.
