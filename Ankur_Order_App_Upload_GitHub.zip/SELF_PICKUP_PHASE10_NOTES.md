# Phase 10 — Staff Dashboard wired to callable backend

- Confirm Pickup and Undo Pickup now invoke `changeSelfPickup` via Firebase callable Functions (`asia-south1`).
- UI asks for handover confirmation; Undo requires a reason.
- UI disables actions while an operation is running and shows server errors.
- Backend remains the source of truth for permission and five-minute window; client UI alone is not an authorization boundary.

**Not deployed.** Firebase callable `enforceAppCheck: true` requires configured App Check; without it calls fail safely. `firebase-functions` must be installed and deployed, and Firestore rules / emulator tests validated. No live Firebase changes, push notifications, WhatsApp sends, GitHub push, or APK build occurred here.
